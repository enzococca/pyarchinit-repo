# tabs/Documentazione_preview.py

## Overview

This file contains 18 documented elements.

## Classes

### pyarchinit_doc_preview

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface, docstr)

##### DB_connect(self)

##### draw_preview(self)

##### testing(self, name_file, message)

### pyarchinit_doc_preview

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface, docstr)

##### DB_connect(self)

##### draw_preview(self)

##### testing(self, name_file, message)

### pyarchinit_doc_preview

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface, docstr)

##### DB_connect(self)

##### draw_preview(self)

##### testing(self, name_file, message)

