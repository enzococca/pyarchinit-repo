# scripts/insert_saggio_vano_from_excel.py

## Overview

This file contains 12 documented elements.

## Functions

### insert_saggio_values(cursor)

Inserisce valori di esempio per saggio.

**Parameters:**
- `cursor`

### insert_vano_values(cursor)

Inserisce valori di esempio per vano/locus.

**Parameters:**
- `cursor`

### main()

### insert_saggio_values(cursor)

Inserisce valori di esempio per saggio.

**Parameters:**
- `cursor`

### insert_vano_values(cursor)

Inserisce valori di esempio per vano/locus.

**Parameters:**
- `cursor`

### main()

### insert_saggio_values(cursor)

Inserisce valori di esempio per saggio.

**Parameters:**
- `cursor`

### insert_vano_values(cursor)

Inserisce valori di esempio per vano/locus.

**Parameters:**
- `cursor`

### main()

