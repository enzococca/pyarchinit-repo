# scripts/update_entities_us_field.py

## Overview

This file contains 9 documented elements.

## Functions

### update_file(filepath, field_name, old_pattern, new_pattern)

Update a single file to change field type

**Parameters:**
- `filepath`
- `field_name`
- `old_pattern`
- `new_pattern`

### main()

Main migration function

### update_file(filepath, field_name, old_pattern, new_pattern)

Update a single file to change field type

**Parameters:**
- `filepath`
- `field_name`
- `old_pattern`
- `new_pattern`

### main()

Main migration function

### update_file(filepath, field_name, old_pattern, new_pattern)

Update a single file to change field type

**Parameters:**
- `filepath`
- `field_name`
- `old_pattern`
- `new_pattern`

### main()

Main migration function

