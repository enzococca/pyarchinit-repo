# modules/db/entities/DETSESSO.py

## Overview

This file contains 16 documented elements.

## Classes

### DETSESSO

**Inherits from**: object

#### Methods

##### __init__(self, id_det_sesso, sito, num_individuo, glab_grado_imp, pmast_grado_imp, pnuc_grado_imp, pzig_grado_imp, arcsop_grado_imp, tub_grado_imp, pocc_grado_imp, inclfr_grado_imp, zig_grado_imp, msorb_grado_imp, glab_valori, pmast_valori, pnuc_valori, pzig_valori, arcsop_valori, tub_valori, pocc_valori, inclfr_valori, zig_valori, msorb_valori, palato_grado_imp, mfmand_grado_imp, mento_grado_imp, anmand_grado_imp, minf_grado_imp, brmont_grado_imp, condm_grado_imp, palato_valori, mfmand_valori, mento_valori, anmand_valori, minf_valori, brmont_valori, condm_valori, sex_cr_tot, ind_cr_sex, sup_p_I, sup_p_II, sup_p_III, sup_p_sex, in_isch_I, in_isch_II, in_isch_III, in_isch_sex, arco_c_sex, ramo_ip_I, ramo_ip_II, ramo_ip_III, ramo_ip_sex, prop_ip_sex, ind_bac_sex)

##### __repr__(self)

### DETSESSO

**Inherits from**: object

#### Methods

##### __init__(self, id_det_sesso, sito, num_individuo, glab_grado_imp, pmast_grado_imp, pnuc_grado_imp, pzig_grado_imp, arcsop_grado_imp, tub_grado_imp, pocc_grado_imp, inclfr_grado_imp, zig_grado_imp, msorb_grado_imp, glab_valori, pmast_valori, pnuc_valori, pzig_valori, arcsop_valori, tub_valori, pocc_valori, inclfr_valori, zig_valori, msorb_valori, palato_grado_imp, mfmand_grado_imp, mento_grado_imp, anmand_grado_imp, minf_grado_imp, brmont_grado_imp, condm_grado_imp, palato_valori, mfmand_valori, mento_valori, anmand_valori, minf_valori, brmont_valori, condm_valori, sex_cr_tot, ind_cr_sex, sup_p_I, sup_p_II, sup_p_III, sup_p_sex, in_isch_I, in_isch_II, in_isch_III, in_isch_sex, arco_c_sex, ramo_ip_I, ramo_ip_II, ramo_ip_III, ramo_ip_sex, prop_ip_sex, ind_bac_sex)

##### __repr__(self)

### DETSESSO

**Inherits from**: object

#### Methods

##### __init__(self, id_det_sesso, sito, num_individuo, glab_grado_imp, pmast_grado_imp, pnuc_grado_imp, pzig_grado_imp, arcsop_grado_imp, tub_grado_imp, pocc_grado_imp, inclfr_grado_imp, zig_grado_imp, msorb_grado_imp, glab_valori, pmast_valori, pnuc_valori, pzig_valori, arcsop_valori, tub_valori, pocc_valori, inclfr_valori, zig_valori, msorb_valori, palato_grado_imp, mfmand_grado_imp, mento_grado_imp, anmand_grado_imp, minf_grado_imp, brmont_grado_imp, condm_grado_imp, palato_valori, mfmand_valori, mento_valori, anmand_valori, minf_valori, brmont_valori, condm_valori, sex_cr_tot, ind_cr_sex, sup_p_I, sup_p_II, sup_p_III, sup_p_sex, in_isch_I, in_isch_II, in_isch_III, in_isch_sex, arco_c_sex, ramo_ip_I, ramo_ip_II, ramo_ip_III, ramo_ip_sex, prop_ip_sex, ind_bac_sex)

##### __repr__(self)

### DETSESSO

**Inherits from**: object

#### Methods

##### __init__(self, id_det_sesso, sito, num_individuo, glab_grado_imp, pmast_grado_imp, pnuc_grado_imp, pzig_grado_imp, arcsop_grado_imp, tub_grado_imp, pocc_grado_imp, inclfr_grado_imp, zig_grado_imp, msorb_grado_imp, glab_valori, pmast_valori, pnuc_valori, pzig_valori, arcsop_valori, tub_valori, pocc_valori, inclfr_valori, zig_valori, msorb_valori, palato_grado_imp, mfmand_grado_imp, mento_grado_imp, anmand_grado_imp, minf_grado_imp, brmont_grado_imp, condm_grado_imp, palato_valori, mfmand_valori, mento_valori, anmand_valori, minf_valori, brmont_valori, condm_valori, sex_cr_tot, ind_cr_sex, sup_p_I, sup_p_II, sup_p_III, sup_p_sex, in_isch_I, in_isch_II, in_isch_III, in_isch_sex, arco_c_sex, ramo_ip_I, ramo_ip_II, ramo_ip_III, ramo_ip_sex, prop_ip_sex, ind_bac_sex)

##### __repr__(self)

