# fix_tma_table_names.py

## Overview

This file contains 8 documented elements.

## Functions

### fix_tma_table_names()

Fix the inconsistent TMA table names in the database

### fix_tma_table_names()

Fix the inconsistent TMA table names in the database

### fix_tma_table_names()

Fix the inconsistent TMA table names in the database

### fix_tma_table_names()

Fix the inconsistent TMA table names in the database

