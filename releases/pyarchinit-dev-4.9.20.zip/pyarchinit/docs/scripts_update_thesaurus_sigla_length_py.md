# scripts/update_thesaurus_sigla_length.py

## Overview

This file contains 12 documented elements.

## Functions

### update_sigla_length_sqlite(db_path)

Aggiorna la lunghezza del campo sigla per SQLite.

**Parameters:**
- `db_path`

### create_postgres_update_script()

Crea script SQL per PostgreSQL.

### main()

### update_sigla_length_sqlite(db_path)

Aggiorna la lunghezza del campo sigla per SQLite.

**Parameters:**
- `db_path`

### create_postgres_update_script()

Crea script SQL per PostgreSQL.

### main()

### update_sigla_length_sqlite(db_path)

Aggiorna la lunghezza del campo sigla per SQLite.

**Parameters:**
- `db_path`

### create_postgres_update_script()

Crea script SQL per PostgreSQL.

### main()

