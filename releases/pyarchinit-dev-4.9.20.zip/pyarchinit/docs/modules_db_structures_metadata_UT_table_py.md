# modules/db/structures_metadata/UT_table.py

## Overview

This file contains 12 documented elements.

## Classes

### UT_table

#### Methods

##### define_table(cls, metadata)

### UT_table

#### Methods

##### define_table(cls, metadata)

### UT_table

#### Methods

##### define_table(cls, metadata)

### UT_table

#### Methods

##### define_table(cls, metadata)

