# modules/utility/pyarchinit_folder_installation.py

## Overview

This file contains 16 documented elements.

## Classes

### pyarchinit_Folder_installation

**Inherits from**: object

#### Methods

##### install_dir(self)

##### installConfigFile(self, path)

### pyarchinit_Folder_installation

**Inherits from**: object

#### Methods

##### install_dir(self)

##### installConfigFile(self, path)

### pyarchinit_Folder_installation

**Inherits from**: object

#### Methods

##### install_dir(self)

##### installConfigFile(self, path)

### pyarchinit_Folder_installation

**Inherits from**: object

#### Methods

##### install_dir(self)

##### installConfigFile(self, path)

