# tabs/Gis_Time_controller.py

## Overview

This file contains 60 documented elements.

## Classes

### ZoomableGraphicsView

**Inherits from**: QGraphicsView

#### Methods

##### __init__(self, parent)

##### wheelEvent(self, event)

### pyarchinit_Gis_Time_Controller

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### connect(self)

##### update_selected_layers(self)

##### update_layers(self, layers)

##### set_max_num(self)

##### update_graphics_view(self)

##### define_order_layer_value(self, v)

##### update_datazione(self, value)

##### liststring(self, sito, area, i, e)

##### on_pushButton_visualize_pressed(self)

##### on_pushButton_atlas_pressed(self)

##### load_template(self, template_path)

##### generate_images(self)

##### stop_processes_named(self, name)

##### stop_image_generation(self)

### ZoomableGraphicsView

**Inherits from**: QGraphicsView

#### Methods

##### __init__(self, parent)

##### wheelEvent(self, event)

### pyarchinit_Gis_Time_Controller

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### connect(self)

##### update_selected_layers(self)

##### update_layers(self, layers)

##### set_max_num(self)

##### update_graphics_view(self)

##### define_order_layer_value(self, v)

##### update_datazione(self, value)

##### liststring(self, sito, area, i, e)

##### on_pushButton_visualize_pressed(self)

##### on_pushButton_atlas_pressed(self)

##### load_template(self, template_path)

##### generate_images(self)

##### stop_processes_named(self, name)

##### stop_image_generation(self)

### ZoomableGraphicsView

**Inherits from**: QGraphicsView

#### Methods

##### __init__(self, parent)

##### wheelEvent(self, event)

### pyarchinit_Gis_Time_Controller

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### connect(self)

##### update_selected_layers(self)

##### update_layers(self, layers)

##### set_max_num(self)

##### update_graphics_view(self)

##### define_order_layer_value(self, v)

##### update_datazione(self, value)

##### liststring(self, sito, area, i, e)

##### on_pushButton_visualize_pressed(self)

##### on_pushButton_atlas_pressed(self)

##### load_template(self, template_path)

##### generate_images(self)

##### stop_processes_named(self, name)

##### stop_image_generation(self)

