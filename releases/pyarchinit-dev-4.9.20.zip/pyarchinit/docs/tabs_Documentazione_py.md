# tabs/Documentazione.py

## Overview

This file contains 138 documented elements.

## Classes

### pyarchinit_Documentazione

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### enable_button(self, n)

##### enable_button_search(self, n)

##### on_pushButton_connect_pressed(self)

##### charge_list(self)

##### msg_sito(self)

##### set_sito(self)

##### generate_list_pdf(self)

##### on_pushButton_disegno_doc_pressed(self)

##### on_pushButton_exp_scheda_doc_pressed(self)

##### on_pushButton_exp_elenco_doc_pressed(self)

##### on_pushButtonPreview_pressed(self)

##### on_pushButton_sort_pressed(self)

##### on_pushButton_new_rec_pressed(self)

##### on_pushButton_save_pressed(self)

##### data_error_check(self)

##### insert_new_rec(self)

##### check_record_state(self)

##### on_pushButton_view_all_pressed(self)

##### on_pushButton_first_rec_pressed(self)

##### on_pushButton_last_rec_pressed(self)

##### on_pushButton_prev_rec_pressed(self)

##### on_pushButton_next_rec_pressed(self)

##### on_pushButton_delete_pressed(self)

##### on_pushButton_new_search_pressed(self)

##### on_pushButton_search_go_pressed(self)

##### on_pushButton_test_pressed(self)

##### update_if(self, msg)

##### charge_records(self)

##### datestrfdate(self)

##### table2dict(self, n)

##### empty_fields_nosite(self)

##### empty_fields(self)

##### fill_fields(self, n)

##### set_rec_counter(self, t, c)

##### set_LIST_REC_TEMP(self)

##### set_LIST_REC_CORR(self)

##### setComboBoxEnable(self, f, v)

##### setComboBoxEditable(self, f, n)

##### rec_toupdate(self)

##### records_equal_check(self)

##### update_record(self)

##### testing(self, name_file, message)

##### check_for_updates(self)

Check if current record has been modified by others

### pyarchinit_Documentazione

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### enable_button(self, n)

##### enable_button_search(self, n)

##### on_pushButton_connect_pressed(self)

##### charge_list(self)

##### msg_sito(self)

##### set_sito(self)

##### generate_list_pdf(self)

##### on_pushButton_disegno_doc_pressed(self)

##### on_pushButton_exp_scheda_doc_pressed(self)

##### on_pushButton_exp_elenco_doc_pressed(self)

##### on_pushButtonPreview_pressed(self)

##### on_pushButton_sort_pressed(self)

##### on_pushButton_new_rec_pressed(self)

##### on_pushButton_save_pressed(self)

##### data_error_check(self)

##### insert_new_rec(self)

##### check_record_state(self)

##### on_pushButton_view_all_pressed(self)

##### on_pushButton_first_rec_pressed(self)

##### on_pushButton_last_rec_pressed(self)

##### on_pushButton_prev_rec_pressed(self)

##### on_pushButton_next_rec_pressed(self)

##### on_pushButton_delete_pressed(self)

##### on_pushButton_new_search_pressed(self)

##### on_pushButton_search_go_pressed(self)

##### on_pushButton_test_pressed(self)

##### update_if(self, msg)

##### charge_records(self)

##### datestrfdate(self)

##### table2dict(self, n)

##### empty_fields_nosite(self)

##### empty_fields(self)

##### fill_fields(self, n)

##### set_rec_counter(self, t, c)

##### set_LIST_REC_TEMP(self)

##### set_LIST_REC_CORR(self)

##### setComboBoxEnable(self, f, v)

##### setComboBoxEditable(self, f, n)

##### rec_toupdate(self)

##### records_equal_check(self)

##### update_record(self)

##### testing(self, name_file, message)

##### check_for_updates(self)

Check if current record has been modified by others

### pyarchinit_Documentazione

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### enable_button(self, n)

##### enable_button_search(self, n)

##### on_pushButton_connect_pressed(self)

##### charge_list(self)

##### msg_sito(self)

##### set_sito(self)

##### generate_list_pdf(self)

##### on_pushButton_disegno_doc_pressed(self)

##### on_pushButton_exp_scheda_doc_pressed(self)

##### on_pushButton_exp_elenco_doc_pressed(self)

##### on_pushButtonPreview_pressed(self)

##### on_pushButton_sort_pressed(self)

##### on_pushButton_new_rec_pressed(self)

##### on_pushButton_save_pressed(self)

##### data_error_check(self)

##### insert_new_rec(self)

##### check_record_state(self)

##### on_pushButton_view_all_pressed(self)

##### on_pushButton_first_rec_pressed(self)

##### on_pushButton_last_rec_pressed(self)

##### on_pushButton_prev_rec_pressed(self)

##### on_pushButton_next_rec_pressed(self)

##### on_pushButton_delete_pressed(self)

##### on_pushButton_new_search_pressed(self)

##### on_pushButton_search_go_pressed(self)

##### on_pushButton_test_pressed(self)

##### update_if(self, msg)

##### charge_records(self)

##### datestrfdate(self)

##### table2dict(self, n)

##### empty_fields_nosite(self)

##### empty_fields(self)

##### fill_fields(self, n)

##### set_rec_counter(self, t, c)

##### set_LIST_REC_TEMP(self)

##### set_LIST_REC_CORR(self)

##### setComboBoxEnable(self, f, v)

##### setComboBoxEditable(self, f, n)

##### rec_toupdate(self)

##### records_equal_check(self)

##### update_record(self)

##### testing(self, name_file, message)

##### check_for_updates(self)

Check if current record has been modified by others

