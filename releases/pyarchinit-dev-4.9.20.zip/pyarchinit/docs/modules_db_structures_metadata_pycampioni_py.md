# modules/db/structures_metadata/pycampioni.py

## Overview

This file contains 12 documented elements.

## Classes

### pycampioni

#### Methods

##### define_table(cls, metadata)

### pycampioni

#### Methods

##### define_table(cls, metadata)

### pycampioni

#### Methods

##### define_table(cls, metadata)

### pycampioni

#### Methods

##### define_table(cls, metadata)

