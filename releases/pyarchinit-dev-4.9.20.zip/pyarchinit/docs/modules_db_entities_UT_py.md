# modules/db/entities/UT.py

## Overview

This file contains 16 documented elements.

## Classes

### UT

**Inherits from**: object

#### Methods

##### __init__(self, id_ut, progetto, nr_ut, ut_letterale, def_ut, descrizione_ut, interpretazione_ut, nazione, regione, provincia, comune, frazione, localita, indirizzo, nr_civico, carta_topo_igm, carta_ctr, coord_geografiche, coord_piane, quota, andamento_terreno_pendenza, utilizzo_suolo_vegetazione, descrizione_empirica_suolo, descrizione_luogo, metodo_rilievo_e_ricognizione, geometria, bibliografia, data, ora_meteo, responsabile, dimensioni_ut, rep_per_mq, rep_datanti, periodo_I, datazione_I, interpretazione_I, periodo_II, datazione_II, interpretazione_II, documentazione, enti_tutela_vincoli, indagini_preliminari)

##### __repr__(self)

### UT

**Inherits from**: object

#### Methods

##### __init__(self, id_ut, progetto, nr_ut, ut_letterale, def_ut, descrizione_ut, interpretazione_ut, nazione, regione, provincia, comune, frazione, localita, indirizzo, nr_civico, carta_topo_igm, carta_ctr, coord_geografiche, coord_piane, quota, andamento_terreno_pendenza, utilizzo_suolo_vegetazione, descrizione_empirica_suolo, descrizione_luogo, metodo_rilievo_e_ricognizione, geometria, bibliografia, data, ora_meteo, responsabile, dimensioni_ut, rep_per_mq, rep_datanti, periodo_I, datazione_I, interpretazione_I, periodo_II, datazione_II, interpretazione_II, documentazione, enti_tutela_vincoli, indagini_preliminari)

##### __repr__(self)

### UT

**Inherits from**: object

#### Methods

##### __init__(self, id_ut, progetto, nr_ut, ut_letterale, def_ut, descrizione_ut, interpretazione_ut, nazione, regione, provincia, comune, frazione, localita, indirizzo, nr_civico, carta_topo_igm, carta_ctr, coord_geografiche, coord_piane, quota, andamento_terreno_pendenza, utilizzo_suolo_vegetazione, descrizione_empirica_suolo, descrizione_luogo, metodo_rilievo_e_ricognizione, geometria, bibliografia, data, ora_meteo, responsabile, dimensioni_ut, rep_per_mq, rep_datanti, periodo_I, datazione_I, interpretazione_I, periodo_II, datazione_II, interpretazione_II, documentazione, enti_tutela_vincoli, indagini_preliminari)

##### __repr__(self)

### UT

**Inherits from**: object

#### Methods

##### __init__(self, id_ut, progetto, nr_ut, ut_letterale, def_ut, descrizione_ut, interpretazione_ut, nazione, regione, provincia, comune, frazione, localita, indirizzo, nr_civico, carta_topo_igm, carta_ctr, coord_geografiche, coord_piane, quota, andamento_terreno_pendenza, utilizzo_suolo_vegetazione, descrizione_empirica_suolo, descrizione_luogo, metodo_rilievo_e_ricognizione, geometria, bibliografia, data, ora_meteo, responsabile, dimensioni_ut, rep_per_mq, rep_datanti, periodo_I, datazione_I, interpretazione_I, periodo_II, datazione_II, interpretazione_II, documentazione, enti_tutela_vincoli, indagini_preliminari)

##### __repr__(self)

