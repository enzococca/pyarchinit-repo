# modules/utility/pyarchinit_exp_pdf_experimental.py

## Overview

This file contains 56 documented elements.

## Classes

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

