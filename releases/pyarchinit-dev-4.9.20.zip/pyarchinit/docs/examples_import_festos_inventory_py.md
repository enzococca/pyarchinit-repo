# examples/import_festos_inventory.py

## Overview

This file contains 20 documented elements.

## Functions

### import_festos_inventory(file_path)

Importa un inventario cassette di Festos

Args:
    file_path: percorso del file DOCX con l'inventario

**Parameters:**
- `file_path`

### batch_import_inventories(directory_path)

Importa tutti i file DOCX di inventario da una directory

Args:
    directory_path: percorso della directory con i file

**Parameters:**
- `directory_path`

### import_single_file(file_path)

Importa un singolo file (funzione helper)

**Parameters:**
- `file_path`

### main()

Funzione principale con esempi

### import_festos_inventory(file_path)

Importa un inventario cassette di Festos

Args:
    file_path: percorso del file DOCX con l'inventario

**Parameters:**
- `file_path`

### batch_import_inventories(directory_path)

Importa tutti i file DOCX di inventario da una directory

Args:
    directory_path: percorso della directory con i file

**Parameters:**
- `directory_path`

### import_single_file(file_path)

Importa un singolo file (funzione helper)

**Parameters:**
- `file_path`

### main()

Funzione principale con esempi

### import_festos_inventory(file_path)

Importa un inventario cassette di Festos

Args:
    file_path: percorso del file DOCX con l'inventario

**Parameters:**
- `file_path`

### batch_import_inventories(directory_path)

Importa tutti i file DOCX di inventario da una directory

Args:
    directory_path: percorso della directory con i file

**Parameters:**
- `directory_path`

### import_single_file(file_path)

Importa un singolo file (funzione helper)

**Parameters:**
- `file_path`

### main()

Funzione principale con esempi

### import_festos_inventory(file_path)

Importa un inventario cassette di Festos

Args:
    file_path: percorso del file DOCX con l'inventario

**Parameters:**
- `file_path`

### batch_import_inventories(directory_path)

Importa tutti i file DOCX di inventario da una directory

Args:
    directory_path: percorso della directory con i file

**Parameters:**
- `directory_path`

### import_single_file(file_path)

Importa un singolo file (funzione helper)

**Parameters:**
- `file_path`

### main()

Funzione principale con esempi

