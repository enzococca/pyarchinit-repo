# PlaceSelectionDialog.py

## Overview

This file contains 12 documented elements.

## Classes

### PlaceSelectionDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self)

### PlaceSelectionDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self)

### PlaceSelectionDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self)

### PlaceSelectionDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self)

