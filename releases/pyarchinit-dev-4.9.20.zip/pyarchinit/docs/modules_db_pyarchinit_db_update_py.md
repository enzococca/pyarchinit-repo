# modules/db/pyarchinit_db_update.py

## Overview

This file contains 28 documented elements.

## Classes

### DB_update

**Inherits from**: object

#### Methods

##### __init__(self, conn_str)

##### update_table(self)

### DB_update

**Inherits from**: object

#### Methods

##### __init__(self, conn_str)

##### update_table(self)

### DB_update

**Inherits from**: object

#### Methods

##### __init__(self, conn_str)

##### update_table(self)

### DB_update

**Inherits from**: object

#### Methods

##### __init__(self, conn_str)

##### update_table(self)

## Functions

### log_debug(msg)

**Parameters:**
- `msg`

### safe_load_table(table_name)

Carica una tabella gestendo errori di encoding UTF-8

**Parameters:**
- `table_name`

### safe_load_table(table_name)

Load a table handling encoding errors

**Parameters:**
- `table_name`

### log_debug(msg)

**Parameters:**
- `msg`

### safe_load_table(table_name)

Carica una tabella gestendo errori di encoding UTF-8

**Parameters:**
- `table_name`

### safe_load_table(table_name)

Load a table handling encoding errors

**Parameters:**
- `table_name`

### log_debug(msg)

**Parameters:**
- `msg`

### safe_load_table(table_name)

Carica una tabella gestendo errori di encoding UTF-8

**Parameters:**
- `table_name`

### safe_load_table(table_name)

Load a table handling encoding errors

**Parameters:**
- `table_name`

### log_debug(msg)

**Parameters:**
- `msg`

### safe_load_table(table_name)

Carica una tabella gestendo errori di encoding UTF-8

**Parameters:**
- `table_name`

### safe_load_table(table_name)

Load a table handling encoding errors

**Parameters:**
- `table_name`

