# modules/db/structures/DETSESSO_table.py

## Overview

This file contains 8 documented elements.

## Classes

### DETSESSO_table

### DETSESSO_table

### DETSESSO_table

### DETSESSO_table

