# modules/db/entities/TMA.py

## Overview

This file contains 16 documented elements.

## Classes

### TMA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, area, localita, settore, inventario, ogtm, ldct, ldcn, vecchia_collocazione, cassetta, scan, saggio, vano_locus, dscd, dscu, rcgd, rcgz, aint, aind, dtzg, deso, nsc, ftap, ftan, drat, dran, draa, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

### TMA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, area, localita, settore, inventario, ogtm, ldct, ldcn, vecchia_collocazione, cassetta, scan, saggio, vano_locus, dscd, dscu, rcgd, rcgz, aint, aind, dtzg, deso, nsc, ftap, ftan, drat, dran, draa, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

### TMA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, area, localita, settore, inventario, ogtm, ldct, ldcn, vecchia_collocazione, cassetta, scan, saggio, vano_locus, dscd, dscu, rcgd, rcgz, aint, aind, dtzg, deso, nsc, ftap, ftan, drat, dran, draa, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

### TMA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, area, localita, settore, inventario, ogtm, ldct, ldcn, vecchia_collocazione, cassetta, scan, saggio, vano_locus, dscd, dscu, rcgd, rcgz, aint, aind, dtzg, deso, nsc, ftap, ftan, drat, dran, draa, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

