# modules/utility/pyarchinit_exp_Tafonomiasheet_pdf.py

## Overview

This file contains 148 documented elements.

## Classes

### NumberedCanvas_TOMBAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_TOMBAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Tomba_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Tomba_index_II_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Tomba_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_tomba_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Tomba_sheets(self, records)

##### build_Tomba_sheets_de(self, records)

##### build_Tomba_sheets_en(self, records)

##### build_index_Tomba(self, records, sito)

### NumberedCanvas_TOMBAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_TOMBAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Tomba_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Tomba_index_II_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Tomba_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_tomba_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Tomba_sheets(self, records)

##### build_Tomba_sheets_de(self, records)

##### build_Tomba_sheets_en(self, records)

##### build_index_Tomba(self, records, sito)

### NumberedCanvas_TOMBAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_TOMBAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Tomba_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Tomba_index_II_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Tomba_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_tomba_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Tomba_sheets(self, records)

##### build_Tomba_sheets_de(self, records)

##### build_Tomba_sheets_en(self, records)

##### build_index_Tomba(self, records, sito)

### NumberedCanvas_TOMBAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_TOMBAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Tomba_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Tomba_index_II_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Tomba_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_tomba_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Tomba_sheets(self, records)

##### build_Tomba_sheets_de(self, records)

##### build_Tomba_sheets_en(self, records)

##### build_index_Tomba(self, records, sito)

