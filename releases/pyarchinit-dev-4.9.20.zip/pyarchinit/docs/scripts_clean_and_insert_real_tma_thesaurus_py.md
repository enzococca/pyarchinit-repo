# scripts/clean_and_insert_real_tma_thesaurus.py

## Overview

This file contains 12 documented elements.

## Functions

### clean_existing_data(cursor)

Rimuove tutti i dati esistenti del thesaurus TMA.

**Parameters:**
- `cursor`

### insert_tma_thesaurus_data(cursor)

Inserisce i dati reali del thesaurus TMA.

**Parameters:**
- `cursor`

### main()

### clean_existing_data(cursor)

Rimuove tutti i dati esistenti del thesaurus TMA.

**Parameters:**
- `cursor`

### insert_tma_thesaurus_data(cursor)

Inserisce i dati reali del thesaurus TMA.

**Parameters:**
- `cursor`

### main()

### clean_existing_data(cursor)

Rimuove tutti i dati esistenti del thesaurus TMA.

**Parameters:**
- `cursor`

### insert_tma_thesaurus_data(cursor)

Inserisce i dati reali del thesaurus TMA.

**Parameters:**
- `cursor`

### main()

