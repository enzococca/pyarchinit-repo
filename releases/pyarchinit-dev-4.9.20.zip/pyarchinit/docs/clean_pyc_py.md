# clean_pyc.py

## Overview

This file contains 8 documented elements.

## Functions

### clean_pyc_files(root_dir)

Rimuove tutti i file .pyc e le directory __pycache__

**Parameters:**
- `root_dir`

### clean_pyc_files(root_dir)

Rimuove tutti i file .pyc e le directory __pycache__

**Parameters:**
- `root_dir`

### clean_pyc_files(root_dir)

Rimuove tutti i file .pyc e le directory __pycache__

**Parameters:**
- `root_dir`

### clean_pyc_files(root_dir)

Rimuove tutti i file .pyc e le directory __pycache__

**Parameters:**
- `root_dir`

