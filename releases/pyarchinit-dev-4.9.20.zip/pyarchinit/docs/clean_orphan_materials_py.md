# clean_orphan_materials.py

## Overview

This file contains 4 documented elements.

