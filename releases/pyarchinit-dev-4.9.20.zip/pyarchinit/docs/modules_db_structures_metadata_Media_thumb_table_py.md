# modules/db/structures_metadata/Media_thumb_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Media_thumb_table

#### Methods

##### define_table(cls, metadata)

### Media_thumb_table

#### Methods

##### define_table(cls, metadata)

### Media_thumb_table

#### Methods

##### define_table(cls, metadata)

### Media_thumb_table

#### Methods

##### define_table(cls, metadata)

