# modules/utility/archaeological_data_mapping.py

## Overview

This file contains 48 documented elements.

## Classes

### ArchaeologicalDataMapper

**Inherits from**: QWidget

#### Methods

##### __init__(self, iface, parent)

##### initUI(self)

##### open_file(self, link)

##### get_input_file(self)

##### get_output_file(self)

##### process_data(self)

##### load_input_data(self, input_file)

##### map_data_to_template(self, input_df)

##### create_archaeological_excel(self, input_file, output_file)

### ArchaeologicalDataMapper

**Inherits from**: QWidget

#### Methods

##### __init__(self, iface, parent)

##### initUI(self)

##### open_file(self, link)

##### get_input_file(self)

##### get_output_file(self)

##### process_data(self)

##### load_input_data(self, input_file)

##### map_data_to_template(self, input_df)

##### create_archaeological_excel(self, input_file, output_file)

### ArchaeologicalDataMapper

**Inherits from**: QWidget

#### Methods

##### __init__(self, iface, parent)

##### initUI(self)

##### open_file(self, link)

##### get_input_file(self)

##### get_output_file(self)

##### process_data(self)

##### load_input_data(self, input_file)

##### map_data_to_template(self, input_df)

##### create_archaeological_excel(self, input_file, output_file)

### ArchaeologicalDataMapper

**Inherits from**: QWidget

#### Methods

##### __init__(self, iface, parent)

##### initUI(self)

##### open_file(self, link)

##### get_input_file(self)

##### get_output_file(self)

##### process_data(self)

##### load_input_data(self, input_file)

##### map_data_to_template(self, input_df)

##### create_archaeological_excel(self, input_file, output_file)

## Functions

### process_quantity(q)

**Parameters:**
- `q`

### process_measurements(measurements)

**Parameters:**
- `measurements`

### process_quantity(q)

**Parameters:**
- `q`

### process_measurements(measurements)

**Parameters:**
- `measurements`

### process_quantity(q)

**Parameters:**
- `q`

### process_measurements(measurements)

**Parameters:**
- `measurements`

### process_quantity(q)

**Parameters:**
- `q`

### process_measurements(measurements)

**Parameters:**
- `measurements`

