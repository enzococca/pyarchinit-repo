# modules/db/structures_metadata/Tma_materiali_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Tma_materiali_table

TMA Materiali - Table for repetitive material data

#### Methods

##### define_table(cls, metadata)

### Tma_materiali_table

TMA Materiali - Table for repetitive material data

#### Methods

##### define_table(cls, metadata)

### Tma_materiali_table

TMA Materiali - Table for repetitive material data

#### Methods

##### define_table(cls, metadata)

### Tma_materiali_table

TMA Materiali - Table for repetitive material data

#### Methods

##### define_table(cls, metadata)

