# modules/db/structures_metadata/Documentazione_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Documentazione_table

#### Methods

##### define_table(cls, metadata)

### Documentazione_table

#### Methods

##### define_table(cls, metadata)

### Documentazione_table

#### Methods

##### define_table(cls, metadata)

### Documentazione_table

#### Methods

##### define_table(cls, metadata)

