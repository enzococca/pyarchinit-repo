# modules/db/entities/ARCHEOZOOLOGY.py

## Overview

This file contains 16 documented elements.

## Classes

### ARCHEOZOOLOGY

**Inherits from**: object

#### Methods

##### __init__(self, id_archzoo, sito, area, us, quadrato, coord_x, coord_y, coord_z, bos_bison, calcinati, camoscio, capriolo, cervo, combusto, coni, pdi, stambecco, strie, canidi, ursidi, megacero)

##### __repr__(self)

### ARCHEOZOOLOGY

**Inherits from**: object

#### Methods

##### __init__(self, id_archzoo, sito, area, us, quadrato, coord_x, coord_y, coord_z, bos_bison, calcinati, camoscio, capriolo, cervo, combusto, coni, pdi, stambecco, strie, canidi, ursidi, megacero)

##### __repr__(self)

### ARCHEOZOOLOGY

**Inherits from**: object

#### Methods

##### __init__(self, id_archzoo, sito, area, us, quadrato, coord_x, coord_y, coord_z, bos_bison, calcinati, camoscio, capriolo, cervo, combusto, coni, pdi, stambecco, strie, canidi, ursidi, megacero)

##### __repr__(self)

### ARCHEOZOOLOGY

**Inherits from**: object

#### Methods

##### __init__(self, id_archzoo, sito, area, us, quadrato, coord_x, coord_y, coord_z, bos_bison, calcinati, camoscio, capriolo, cervo, combusto, coni, pdi, stambecco, strie, canidi, ursidi, megacero)

##### __repr__(self)

