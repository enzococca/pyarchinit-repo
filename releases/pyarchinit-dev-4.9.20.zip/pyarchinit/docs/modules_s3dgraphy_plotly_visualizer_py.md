# modules/s3dgraphy/plotly_visualizer.py

## Overview

This file contains 16 documented elements.

## Classes

### PlotlyMatrixVisualizer

Creates interactive stratigraphic matrix visualization using Plotly

#### Methods

##### __init__(self, qgis_integration)

##### create_interactive_graph(self, graph_data, output_path)

Create interactive graph visualization with Plotly

### PlotlyMatrixVisualizer

Creates interactive stratigraphic matrix visualization using Plotly

#### Methods

##### __init__(self, qgis_integration)

##### create_interactive_graph(self, graph_data, output_path)

Create interactive graph visualization with Plotly

### PlotlyMatrixVisualizer

Creates interactive stratigraphic matrix visualization using Plotly

#### Methods

##### __init__(self, qgis_integration)

##### create_interactive_graph(self, graph_data, output_path)

Create interactive graph visualization with Plotly

### PlotlyMatrixVisualizer

Creates interactive stratigraphic matrix visualization using Plotly

#### Methods

##### __init__(self, qgis_integration)

##### create_interactive_graph(self, graph_data, output_path)

Create interactive graph visualization with Plotly

