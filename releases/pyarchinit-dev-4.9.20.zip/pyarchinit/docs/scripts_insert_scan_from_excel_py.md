# scripts/insert_scan_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_scan_values(cursor)

Inserisce i valori scan dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_scan_values(cursor)

Inserisce i valori scan dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_scan_values(cursor)

Inserisce i valori scan dal file Excel.

**Parameters:**
- `cursor`

### main()

