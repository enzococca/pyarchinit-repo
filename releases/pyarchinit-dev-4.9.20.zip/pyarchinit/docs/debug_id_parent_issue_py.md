# debug_id_parent_issue.py

## Overview

This file contains 8 documented elements.

## Functions

### debug_parent_lookup()

Debug the parent lookup logic exactly as used in insert_new_rec

### debug_parent_lookup()

Debug the parent lookup logic exactly as used in insert_new_rec

### debug_parent_lookup()

Debug the parent lookup logic exactly as used in insert_new_rec

### debug_parent_lookup()

Debug the parent lookup logic exactly as used in insert_new_rec

