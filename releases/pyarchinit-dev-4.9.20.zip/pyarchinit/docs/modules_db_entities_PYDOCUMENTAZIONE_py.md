# modules/db/entities/PYDOCUMENTAZIONE.py

## Overview

This file contains 16 documented elements.

## Classes

### PYDOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito, nome_doc, tipo_doc, path_qgis_pj, the_geom)

##### __repr__(self)

### PYDOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito, nome_doc, tipo_doc, path_qgis_pj, the_geom)

##### __repr__(self)

### PYDOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito, nome_doc, tipo_doc, path_qgis_pj, the_geom)

##### __repr__(self)

### PYDOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito, nome_doc, tipo_doc, path_qgis_pj, the_geom)

##### __repr__(self)

