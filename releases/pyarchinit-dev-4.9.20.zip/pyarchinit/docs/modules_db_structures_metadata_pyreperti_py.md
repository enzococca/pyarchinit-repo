# modules/db/structures_metadata/pyreperti.py

## Overview

This file contains 12 documented elements.

## Classes

### pyreperti

#### Methods

##### define_table(cls, metadata)

### pyreperti

#### Methods

##### define_table(cls, metadata)

### pyreperti

#### Methods

##### define_table(cls, metadata)

### pyreperti

#### Methods

##### define_table(cls, metadata)

