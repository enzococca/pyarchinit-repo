# modules/db/structures_metadata/pyripartizioni_spaziali.py

## Overview

This file contains 12 documented elements.

## Classes

### pyripartizioni_spaziali

#### Methods

##### define_table(cls, metadata)

### pyripartizioni_spaziali

#### Methods

##### define_table(cls, metadata)

### pyripartizioni_spaziali

#### Methods

##### define_table(cls, metadata)

### pyripartizioni_spaziali

#### Methods

##### define_table(cls, metadata)

