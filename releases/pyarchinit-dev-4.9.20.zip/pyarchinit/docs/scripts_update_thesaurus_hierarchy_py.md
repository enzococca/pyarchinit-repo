# scripts/update_thesaurus_hierarchy.py

## Overview

This file contains 15 documented elements.

## Functions

### add_hierarchy_fields(cursor)

Aggiunge i campi per la gerarchia se non esistono.

**Parameters:**
- `cursor`

### clear_tma_thesaurus(cursor)

Rimuove i dati esistenti del thesaurus TMA per reimportarli con gerarchia.

**Parameters:**
- `cursor`

### insert_hierarchical_data(cursor)

Inserisce i dati con relazioni gerarchiche.

**Parameters:**
- `cursor`

### main()

### add_hierarchy_fields(cursor)

Aggiunge i campi per la gerarchia se non esistono.

**Parameters:**
- `cursor`

### clear_tma_thesaurus(cursor)

Rimuove i dati esistenti del thesaurus TMA per reimportarli con gerarchia.

**Parameters:**
- `cursor`

### insert_hierarchical_data(cursor)

Inserisce i dati con relazioni gerarchiche.

**Parameters:**
- `cursor`

### main()

### add_hierarchy_fields(cursor)

Aggiunge i campi per la gerarchia se non esistono.

**Parameters:**
- `cursor`

### clear_tma_thesaurus(cursor)

Rimuove i dati esistenti del thesaurus TMA per reimportarli con gerarchia.

**Parameters:**
- `cursor`

### insert_hierarchical_data(cursor)

Inserisce i dati con relazioni gerarchiche.

**Parameters:**
- `cursor`

### main()

