# modules/db/structures_metadata/pyindividui.py

## Overview

This file contains 12 documented elements.

## Classes

### pyindividui

#### Methods

##### define_table(cls, metadata)

### pyindividui

#### Methods

##### define_table(cls, metadata)

### pyindividui

#### Methods

##### define_table(cls, metadata)

### pyindividui

#### Methods

##### define_table(cls, metadata)

