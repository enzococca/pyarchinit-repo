# modules/db/entities/US_TOIMP.py

## Overview

This file contains 16 documented elements.

## Classes

### US_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_us, sito, area, us, d_stratigrafica, d_interpretativa, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, scavato, attivita, anno_scavo, metodo_di_scavo, inclusi, campioni, rapporti, data_schedatura, schedatore, formazione, stato_di_conservazione, colore, consistenza, struttura)

##### __repr__(self)

### US_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_us, sito, area, us, d_stratigrafica, d_interpretativa, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, scavato, attivita, anno_scavo, metodo_di_scavo, inclusi, campioni, rapporti, data_schedatura, schedatore, formazione, stato_di_conservazione, colore, consistenza, struttura)

##### __repr__(self)

### US_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_us, sito, area, us, d_stratigrafica, d_interpretativa, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, scavato, attivita, anno_scavo, metodo_di_scavo, inclusi, campioni, rapporti, data_schedatura, schedatore, formazione, stato_di_conservazione, colore, consistenza, struttura)

##### __repr__(self)

### US_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_us, sito, area, us, d_stratigrafica, d_interpretativa, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, scavato, attivita, anno_scavo, metodo_di_scavo, inclusi, campioni, rapporti, data_schedatura, schedatore, formazione, stato_di_conservazione, colore, consistenza, struttura)

##### __repr__(self)

