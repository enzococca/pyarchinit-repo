# modules/db/entities/PYSITO_POLYGON.py

## Overview

This file contains 16 documented elements.

## Classes

### PYSITO_POLYGON

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_id, the_geom)

##### __repr__(self)

### PYSITO_POLYGON

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_id, the_geom)

##### __repr__(self)

### PYSITO_POLYGON

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_id, the_geom)

##### __repr__(self)

### PYSITO_POLYGON

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_id, the_geom)

##### __repr__(self)

