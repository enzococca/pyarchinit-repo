# debug_tma_widgets.py

## Overview

This file contains 24 documented elements.

## Functions

### check_thesaurus_data(cursor)

Check thesaurus data for correct nome_tabella values

**Parameters:**
- `cursor`

### test_localita_query(cursor)

Test the exact query used in filter_area_by_localita

**Parameters:**
- `cursor`

### check_hierarchy(cursor)

Check if hierarchy is properly set up

**Parameters:**
- `cursor`

### suggest_fixes(cursor)

Suggest SQL fixes if needed

**Parameters:**
- `cursor`

### main()

### check_thesaurus_data(cursor)

Check thesaurus data for correct nome_tabella values

**Parameters:**
- `cursor`

### test_localita_query(cursor)

Test the exact query used in filter_area_by_localita

**Parameters:**
- `cursor`

### check_hierarchy(cursor)

Check if hierarchy is properly set up

**Parameters:**
- `cursor`

### suggest_fixes(cursor)

Suggest SQL fixes if needed

**Parameters:**
- `cursor`

### main()

### check_thesaurus_data(cursor)

Check thesaurus data for correct nome_tabella values

**Parameters:**
- `cursor`

### test_localita_query(cursor)

Test the exact query used in filter_area_by_localita

**Parameters:**
- `cursor`

### check_hierarchy(cursor)

Check if hierarchy is properly set up

**Parameters:**
- `cursor`

### suggest_fixes(cursor)

Suggest SQL fixes if needed

**Parameters:**
- `cursor`

### main()

### check_thesaurus_data(cursor)

Check thesaurus data for correct nome_tabella values

**Parameters:**
- `cursor`

### test_localita_query(cursor)

Test the exact query used in filter_area_by_localita

**Parameters:**
- `cursor`

### check_hierarchy(cursor)

Check if hierarchy is properly set up

**Parameters:**
- `cursor`

### suggest_fixes(cursor)

Suggest SQL fixes if needed

**Parameters:**
- `cursor`

### main()

