# scripts/add_tma_localita_settore_postgres.py

## Overview

This file contains 9 documented elements.

## Functions

### check_column_exists(cursor, table_name, column_name)

Check if a column exists in a PostgreSQL table.

**Parameters:**
- `cursor`
- `table_name`
- `column_name`

### main()

### check_column_exists(cursor, table_name, column_name)

Check if a column exists in a PostgreSQL table.

**Parameters:**
- `cursor`
- `table_name`
- `column_name`

### main()

### check_column_exists(cursor, table_name, column_name)

Check if a column exists in a PostgreSQL table.

**Parameters:**
- `cursor`
- `table_name`
- `column_name`

### main()

