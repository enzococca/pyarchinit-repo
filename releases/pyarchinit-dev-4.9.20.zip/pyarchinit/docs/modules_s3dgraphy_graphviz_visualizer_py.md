# modules/s3dgraphy/graphviz_visualizer.py

## Overview

This file contains 16 documented elements.

## Classes

### GraphvizVisualizer

Creates a hierarchical graph visualization using Graphviz

#### Methods

##### __init__(self)

##### create_graph_image(self, graph_data, output_path)

Create a hierarchical graph visualization using Graphviz

Args:
    graph_data: Extended Matrix data
    output_path: Path to save the image

Returns:
    True if successful

### GraphvizVisualizer

Creates a hierarchical graph visualization using Graphviz

#### Methods

##### __init__(self)

##### create_graph_image(self, graph_data, output_path)

Create a hierarchical graph visualization using Graphviz

Args:
    graph_data: Extended Matrix data
    output_path: Path to save the image

Returns:
    True if successful

### GraphvizVisualizer

Creates a hierarchical graph visualization using Graphviz

#### Methods

##### __init__(self)

##### create_graph_image(self, graph_data, output_path)

Create a hierarchical graph visualization using Graphviz

Args:
    graph_data: Extended Matrix data
    output_path: Path to save the image

Returns:
    True if successful

### GraphvizVisualizer

Creates a hierarchical graph visualization using Graphviz

#### Methods

##### __init__(self)

##### create_graph_image(self, graph_data, output_path)

Create a hierarchical graph visualization using Graphviz

Args:
    graph_data: Extended Matrix data
    output_path: Path to save the image

Returns:
    True if successful

