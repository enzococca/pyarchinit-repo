# modules/db/structures_metadata/pysito_point.py

## Overview

This file contains 12 documented elements.

## Classes

### pysito_point

#### Methods

##### define_table(cls, metadata)

### pysito_point

#### Methods

##### define_table(cls, metadata)

### pysito_point

#### Methods

##### define_table(cls, metadata)

### pysito_point

#### Methods

##### define_table(cls, metadata)

