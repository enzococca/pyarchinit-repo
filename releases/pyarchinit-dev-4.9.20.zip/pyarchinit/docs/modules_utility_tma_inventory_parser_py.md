# modules/utility/tma_inventory_parser.py

## Overview

This file contains 24 documented elements.

## Classes

### TMAInventoryParser

Parser specifico per file inventario cassette archeologiche

#### Methods

##### __init__(self)

##### parse_docx_inventory(self, file_path, sito)

Parsa un file docx con inventario cassette

Args:
    file_path: Path del file docx
    sito: Nome del sito (se non specificato, cerca nel testo)
    
Returns:
    Lista di dizionari con i record da importare

### TMAInventoryImportDialog

Dialog per completare i dati mancanti durante l'import

#### Methods

##### __init__(self, parent)

##### get_completion_data(self, records)

Mostra un dialog per completare i dati mancanti

Returns:
    Tuple di (records aggiornati, conferma import)

### TMAInventoryParser

Parser specifico per file inventario cassette archeologiche

#### Methods

##### __init__(self)

##### parse_docx_inventory(self, file_path, sito)

Parsa un file docx con inventario cassette

Args:
    file_path: Path del file docx
    sito: Nome del sito (se non specificato, cerca nel testo)
    
Returns:
    Lista di dizionari con i record da importare

### TMAInventoryImportDialog

Dialog per completare i dati mancanti durante l'import

#### Methods

##### __init__(self, parent)

##### get_completion_data(self, records)

Mostra un dialog per completare i dati mancanti

Returns:
    Tuple di (records aggiornati, conferma import)

### TMAInventoryParser

Parser specifico per file inventario cassette archeologiche

#### Methods

##### __init__(self)

##### parse_docx_inventory(self, file_path, sito)

Parsa un file docx con inventario cassette

Args:
    file_path: Path del file docx
    sito: Nome del sito (se non specificato, cerca nel testo)
    
Returns:
    Lista di dizionari con i record da importare

### TMAInventoryImportDialog

Dialog per completare i dati mancanti durante l'import

#### Methods

##### __init__(self, parent)

##### get_completion_data(self, records)

Mostra un dialog per completare i dati mancanti

Returns:
    Tuple di (records aggiornati, conferma import)

### TMAInventoryParser

Parser specifico per file inventario cassette archeologiche

#### Methods

##### __init__(self)

##### parse_docx_inventory(self, file_path, sito)

Parsa un file docx con inventario cassette

Args:
    file_path: Path del file docx
    sito: Nome del sito (se non specificato, cerca nel testo)
    
Returns:
    Lista di dizionari con i record da importare

### TMAInventoryImportDialog

Dialog per completare i dati mancanti durante l'import

#### Methods

##### __init__(self, parent)

##### get_completion_data(self, records)

Mostra un dialog per completare i dati mancanti

Returns:
    Tuple di (records aggiornati, conferma import)

