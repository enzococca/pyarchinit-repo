# examples/tma_import_example.py

## Overview

This file contains 24 documented elements.

## Functions

### import_excel_example()

Esempio di importazione da Excel

### import_with_custom_mapping()

Esempio di importazione con mapping personalizzato dei campi

### import_batch_example()

Esempio di importazione di multipli file

### create_example_files()

Crea file di esempio per testare l'importazione

### show_available_mappings()

Mostra tutti i mapping di campo disponibili

### import_excel_example()

Esempio di importazione da Excel

### import_with_custom_mapping()

Esempio di importazione con mapping personalizzato dei campi

### import_batch_example()

Esempio di importazione di multipli file

### create_example_files()

Crea file di esempio per testare l'importazione

### show_available_mappings()

Mostra tutti i mapping di campo disponibili

### import_excel_example()

Esempio di importazione da Excel

### import_with_custom_mapping()

Esempio di importazione con mapping personalizzato dei campi

### import_batch_example()

Esempio di importazione di multipli file

### create_example_files()

Crea file di esempio per testare l'importazione

### show_available_mappings()

Mostra tutti i mapping di campo disponibili

### import_excel_example()

Esempio di importazione da Excel

### import_with_custom_mapping()

Esempio di importazione con mapping personalizzato dei campi

### import_batch_example()

Esempio di importazione di multipli file

### create_example_files()

Crea file di esempio per testare l'importazione

### show_available_mappings()

Mostra tutti i mapping di campo disponibili

