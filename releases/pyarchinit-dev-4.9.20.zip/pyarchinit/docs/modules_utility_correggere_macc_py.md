# modules/utility/correggere_macc.py

## Overview

This file contains 24 documented elements.

## Functions

### find_db_from_loaded_layer(table_name)

Se la layer è caricata, prova a estrarre il path dal datasource.

**Parameters:**
- `table_name`

### msg(txt, level)

Messaggi su console e (se disponibile) sulla message bar di QGIS.

**Parameters:**
- `txt`
- `level`

### backup_db(path)

Crea un backup del db con timestamp nella stessa cartella.

**Parameters:**
- `path`

### table_info(conn, table)

**Parameters:**
- `conn`
- `table`

### fk_list(conn, table)

**Parameters:**
- `conn`
- `table`

### find_db_from_loaded_layer(table_name)

Se la layer è caricata, prova a estrarre il path dal datasource.

**Parameters:**
- `table_name`

### msg(txt, level)

Messaggi su console e (se disponibile) sulla message bar di QGIS.

**Parameters:**
- `txt`
- `level`

### backup_db(path)

Crea un backup del db con timestamp nella stessa cartella.

**Parameters:**
- `path`

### table_info(conn, table)

**Parameters:**
- `conn`
- `table`

### fk_list(conn, table)

**Parameters:**
- `conn`
- `table`

### find_db_from_loaded_layer(table_name)

Se la layer è caricata, prova a estrarre il path dal datasource.

**Parameters:**
- `table_name`

### msg(txt, level)

Messaggi su console e (se disponibile) sulla message bar di QGIS.

**Parameters:**
- `txt`
- `level`

### backup_db(path)

Crea un backup del db con timestamp nella stessa cartella.

**Parameters:**
- `path`

### table_info(conn, table)

**Parameters:**
- `conn`
- `table`

### fk_list(conn, table)

**Parameters:**
- `conn`
- `table`

### find_db_from_loaded_layer(table_name)

Se la layer è caricata, prova a estrarre il path dal datasource.

**Parameters:**
- `table_name`

### msg(txt, level)

Messaggi su console e (se disponibile) sulla message bar di QGIS.

**Parameters:**
- `txt`
- `level`

### backup_db(path)

Crea un backup del db con timestamp nella stessa cartella.

**Parameters:**
- `path`

### table_info(conn, table)

**Parameters:**
- `conn`
- `table`

### fk_list(conn, table)

**Parameters:**
- `conn`
- `table`

