# scripts/thesaurus_summary.py

## Overview

This file contains 9 documented elements.

## Functions

### generate_summary(db_path)

Genera un riepilogo del thesaurus.

**Parameters:**
- `db_path`

### main()

### generate_summary(db_path)

Genera un riepilogo del thesaurus.

**Parameters:**
- `db_path`

### main()

### generate_summary(db_path)

Genera un riepilogo del thesaurus.

**Parameters:**
- `db_path`

### main()

