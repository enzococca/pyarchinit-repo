# modules/db/entities/PDF_ADMINISTRATOR.py

## Overview

This file contains 16 documented elements.

## Classes

### PDF_ADMINISTRATOR

**Inherits from**: object

#### Methods

##### __init__(self, id_pdf_administrator, table_name, schema_griglia, schema_fusione_celle, modello)

##### __repr__(self)

### PDF_ADMINISTRATOR

**Inherits from**: object

#### Methods

##### __init__(self, id_pdf_administrator, table_name, schema_griglia, schema_fusione_celle, modello)

##### __repr__(self)

### PDF_ADMINISTRATOR

**Inherits from**: object

#### Methods

##### __init__(self, id_pdf_administrator, table_name, schema_griglia, schema_fusione_celle, modello)

##### __repr__(self)

### PDF_ADMINISTRATOR

**Inherits from**: object

#### Methods

##### __init__(self, id_pdf_administrator, table_name, schema_griglia, schema_fusione_celle, modello)

##### __repr__(self)

