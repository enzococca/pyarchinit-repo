# tabs/pyarchinit_setting_matrix.py

## Overview

This file contains 9 documented elements.

## Classes

### Setting_Matrix

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self)

### Setting_Matrix

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self)

### Setting_Matrix

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self)

