# modules/db/entities/MEDIAVIEW.py

## Overview

This file contains 16 documented elements.

## Classes

### MEDIAVIEW

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, filepath, path_resize, entity_type, id_media_m, id_entity)

##### __repr__(self)

### MEDIAVIEW

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, filepath, path_resize, entity_type, id_media_m, id_entity)

##### __repr__(self)

### MEDIAVIEW

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, filepath, path_resize, entity_type, id_media_m, id_entity)

##### __repr__(self)

### MEDIAVIEW

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, filepath, path_resize, entity_type, id_media_m, id_entity)

##### __repr__(self)

