# modules/db/structures_metadata/Tafonomia_table.py

## Overview

This file contains 8 documented elements.

## Classes

### Tomba_table

### Tomba_table

### Tomba_table

### Tomba_table

