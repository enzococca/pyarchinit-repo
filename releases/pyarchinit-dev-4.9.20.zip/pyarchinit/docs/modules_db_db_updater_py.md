# modules/db/db_updater.py

## Overview

This file contains 20 documented elements.

## Classes

### DatabaseUpdater

Handles automatic database updates when connecting

#### Methods

##### __init__(self, db_manager)

##### check_and_update_triggers(self)

Check and update database triggers to ensure they're compatible
with multi-user permission system

##### update_create_doc_trigger(self)

Update the create_doc trigger to handle permission issues

### DatabaseUpdater

Handles automatic database updates when connecting

#### Methods

##### __init__(self, db_manager)

##### check_and_update_triggers(self)

Check and update database triggers to ensure they're compatible
with multi-user permission system

##### update_create_doc_trigger(self)

Update the create_doc trigger to handle permission issues

### DatabaseUpdater

Handles automatic database updates when connecting

#### Methods

##### __init__(self, db_manager)

##### check_and_update_triggers(self)

Check and update database triggers to ensure they're compatible
with multi-user permission system

##### update_create_doc_trigger(self)

Update the create_doc trigger to handle permission issues

### DatabaseUpdater

Handles automatic database updates when connecting

#### Methods

##### __init__(self, db_manager)

##### check_and_update_triggers(self)

Check and update database triggers to ensure they're compatible
with multi-user permission system

##### update_create_doc_trigger(self)

Update the create_doc trigger to handle permission issues

