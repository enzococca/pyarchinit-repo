# scripts/fix_spatialite_view_registration.py

## Overview

This file contains 9 documented elements.

## Functions

### fix_view_registration(db_path)

Fix the registration of pyarchinit_us_view in SpatiaLite metadata tables

**Parameters:**
- `db_path`

### main()

### fix_view_registration(db_path)

Fix the registration of pyarchinit_us_view in SpatiaLite metadata tables

**Parameters:**
- `db_path`

### main()

### fix_view_registration(db_path)

Fix the registration of pyarchinit_us_view in SpatiaLite metadata tables

**Parameters:**
- `db_path`

### main()

