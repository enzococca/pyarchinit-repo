# tabs/Upd.py

## Overview

This file contains 18 documented elements.

## Classes

### pyarchinit_Upd_Values

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### load_connection(self)

##### on_pushButton_pressed(self)

##### update_record(self, table_value, id_field_value, id_value_list, table_fields_list, data_list)

### pyarchinit_Upd_Values

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### load_connection(self)

##### on_pushButton_pressed(self)

##### update_record(self, table_value, id_field_value, id_value_list, table_fields_list, data_list)

### pyarchinit_Upd_Values

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### load_connection(self)

##### on_pushButton_pressed(self)

##### update_record(self, table_value, id_field_value, id_value_list, table_fields_list, data_list)

