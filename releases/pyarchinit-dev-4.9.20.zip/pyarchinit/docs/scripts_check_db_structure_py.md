# scripts/check_db_structure.py

## Overview

This file contains 6 documented elements.

## Functions

### check_db_structure(db_path)

Check the structure of TMA tables in the database.

**Parameters:**
- `db_path`

### check_db_structure(db_path)

Check the structure of TMA tables in the database.

**Parameters:**
- `db_path`

### check_db_structure(db_path)

Check the structure of TMA tables in the database.

**Parameters:**
- `db_path`

