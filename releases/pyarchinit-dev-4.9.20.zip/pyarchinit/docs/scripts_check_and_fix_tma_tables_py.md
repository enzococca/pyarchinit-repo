# scripts/check_and_fix_tma_tables.py

## Overview

This file contains 12 documented elements.

## Functions

### check_table_exists(cursor, table_name)

Check if table exists

**Parameters:**
- `cursor`
- `table_name`

### get_table_columns(cursor, table_name)

Get columns of a table

**Parameters:**
- `cursor`
- `table_name`

### main()

### check_table_exists(cursor, table_name)

Check if table exists

**Parameters:**
- `cursor`
- `table_name`

### get_table_columns(cursor, table_name)

Get columns of a table

**Parameters:**
- `cursor`
- `table_name`

### main()

### check_table_exists(cursor, table_name)

Check if table exists

**Parameters:**
- `cursor`
- `table_name`

### get_table_columns(cursor, table_name)

Get columns of a table

**Parameters:**
- `cursor`
- `table_name`

### main()

