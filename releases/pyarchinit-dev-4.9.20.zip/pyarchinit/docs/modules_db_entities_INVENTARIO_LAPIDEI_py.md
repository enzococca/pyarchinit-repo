# modules/db/entities/INVENTARIO_LAPIDEI.py

## Overview

This file contains 16 documented elements.

## Classes

### INVENTARIO_LAPIDEI

**Inherits from**: object

#### Methods

##### __init__(self, id_invlap, sito, scheda_numero, collocazione, oggetto, tipologia, materiale, d_letto_posa, d_letto_attesa, toro, spessore, larghezza, lunghezza, h, descrizione, lavorazione_e_stato_di_conservazione, confronti, cronologia, bibliografia, compilatore)

##### __repr__(self)

### INVENTARIO_LAPIDEI

**Inherits from**: object

#### Methods

##### __init__(self, id_invlap, sito, scheda_numero, collocazione, oggetto, tipologia, materiale, d_letto_posa, d_letto_attesa, toro, spessore, larghezza, lunghezza, h, descrizione, lavorazione_e_stato_di_conservazione, confronti, cronologia, bibliografia, compilatore)

##### __repr__(self)

### INVENTARIO_LAPIDEI

**Inherits from**: object

#### Methods

##### __init__(self, id_invlap, sito, scheda_numero, collocazione, oggetto, tipologia, materiale, d_letto_posa, d_letto_attesa, toro, spessore, larghezza, lunghezza, h, descrizione, lavorazione_e_stato_di_conservazione, confronti, cronologia, bibliografia, compilatore)

##### __repr__(self)

### INVENTARIO_LAPIDEI

**Inherits from**: object

#### Methods

##### __init__(self, id_invlap, sito, scheda_numero, collocazione, oggetto, tipologia, materiale, d_letto_posa, d_letto_attesa, toro, spessore, larghezza, lunghezza, h, descrizione, lavorazione_e_stato_di_conservazione, confronti, cronologia, bibliografia, compilatore)

##### __repr__(self)

