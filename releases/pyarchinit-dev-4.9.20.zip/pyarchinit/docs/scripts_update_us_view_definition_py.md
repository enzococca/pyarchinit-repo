# scripts/update_us_view_definition.py

## Overview

This file contains 9 documented elements.

## Functions

### update_view_definition(db_path)

Update the pyarchinit_us_view to ensure proper column selection

**Parameters:**
- `db_path`

### main()

### update_view_definition(db_path)

Update the pyarchinit_us_view to ensure proper column selection

**Parameters:**
- `db_path`

### main()

### update_view_definition(db_path)

Update the pyarchinit_us_view to ensure proper column selection

**Parameters:**
- `db_path`

### main()

