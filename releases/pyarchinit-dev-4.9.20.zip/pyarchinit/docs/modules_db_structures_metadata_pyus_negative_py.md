# modules/db/structures_metadata/pyus_negative.py

## Overview

This file contains 12 documented elements.

## Classes

### pyus_negative

#### Methods

##### define_table(cls, metadata)

### pyus_negative

#### Methods

##### define_table(cls, metadata)

### pyus_negative

#### Methods

##### define_table(cls, metadata)

### pyus_negative

#### Methods

##### define_table(cls, metadata)

