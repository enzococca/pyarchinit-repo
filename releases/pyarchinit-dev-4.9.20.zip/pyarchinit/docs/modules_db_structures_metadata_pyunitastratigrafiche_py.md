# modules/db/structures_metadata/pyunitastratigrafiche.py

## Overview

This file contains 12 documented elements.

## Classes

### pyunitastratigrafiche

#### Methods

##### define_table(cls, metadata)

### pyunitastratigrafiche

#### Methods

##### define_table(cls, metadata)

### pyunitastratigrafiche

#### Methods

##### define_table(cls, metadata)

### pyunitastratigrafiche

#### Methods

##### define_table(cls, metadata)

