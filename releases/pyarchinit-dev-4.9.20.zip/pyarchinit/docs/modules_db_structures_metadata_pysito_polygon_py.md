# modules/db/structures_metadata/pysito_polygon.py

## Overview

This file contains 12 documented elements.

## Classes

### pysito_polygon

#### Methods

##### define_table(cls, metadata)

### pysito_polygon

#### Methods

##### define_table(cls, metadata)

### pysito_polygon

#### Methods

##### define_table(cls, metadata)

### pysito_polygon

#### Methods

##### define_table(cls, metadata)

