# scripts/verify_tma_tables.py

## Overview

This file contains 9 documented elements.

## Functions

### verify_tables(db_path)

Verifica l'esistenza delle tabelle TMA.

**Parameters:**
- `db_path`

### main()

### verify_tables(db_path)

Verifica l'esistenza delle tabelle TMA.

**Parameters:**
- `db_path`

### main()

### verify_tables(db_path)

Verifica l'esistenza delle tabelle TMA.

**Parameters:**
- `db_path`

### main()

