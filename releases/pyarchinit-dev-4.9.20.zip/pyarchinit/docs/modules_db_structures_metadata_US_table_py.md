# modules/db/structures_metadata/US_table.py

## Overview

This file contains 12 documented elements.

## Classes

### US_table

#### Methods

##### define_table(cls, metadata)

### US_table

#### Methods

##### define_table(cls, metadata)

### US_table

#### Methods

##### define_table(cls, metadata)

### US_table

#### Methods

##### define_table(cls, metadata)

