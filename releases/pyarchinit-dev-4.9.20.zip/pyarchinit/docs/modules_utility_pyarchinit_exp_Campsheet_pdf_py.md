# modules/utility/pyarchinit_exp_Campsheet_pdf.py

## Overview

This file contains 228 documented elements.

## Classes

### NumberedCanvas_Campionisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Campioniindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Campioni_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_campioni_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Champ_sheets(self, records)

##### build_Champ_sheets_de(self, records)

##### build_Champ_sheets_en(self, records)

##### build_index_Campioni(self, records, sito)

##### build_index_Campioni_de(self, records, sito)

##### build_index_Campioni_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Campioni(self, records, sito)

##### build_box_labels_Campioni_de(self, records, sito)

##### build_box_labels_Campioni_en(self, records, sito)

### NumberedCanvas_Campionisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Campioniindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Campioni_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_campioni_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Champ_sheets(self, records)

##### build_Champ_sheets_de(self, records)

##### build_Champ_sheets_en(self, records)

##### build_index_Campioni(self, records, sito)

##### build_index_Campioni_de(self, records, sito)

##### build_index_Campioni_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Campioni(self, records, sito)

##### build_box_labels_Campioni_de(self, records, sito)

##### build_box_labels_Campioni_en(self, records, sito)

### NumberedCanvas_Campionisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Campioniindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Campioni_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_campioni_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Champ_sheets(self, records)

##### build_Champ_sheets_de(self, records)

##### build_Champ_sheets_en(self, records)

##### build_index_Campioni(self, records, sito)

##### build_index_Campioni_de(self, records, sito)

##### build_index_Campioni_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Campioni(self, records, sito)

##### build_box_labels_Campioni_de(self, records, sito)

##### build_box_labels_Campioni_en(self, records, sito)

### NumberedCanvas_Campionisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Campioniindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Campioni_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### Campioni_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_campioni_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Champ_sheets(self, records)

##### build_Champ_sheets_de(self, records)

##### build_Champ_sheets_en(self, records)

##### build_index_Campioni(self, records, sito)

##### build_index_Campioni_de(self, records, sito)

##### build_index_Campioni_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Campioni(self, records, sito)

##### build_box_labels_Campioni_de(self, records, sito)

##### build_box_labels_Campioni_en(self, records, sito)

