# scripts/insert_ftap_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_ftap_values(cursor)

Inserisce i valori ftap dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_ftap_values(cursor)

Inserisce i valori ftap dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_ftap_values(cursor)

Inserisce i valori ftap dal file Excel.

**Parameters:**
- `cursor`

### main()

