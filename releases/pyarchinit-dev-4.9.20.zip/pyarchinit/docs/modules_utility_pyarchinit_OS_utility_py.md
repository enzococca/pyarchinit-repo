# modules/utility/pyarchinit_OS_utility.py

## Overview

This file contains 36 documented elements.

## Classes

### Pyarchinit_OS_Utility

**Inherits from**: object

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

##### checkgraphvizinstallation()

##### checkpostgresinstallation()

##### isWindows()

##### isMac()

### Pyarchinit_OS_Utility

**Inherits from**: object

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

##### checkgraphvizinstallation()

##### checkpostgresinstallation()

##### isWindows()

##### isMac()

### Pyarchinit_OS_Utility

**Inherits from**: object

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

##### checkgraphvizinstallation()

##### checkpostgresinstallation()

##### isWindows()

##### isMac()

### Pyarchinit_OS_Utility

**Inherits from**: object

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

##### checkgraphvizinstallation()

##### checkpostgresinstallation()

##### isWindows()

##### isMac()

