# scripts/fix_tma_tables.py

## Overview

This file contains 6 documented elements.

## Functions

### create_tma_tables()

Create TMA tables in the correct order

### create_tma_tables()

Create TMA tables in the correct order

### create_tma_tables()

Create TMA tables in the correct order

