# modules/db/entities/PYRIPARTIZIONI_SPAZIALI.py

## Overview

This file contains 16 documented elements.

## Classes

### PYRIPARTIZIONI_SPAZIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rs, sito_rs, tip_rip, descr_rs, the_geom)

##### __repr__(self)

### PYRIPARTIZIONI_SPAZIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rs, sito_rs, tip_rip, descr_rs, the_geom)

##### __repr__(self)

### PYRIPARTIZIONI_SPAZIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rs, sito_rs, tip_rip, descr_rs, the_geom)

##### __repr__(self)

### PYRIPARTIZIONI_SPAZIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rs, sito_rs, tip_rip, descr_rs, the_geom)

##### __repr__(self)

