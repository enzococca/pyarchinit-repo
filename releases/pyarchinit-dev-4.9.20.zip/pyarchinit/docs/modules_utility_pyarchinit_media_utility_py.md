# modules/utility/pyarchinit_media_utility.py

## Overview

This file contains 36 documented elements.

## Classes

### Media_utility

    >> import Image                      # importo il modulo
>>> image_path = r"C:   est\snake.png" # assegno l' immagine alla variabile tramite raw string (r"pathiles")
>>> image = Image.open(image_path)    # apro l'immagine
>>> width, height = (150, 110)        # ridimensiono l'immagine l' originale era 300x350px
>>> size = (width, height)            # assegno grandezza e altezza
>>> new_image_thumbnail = r"C:  est\snake_small.png" # che sia pitone grande o  pitone piccolo l' importante che pitone è
>>> image.thumbnail(size, Image.BICUBIC) # creo la thumbnail vera e propria con antialias ma potevamo anche bicubic bilinear ecc
>>> image.save(new_image_thumbnail)        # salvo la nuova immagine "thumbnail"

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility

    >> import Image                      # importo il modulo
>>> image_path = r"C:   est\snake.png" # assegno l' immagine alla variabile tramite raw string (r"pathiles")
>>> image = Image.open(image_path)    # apro l'immagine
>>> width, height = (150, 110)        # ridimensiono l'immagine l' originale era 300x350px
>>> size = (width, height)            # assegno grandezza e altezza
>>> new_image_thumbnail = r"C:  est\snake_small.png" # che sia pitone grande o  pitone piccolo l' importante che pitone è
>>> image.thumbnail(size, Image.BICUBIC) # creo la thumbnail vera e propria con antialias ma potevamo anche bicubic bilinear ecc
>>> image.save(new_image_thumbnail)        # salvo la nuova immagine "thumbnail"

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility

    >> import Image                      # importo il modulo
>>> image_path = r"C:   est\snake.png" # assegno l' immagine alla variabile tramite raw string (r"pathiles")
>>> image = Image.open(image_path)    # apro l'immagine
>>> width, height = (150, 110)        # ridimensiono l'immagine l' originale era 300x350px
>>> size = (width, height)            # assegno grandezza e altezza
>>> new_image_thumbnail = r"C:  est\snake_small.png" # che sia pitone grande o  pitone piccolo l' importante che pitone è
>>> image.thumbnail(size, Image.BICUBIC) # creo la thumbnail vera e propria con antialias ma potevamo anche bicubic bilinear ecc
>>> image.save(new_image_thumbnail)        # salvo la nuova immagine "thumbnail"

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility

    >> import Image                      # importo il modulo
>>> image_path = r"C:   est\snake.png" # assegno l' immagine alla variabile tramite raw string (r"pathiles")
>>> image = Image.open(image_path)    # apro l'immagine
>>> width, height = (150, 110)        # ridimensiono l'immagine l' originale era 300x350px
>>> size = (width, height)            # assegno grandezza e altezza
>>> new_image_thumbnail = r"C:  est\snake_small.png" # che sia pitone grande o  pitone piccolo l' importante che pitone è
>>> image.thumbnail(size, Image.BICUBIC) # creo la thumbnail vera e propria con antialias ma potevamo anche bicubic bilinear ecc
>>> image.save(new_image_thumbnail)        # salvo la nuova immagine "thumbnail"

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Media_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

### Video_utility_resize

**Inherits from**: object

#### Methods

##### resample_images(self, mid, ip, i, o, ts)

