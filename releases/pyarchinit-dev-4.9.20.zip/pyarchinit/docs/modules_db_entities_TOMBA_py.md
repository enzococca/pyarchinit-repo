# modules/db/entities/TOMBA.py

## Overview

This file contains 16 documented elements.

## Classes

### TOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id_tomba, sito, area, nr_scheda_taf, sigla_struttura, nr_struttura, nr_individuo, rito, descrizione_taf, interpretazione_taf, segnacoli, canale_libatorio_si_no, oggetti_rinvenuti_esterno, stato_di_conservazione, copertura_tipo, tipo_contenitore_resti, tipo_deposizione, tipo_sepoltura, corredo_presenza, corredo_tipo, corredo_descrizione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa)

##### __repr__(self)

### TOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id_tomba, sito, area, nr_scheda_taf, sigla_struttura, nr_struttura, nr_individuo, rito, descrizione_taf, interpretazione_taf, segnacoli, canale_libatorio_si_no, oggetti_rinvenuti_esterno, stato_di_conservazione, copertura_tipo, tipo_contenitore_resti, tipo_deposizione, tipo_sepoltura, corredo_presenza, corredo_tipo, corredo_descrizione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa)

##### __repr__(self)

### TOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id_tomba, sito, area, nr_scheda_taf, sigla_struttura, nr_struttura, nr_individuo, rito, descrizione_taf, interpretazione_taf, segnacoli, canale_libatorio_si_no, oggetti_rinvenuti_esterno, stato_di_conservazione, copertura_tipo, tipo_contenitore_resti, tipo_deposizione, tipo_sepoltura, corredo_presenza, corredo_tipo, corredo_descrizione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa)

##### __repr__(self)

### TOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id_tomba, sito, area, nr_scheda_taf, sigla_struttura, nr_struttura, nr_individuo, rito, descrizione_taf, interpretazione_taf, segnacoli, canale_libatorio_si_no, oggetti_rinvenuti_esterno, stato_di_conservazione, copertura_tipo, tipo_contenitore_resti, tipo_deposizione, tipo_sepoltura, corredo_presenza, corredo_tipo, corredo_descrizione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa)

##### __repr__(self)

