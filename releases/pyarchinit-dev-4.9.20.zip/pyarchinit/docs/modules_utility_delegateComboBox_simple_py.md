# modules/utility/delegateComboBox_simple.py

## Overview

This file contains 32 documented elements.

## Classes

### ComboBoxDelegate

Simple ComboBox delegate with built-in tooltip support

**Inherits from**: QItemDelegate

#### Methods

##### __init__(self, values, parent)

##### def_values(self, values)

##### def_editable(self, editable)

##### createEditor(self, parent, option, index)

##### setEditorData(self, editor, index)

##### setModelData(self, editor, model, index)

### ComboBoxDelegate

Simple ComboBox delegate with built-in tooltip support

**Inherits from**: QItemDelegate

#### Methods

##### __init__(self, values, parent)

##### def_values(self, values)

##### def_editable(self, editable)

##### createEditor(self, parent, option, index)

##### setEditorData(self, editor, index)

##### setModelData(self, editor, model, index)

### ComboBoxDelegate

Simple ComboBox delegate with built-in tooltip support

**Inherits from**: QItemDelegate

#### Methods

##### __init__(self, values, parent)

##### def_values(self, values)

##### def_editable(self, editable)

##### createEditor(self, parent, option, index)

##### setEditorData(self, editor, index)

##### setModelData(self, editor, model, index)

### ComboBoxDelegate

Simple ComboBox delegate with built-in tooltip support

**Inherits from**: QItemDelegate

#### Methods

##### __init__(self, values, parent)

##### def_values(self, values)

##### def_editable(self, editable)

##### createEditor(self, parent, option, index)

##### setEditorData(self, editor, index)

##### setModelData(self, editor, model, index)

