# modules/db/pyarchinit_OS_utility.py

## Overview

This file contains 20 documented elements.

## Classes

### pyarchinit_OS_Utility

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

### pyarchinit_OS_Utility

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

### pyarchinit_OS_Utility

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

### pyarchinit_OS_Utility

#### Methods

##### create_dir(self, d)

##### copy_file_img(self, f, d)

##### copy_file(self, f, d)

