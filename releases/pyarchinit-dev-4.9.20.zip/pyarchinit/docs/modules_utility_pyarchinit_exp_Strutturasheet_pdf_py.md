# modules/utility/pyarchinit_exp_Strutturasheet_pdf.py

## Overview

This file contains 132 documented elements.

## Classes

### NumberedCanvas_STRUTTURAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_STRUTTURAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Struttura_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Struttura_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_struttura_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Struttura_sheets(self, records)

##### build_index_Struttura(self, records, sito)

##### build_Struttura_sheets_de(self, records)

##### build_index_Struttura_de(self, records, sito)

##### build_Struttura_sheets_en(self, records)

##### build_index_Struttura_en(self, records, sito)

### NumberedCanvas_STRUTTURAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_STRUTTURAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Struttura_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Struttura_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_struttura_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Struttura_sheets(self, records)

##### build_index_Struttura(self, records, sito)

##### build_Struttura_sheets_de(self, records)

##### build_index_Struttura_de(self, records, sito)

##### build_Struttura_sheets_en(self, records)

##### build_index_Struttura_en(self, records, sito)

### NumberedCanvas_STRUTTURAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_STRUTTURAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Struttura_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Struttura_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_struttura_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Struttura_sheets(self, records)

##### build_index_Struttura(self, records, sito)

##### build_Struttura_sheets_de(self, records)

##### build_index_Struttura_de(self, records, sito)

##### build_Struttura_sheets_en(self, records)

##### build_index_Struttura_en(self, records, sito)

### NumberedCanvas_STRUTTURAindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_STRUTTURAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### Struttura_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Struttura_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_struttura_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Struttura_sheets(self, records)

##### build_index_Struttura(self, records, sito)

##### build_Struttura_sheets_de(self, records)

##### build_index_Struttura_de(self, records, sito)

##### build_Struttura_sheets_en(self, records)

##### build_index_Struttura_en(self, records, sito)

