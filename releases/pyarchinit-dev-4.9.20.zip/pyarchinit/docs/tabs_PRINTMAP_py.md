# tabs/PRINTMAP.py

## Overview

This file contains 36 documented elements.

## Classes

### pyarchinit_PRINTMAP

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### customize_GUI(self)

##### loadTemplates(self)

##### listMenu(self, position)

##### opentepmplatePreview(self)

##### addMoreTemplates(self)

##### suggestLayoutName(self)

##### layout_exists(self, layout_name)

##### layoutLoader(self, template_source, layout_name, title_text)

Generate the layout 

##### run(self)

Run method that performs all the real work

### pyarchinit_PRINTMAP

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### customize_GUI(self)

##### loadTemplates(self)

##### listMenu(self, position)

##### opentepmplatePreview(self)

##### addMoreTemplates(self)

##### suggestLayoutName(self)

##### layout_exists(self, layout_name)

##### layoutLoader(self, template_source, layout_name, title_text)

Generate the layout 

##### run(self)

Run method that performs all the real work

### pyarchinit_PRINTMAP

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

##### customize_GUI(self)

##### loadTemplates(self)

##### listMenu(self, position)

##### opentepmplatePreview(self)

##### addMoreTemplates(self)

##### suggestLayoutName(self)

##### layout_exists(self, layout_name)

##### layoutLoader(self, template_source, layout_name, title_text)

Generate the layout 

##### run(self)

Run method that performs all the real work

