# examples/festos_import_example.py

## Overview

This file contains 16 documented elements.

## Functions

### import_festos_inventory(docx_file_path)

Importa un inventario Festos da file DOCX

Args:
    docx_file_path: percorso del file DOCX da importare

**Parameters:**
- `docx_file_path`

### batch_import_festos(directory_path)

Importa tutti i file DOCX di inventario Festos da una directory

Args:
    directory_path: percorso della directory contenente i file DOCX

**Parameters:**
- `directory_path`

### test_parser_with_sample()

Test del parser con dati di esempio

### import_festos_inventory(docx_file_path)

Importa un inventario Festos da file DOCX

Args:
    docx_file_path: percorso del file DOCX da importare

**Parameters:**
- `docx_file_path`

### batch_import_festos(directory_path)

Importa tutti i file DOCX di inventario Festos da una directory

Args:
    directory_path: percorso della directory contenente i file DOCX

**Parameters:**
- `directory_path`

### test_parser_with_sample()

Test del parser con dati di esempio

### import_festos_inventory(docx_file_path)

Importa un inventario Festos da file DOCX

Args:
    docx_file_path: percorso del file DOCX da importare

**Parameters:**
- `docx_file_path`

### batch_import_festos(directory_path)

Importa tutti i file DOCX di inventario Festos da una directory

Args:
    directory_path: percorso della directory contenente i file DOCX

**Parameters:**
- `directory_path`

### test_parser_with_sample()

Test del parser con dati di esempio

### import_festos_inventory(docx_file_path)

Importa un inventario Festos da file DOCX

Args:
    docx_file_path: percorso del file DOCX da importare

**Parameters:**
- `docx_file_path`

### batch_import_festos(directory_path)

Importa tutti i file DOCX di inventario Festos da una directory

Args:
    directory_path: percorso della directory contenente i file DOCX

**Parameters:**
- `directory_path`

### test_parser_with_sample()

Test del parser con dati di esempio

