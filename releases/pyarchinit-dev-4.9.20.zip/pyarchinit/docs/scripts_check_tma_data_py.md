# scripts/check_tma_data.py

## Overview

This file contains 9 documented elements.

## Functions

### check_tma_data(db_path)

Verifica i dati nelle tabelle TMA.

**Parameters:**
- `db_path`

### main()

### check_tma_data(db_path)

Verifica i dati nelle tabelle TMA.

**Parameters:**
- `db_path`

### main()

### check_tma_data(db_path)

Verifica i dati nelle tabelle TMA.

**Parameters:**
- `db_path`

### main()

