# install_dialog.py

## Overview

This file contains 20 documented elements.

## Classes

### InstallDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self, packages)

##### initUI(self)

##### install_packages(self)

### InstallDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self, packages)

##### initUI(self)

##### install_packages(self)

### InstallDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self, packages)

##### initUI(self)

##### install_packages(self)

### InstallDialog

**Inherits from**: QDialog

#### Methods

##### __init__(self, packages)

##### initUI(self)

##### install_packages(self)

## Functions

### show_install_dialog(packages)

**Parameters:**
- `packages`

### show_install_dialog(packages)

**Parameters:**
- `packages`

### show_install_dialog(packages)

**Parameters:**
- `packages`

### show_install_dialog(packages)

**Parameters:**
- `packages`

