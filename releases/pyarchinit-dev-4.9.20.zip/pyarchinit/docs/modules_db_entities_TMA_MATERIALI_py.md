# modules/db/entities/TMA_MATERIALI.py

## Overview

This file contains 16 documented elements.

## Classes

### TMA_MATERIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_tma, madi, macc, macl, macp, macd, cronologia_mac, macq, peso, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

### TMA_MATERIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_tma, madi, macc, macl, macp, macd, cronologia_mac, macq, peso, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

### TMA_MATERIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_tma, madi, macc, macl, macp, macd, cronologia_mac, macq, peso, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

### TMA_MATERIALI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_tma, madi, macc, macl, macp, macd, cronologia_mac, macq, peso, created_at, updated_at, created_by, updated_by)

##### __repr__(self)

