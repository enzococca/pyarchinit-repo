# modules/utility/print_relazione_pdf.py

## Overview

This file contains 60 documented elements.

## Classes

### NumberedCanvas_Relazione

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### exp_rel_pdf

**Inherits from**: object

#### Methods

##### __init__(self, sito)

##### connection_db(self)

##### search_records(self, f, v, m)

##### extract_id_list(self, rec, idf)

##### load_data_sorted(self, id_list, sort_fields_list, sort_mode, mapper_table_class, id_table)

##### myFirstPage(self, canvas, doc)

##### export_rel_pdf(self)

### NumberedCanvas_Relazione

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### exp_rel_pdf

**Inherits from**: object

#### Methods

##### __init__(self, sito)

##### connection_db(self)

##### search_records(self, f, v, m)

##### extract_id_list(self, rec, idf)

##### load_data_sorted(self, id_list, sort_fields_list, sort_mode, mapper_table_class, id_table)

##### myFirstPage(self, canvas, doc)

##### export_rel_pdf(self)

### NumberedCanvas_Relazione

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### exp_rel_pdf

**Inherits from**: object

#### Methods

##### __init__(self, sito)

##### connection_db(self)

##### search_records(self, f, v, m)

##### extract_id_list(self, rec, idf)

##### load_data_sorted(self, id_list, sort_fields_list, sort_mode, mapper_table_class, id_table)

##### myFirstPage(self, canvas, doc)

##### export_rel_pdf(self)

### NumberedCanvas_Relazione

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### exp_rel_pdf

**Inherits from**: object

#### Methods

##### __init__(self, sito)

##### connection_db(self)

##### search_records(self, f, v, m)

##### extract_id_list(self, rec, idf)

##### load_data_sorted(self, id_list, sort_fields_list, sort_mode, mapper_table_class, id_table)

##### myFirstPage(self, canvas, doc)

##### export_rel_pdf(self)

