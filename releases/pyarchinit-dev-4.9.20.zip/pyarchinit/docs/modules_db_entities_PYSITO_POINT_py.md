# modules/db/entities/PYSITO_POINT.py

## Overview

This file contains 16 documented elements.

## Classes

### PYSITO_POINT

**Inherits from**: object

#### Methods

##### __init__(self, gid, sito_nome, the_geom)

##### __repr__(self)

### PYSITO_POINT

**Inherits from**: object

#### Methods

##### __init__(self, gid, sito_nome, the_geom)

##### __repr__(self)

### PYSITO_POINT

**Inherits from**: object

#### Methods

##### __init__(self, gid, sito_nome, the_geom)

##### __repr__(self)

### PYSITO_POINT

**Inherits from**: object

#### Methods

##### __init__(self, gid, sito_nome, the_geom)

##### __repr__(self)

