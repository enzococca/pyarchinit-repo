# modules/db/structures_metadata/pysezioni.py

## Overview

This file contains 12 documented elements.

## Classes

### pysezioni

#### Methods

##### define_table(cls, metadata)

### pysezioni

#### Methods

##### define_table(cls, metadata)

### pysezioni

#### Methods

##### define_table(cls, metadata)

### pysezioni

#### Methods

##### define_table(cls, metadata)

