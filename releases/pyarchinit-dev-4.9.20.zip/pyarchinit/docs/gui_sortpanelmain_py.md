# gui/sortpanelmain.py

## Overview

This file contains 32 documented elements.

## Classes

### SortPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### closeEvent(self, event)

##### on_pushButtonSort_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

### SortPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### closeEvent(self, event)

##### on_pushButtonSort_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

### SortPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### closeEvent(self, event)

##### on_pushButtonSort_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

### SortPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### closeEvent(self, event)

##### on_pushButtonSort_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

