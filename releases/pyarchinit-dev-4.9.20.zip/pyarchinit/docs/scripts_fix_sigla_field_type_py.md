# scripts/fix_sigla_field_type.py

## Overview

This file contains 9 documented elements.

## Functions

### fix_sigla_field(host, port, dbname, user, password)

Sistema il tipo del campo sigla e rimuove gli spazi.

**Parameters:**
- `host`
- `port`
- `dbname`
- `user`
- `password`

### main()

### fix_sigla_field(host, port, dbname, user, password)

Sistema il tipo del campo sigla e rimuove gli spazi.

**Parameters:**
- `host`
- `port`
- `dbname`
- `user`
- `password`

### main()

### fix_sigla_field(host, port, dbname, user, password)

Sistema il tipo del campo sigla e rimuove gli spazi.

**Parameters:**
- `host`
- `port`
- `dbname`
- `user`
- `password`

### main()

