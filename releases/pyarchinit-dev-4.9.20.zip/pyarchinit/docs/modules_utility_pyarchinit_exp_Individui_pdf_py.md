# modules/utility/pyarchinit_exp_Individui_pdf.py

## Overview

This file contains 132 documented elements.

## Classes

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Individuiindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

##### draw_page_number(self, page_count)

### Individui_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Individui_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

##### build_Individui_sheets_de(self, records)

##### build_Individui_sheets_en(self, records)

##### build_index_individui(self, records, sito)

##### build_index_individui_de(self, records, sito)

##### build_index_individui_en(self, records, sito)

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Individuiindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

##### draw_page_number(self, page_count)

### Individui_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Individui_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

##### build_Individui_sheets_de(self, records)

##### build_Individui_sheets_en(self, records)

##### build_index_individui(self, records, sito)

##### build_index_individui_de(self, records, sito)

##### build_index_individui_en(self, records, sito)

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Individuiindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

##### draw_page_number(self, page_count)

### Individui_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Individui_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

##### build_Individui_sheets_de(self, records)

##### build_Individui_sheets_en(self, records)

##### build_index_individui(self, records, sito)

##### build_index_individui_de(self, records, sito)

##### build_index_individui_en(self, records, sito)

### NumberedCanvas_Individuisheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Individuiindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

##### draw_page_number(self, page_count)

### Individui_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### single_Individui_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Individui_sheets(self, records)

##### build_Individui_sheets_de(self, records)

##### build_Individui_sheets_en(self, records)

##### build_index_individui(self, records, sito)

##### build_index_individui_de(self, records, sito)

##### build_index_individui_en(self, records, sito)

