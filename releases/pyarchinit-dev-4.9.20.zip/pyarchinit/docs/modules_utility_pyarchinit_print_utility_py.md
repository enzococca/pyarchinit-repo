# modules/utility/pyarchinit_print_utility.py

## Overview

This file contains 52 documented elements.

## Classes

### Print_utility

**Inherits from**: QObject

#### Methods

##### __init__(self, iface, data)

##### first_batch_try(self, server)

##### converter_1_20(self, n)

##### test_bbox(self)

##### getMapExtentFromMapCanvas(self, mapWidth, mapHeight, scale)

##### print_map(self, tav_num)

##### open_connection_postgis(self)

##### open_connection_sqlite(self)

##### remove_layer(self)

##### charge_layer_sqlite(self, sito, area, us)

##### charge_layer_postgis(self, sito, area, us)

### Print_utility

**Inherits from**: QObject

#### Methods

##### __init__(self, iface, data)

##### first_batch_try(self, server)

##### converter_1_20(self, n)

##### test_bbox(self)

##### getMapExtentFromMapCanvas(self, mapWidth, mapHeight, scale)

##### print_map(self, tav_num)

##### open_connection_postgis(self)

##### open_connection_sqlite(self)

##### remove_layer(self)

##### charge_layer_sqlite(self, sito, area, us)

##### charge_layer_postgis(self, sito, area, us)

### Print_utility

**Inherits from**: QObject

#### Methods

##### __init__(self, iface, data)

##### first_batch_try(self, server)

##### converter_1_20(self, n)

##### test_bbox(self)

##### getMapExtentFromMapCanvas(self, mapWidth, mapHeight, scale)

##### print_map(self, tav_num)

##### open_connection_postgis(self)

##### open_connection_sqlite(self)

##### remove_layer(self)

##### charge_layer_sqlite(self, sito, area, us)

##### charge_layer_postgis(self, sito, area, us)

### Print_utility

**Inherits from**: QObject

#### Methods

##### __init__(self, iface, data)

##### first_batch_try(self, server)

##### converter_1_20(self, n)

##### test_bbox(self)

##### getMapExtentFromMapCanvas(self, mapWidth, mapHeight, scale)

##### print_map(self, tav_num)

##### open_connection_postgis(self)

##### open_connection_sqlite(self)

##### remove_layer(self)

##### charge_layer_sqlite(self, sito, area, us)

##### charge_layer_postgis(self, sito, area, us)

