# verify_and_fix_tma_tipologia_codes.py

## Overview

This file contains 6 documented elements.

## Functions

### verify_tipologia_codes()

Verifica i codici tipologia attualmente nel database.

### verify_tipologia_codes()

Verifica i codici tipologia attualmente nel database.

### verify_tipologia_codes()

Verifica i codici tipologia attualmente nel database.

