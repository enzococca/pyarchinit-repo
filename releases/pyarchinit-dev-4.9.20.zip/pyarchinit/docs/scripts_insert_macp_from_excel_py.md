# scripts/insert_macp_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_macp_values(cursor)

Inserisce i valori macp dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_macp_values(cursor)

Inserisce i valori macp dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_macp_values(cursor)

Inserisce i valori macp dal file Excel.

**Parameters:**
- `cursor`

### main()

