# gui/pyarchinitInfoDialog.py

## Overview

This file contains 16 documented elements.

## Classes

### pyArchInitDialog_Info

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### open_link(self, url)

### pyArchInitDialog_Info

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### open_link(self, url)

### pyArchInitDialog_Info

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### open_link(self, url)

### pyArchInitDialog_Info

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### open_link(self, url)

