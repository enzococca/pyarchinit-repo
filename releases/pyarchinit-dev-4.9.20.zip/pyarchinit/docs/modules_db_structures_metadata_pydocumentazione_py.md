# modules/db/structures_metadata/pydocumentazione.py

## Overview

This file contains 12 documented elements.

## Classes

### pydocumentazione

#### Methods

##### define_table(cls, metadata)

### pydocumentazione

#### Methods

##### define_table(cls, metadata)

### pydocumentazione

#### Methods

##### define_table(cls, metadata)

### pydocumentazione

#### Methods

##### define_table(cls, metadata)

