# gui/ui/mplwidgetmatrix.py

## Overview

This file contains 20 documented elements.

## Classes

### MplCanvas

**Inherits from**: FigureCanvas

#### Methods

##### __init__(self)

### MplwidgetMatrix

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

### MplCanvas

**Inherits from**: FigureCanvas

#### Methods

##### __init__(self)

### MplwidgetMatrix

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

### MplCanvas

**Inherits from**: FigureCanvas

#### Methods

##### __init__(self)

### MplwidgetMatrix

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

### MplCanvas

**Inherits from**: FigureCanvas

#### Methods

##### __init__(self)

### MplwidgetMatrix

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

