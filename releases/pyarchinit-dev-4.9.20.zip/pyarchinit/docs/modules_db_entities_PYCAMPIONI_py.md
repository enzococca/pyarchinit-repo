# modules/db/entities/PYCAMPIONI.py

## Overview

This file contains 16 documented elements.

## Classes

### PYCAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_campion, sito, tipo_camp, dataz, cronologia, link_immag, sigla_camp, the_geom)

##### __repr__(self)

### PYCAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_campion, sito, tipo_camp, dataz, cronologia, link_immag, sigla_camp, the_geom)

##### __repr__(self)

### PYCAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_campion, sito, tipo_camp, dataz, cronologia, link_immag, sigla_camp, the_geom)

##### __repr__(self)

### PYCAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_campion, sito, tipo_camp, dataz, cronologia, link_immag, sigla_camp, the_geom)

##### __repr__(self)

