# modules/db/structures_metadata/pyquote_usm.py

## Overview

This file contains 12 documented elements.

## Classes

### pyquote_usm

#### Methods

##### define_table(cls, metadata)

### pyquote_usm

#### Methods

##### define_table(cls, metadata)

### pyquote_usm

#### Methods

##### define_table(cls, metadata)

### pyquote_usm

#### Methods

##### define_table(cls, metadata)

