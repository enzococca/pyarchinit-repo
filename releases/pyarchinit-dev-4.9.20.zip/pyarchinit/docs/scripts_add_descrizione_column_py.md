# scripts/add_descrizione_column.py

## Overview

This file contains 9 documented elements.

## Functions

### add_descrizione_column(db_path)

Aggiunge la colonna descrizione se non esiste.

**Parameters:**
- `db_path`

### main()

### add_descrizione_column(db_path)

Aggiunge la colonna descrizione se non esiste.

**Parameters:**
- `db_path`

### main()

### add_descrizione_column(db_path)

Aggiunge la colonna descrizione se non esiste.

**Parameters:**
- `db_path`

### main()

