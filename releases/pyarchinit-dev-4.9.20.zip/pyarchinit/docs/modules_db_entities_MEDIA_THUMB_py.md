# modules/db/entities/MEDIA_THUMB.py

## Overview

This file contains 16 documented elements.

## Classes

### MEDIA_THUMB

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, mediatype, media_filename, media_thumb_filename, filetype, filepath, path_resize)

##### __repr__(self)

### MEDIA_THUMB

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, mediatype, media_filename, media_thumb_filename, filetype, filepath, path_resize)

##### __repr__(self)

### MEDIA_THUMB

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, mediatype, media_filename, media_thumb_filename, filetype, filepath, path_resize)

##### __repr__(self)

### MEDIA_THUMB

**Inherits from**: object

#### Methods

##### __init__(self, id_media_thumb, id_media, mediatype, media_filename, media_thumb_filename, filetype, filepath, path_resize)

##### __repr__(self)

