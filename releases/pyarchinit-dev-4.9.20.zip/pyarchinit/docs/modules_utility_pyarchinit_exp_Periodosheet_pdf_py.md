# modules/utility/pyarchinit_exp_Periodosheet_pdf.py

## Overview

This file contains 112 documented elements.

## Classes

### NumberedCanvas_USsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_US_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### unzip_documentazione(self)

##### datestrfdate(self)

##### create_sheet(self)

### US_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### getTable(self)

##### makeStyles(self)

### generate_US_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_US_sheets(self, records)

##### build_index_US(self, records, sito)

### NumberedCanvas_USsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_US_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### unzip_documentazione(self)

##### datestrfdate(self)

##### create_sheet(self)

### US_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### getTable(self)

##### makeStyles(self)

### generate_US_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_US_sheets(self, records)

##### build_index_US(self, records, sito)

### NumberedCanvas_USsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_US_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### unzip_documentazione(self)

##### datestrfdate(self)

##### create_sheet(self)

### US_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### getTable(self)

##### makeStyles(self)

### generate_US_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_US_sheets(self, records)

##### build_index_US(self, records, sito)

### NumberedCanvas_USsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_US_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### unzip_documentazione(self)

##### datestrfdate(self)

##### create_sheet(self)

### US_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### unzip_rapporti_stratigrafici(self)

##### getTable(self)

##### makeStyles(self)

### generate_US_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_US_sheets(self, records)

##### build_index_US(self, records, sito)

