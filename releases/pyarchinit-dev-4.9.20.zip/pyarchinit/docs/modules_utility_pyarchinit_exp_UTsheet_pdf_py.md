# modules/utility/pyarchinit_exp_UTsheet_pdf.py

## Overview

This file contains 104 documented elements.

## Classes

### NumberedCanvas_UTsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_UTindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_UT_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

##### getTable(self)

##### makeStyles(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_UT_sheets(self, records)

##### build_UT_sheets_de(self, records)

##### build_UT_sheets_en(self, records)

### NumberedCanvas_UTsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_UTindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_UT_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

##### getTable(self)

##### makeStyles(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_UT_sheets(self, records)

##### build_UT_sheets_de(self, records)

##### build_UT_sheets_en(self, records)

### NumberedCanvas_UTsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_UTindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_UT_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

##### getTable(self)

##### makeStyles(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_UT_sheets(self, records)

##### build_UT_sheets_de(self, records)

##### build_UT_sheets_en(self, records)

### NumberedCanvas_UTsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_UTindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_UT_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

##### getTable(self)

##### makeStyles(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_UT_sheets(self, records)

##### build_UT_sheets_de(self, records)

##### build_UT_sheets_en(self, records)

