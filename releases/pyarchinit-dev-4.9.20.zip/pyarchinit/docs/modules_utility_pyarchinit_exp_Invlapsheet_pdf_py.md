# modules/utility/pyarchinit_exp_Invlapsheet_pdf.py

## Overview

This file contains 72 documented elements.

## Classes

### NumberedCanvas_Invlapsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Invlap_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_reperti_pdf

#### Methods

##### datestrfdate(self)

##### build_Invlap_sheets(self, records)

##### build_Invlap_sheets_de(self, records)

##### build_Invlap_sheets_en(self, records)

### NumberedCanvas_Invlapsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Invlap_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_reperti_pdf

#### Methods

##### datestrfdate(self)

##### build_Invlap_sheets(self, records)

##### build_Invlap_sheets_de(self, records)

##### build_Invlap_sheets_en(self, records)

### NumberedCanvas_Invlapsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Invlap_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_reperti_pdf

#### Methods

##### datestrfdate(self)

##### build_Invlap_sheets(self, records)

##### build_Invlap_sheets_de(self, records)

##### build_Invlap_sheets_en(self, records)

### NumberedCanvas_Invlapsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Invlap_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### generate_reperti_pdf

#### Methods

##### datestrfdate(self)

##### build_Invlap_sheets(self, records)

##### build_Invlap_sheets_de(self, records)

##### build_Invlap_sheets_en(self, records)

