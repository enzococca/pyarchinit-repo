# scripts/verify_tma_persistence.py

## Overview

This file contains 12 documented elements.

## Functions

### monitor_tma_data(db_path, interval, duration)

Monitora i dati TMA per vedere se vengono cancellati.

**Parameters:**
- `db_path`
- `interval`
- `duration`

### show_final_state(db_path)

Mostra lo stato finale del database.

**Parameters:**
- `db_path`

### main()

### monitor_tma_data(db_path, interval, duration)

Monitora i dati TMA per vedere se vengono cancellati.

**Parameters:**
- `db_path`
- `interval`
- `duration`

### show_final_state(db_path)

Mostra lo stato finale del database.

**Parameters:**
- `db_path`

### main()

### monitor_tma_data(db_path, interval, duration)

Monitora i dati TMA per vedere se vengono cancellati.

**Parameters:**
- `db_path`
- `interval`
- `duration`

### show_final_state(db_path)

Mostra lo stato finale del database.

**Parameters:**
- `db_path`

### main()

