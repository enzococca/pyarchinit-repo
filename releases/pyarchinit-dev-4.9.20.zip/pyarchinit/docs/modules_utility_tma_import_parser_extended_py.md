# modules/utility/tma_import_parser_extended.py

## Overview

This file contains 16 documented elements.

## Classes

### TMAImportManagerExtended

Manager esteso che supporta inventari

**Inherits from**: TMAImportManager

#### Methods

##### __init__(self, db_manager)

##### import_file(self, file_path, custom_mapping, use_festos_parser)

Override del metodo import_file per gestire inventari DOCX

### TMAImportManagerExtended

Manager esteso che supporta inventari

**Inherits from**: TMAImportManager

#### Methods

##### __init__(self, db_manager)

##### import_file(self, file_path, custom_mapping, use_festos_parser)

Override del metodo import_file per gestire inventari DOCX

### TMAImportManagerExtended

Manager esteso che supporta inventari

**Inherits from**: TMAImportManager

#### Methods

##### __init__(self, db_manager)

##### import_file(self, file_path, custom_mapping, use_festos_parser)

Override del metodo import_file per gestire inventari DOCX

### TMAImportManagerExtended

Manager esteso che supporta inventari

**Inherits from**: TMAImportManager

#### Methods

##### __init__(self, db_manager)

##### import_file(self, file_path, custom_mapping, use_festos_parser)

Override del metodo import_file per gestire inventari DOCX

