# watch_and_update.py

## Overview

This file contains 18 documented elements.

## Classes

### DocUpdateHandler

**Inherits from**: FileSystemEventHandler

#### Methods

##### __init__(self, project_path)

##### on_modified(self, event)

##### update_documentation(self)

### DocUpdateHandler

**Inherits from**: FileSystemEventHandler

#### Methods

##### __init__(self, project_path)

##### on_modified(self, event)

##### update_documentation(self)

### DocUpdateHandler

**Inherits from**: FileSystemEventHandler

#### Methods

##### __init__(self, project_path)

##### on_modified(self, event)

##### update_documentation(self)

## Functions

### main()

### main()

### main()

