# modules/db/entities/PYLINEERIFERIMENTO.py

## Overview

This file contains 16 documented elements.

## Classes

### PYLINEERIFERIMENTO

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, definizion, descrizion, the_geom)

##### __repr__(self)

### PYLINEERIFERIMENTO

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, definizion, descrizion, the_geom)

##### __repr__(self)

### PYLINEERIFERIMENTO

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, definizion, descrizion, the_geom)

##### __repr__(self)

### PYLINEERIFERIMENTO

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, definizion, descrizion, the_geom)

##### __repr__(self)

