# modules/db/structures_metadata/Pottery_table.py

## Overview

This file contains 12 documented elements.

## Classes

### PotteryTable

#### Methods

##### define_table(cls, metadata)

### PotteryTable

#### Methods

##### define_table(cls, metadata)

### PotteryTable

#### Methods

##### define_table(cls, metadata)

### PotteryTable

#### Methods

##### define_table(cls, metadata)

