# modules/db/structures_metadata/DETETA_table.py

## Overview

This file contains 12 documented elements.

## Classes

### DETETA_table

#### Methods

##### define_table(cls, metadata)

### DETETA_table

#### Methods

##### define_table(cls, metadata)

### DETETA_table

#### Methods

##### define_table(cls, metadata)

### DETETA_table

#### Methods

##### define_table(cls, metadata)

