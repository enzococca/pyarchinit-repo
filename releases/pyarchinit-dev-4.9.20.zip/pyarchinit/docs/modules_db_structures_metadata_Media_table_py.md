# modules/db/structures_metadata/Media_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Media_table

#### Methods

##### define_table(cls, metadata)

### Media_table

#### Methods

##### define_table(cls, metadata)

### Media_table

#### Methods

##### define_table(cls, metadata)

### Media_table

#### Methods

##### define_table(cls, metadata)

