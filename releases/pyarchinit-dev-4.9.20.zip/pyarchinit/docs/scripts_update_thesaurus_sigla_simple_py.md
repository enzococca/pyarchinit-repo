# scripts/update_thesaurus_sigla_simple.py

## Overview

This file contains 9 documented elements.

## Functions

### backup_and_recreate(db_path)

Backup dei dati e ricreazione tabella.

**Parameters:**
- `db_path`

### main()

### backup_and_recreate(db_path)

Backup dei dati e ricreazione tabella.

**Parameters:**
- `db_path`

### main()

### backup_and_recreate(db_path)

Backup dei dati e ricreazione tabella.

**Parameters:**
- `db_path`

### main()

