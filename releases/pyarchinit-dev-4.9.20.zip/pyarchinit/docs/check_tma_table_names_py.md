# check_tma_table_names.py

## Overview

This file contains 8 documented elements.

## Functions

### check_tma_table_names()

Check the table names used in TMA thesaurus records

### check_tma_table_names()

Check the table names used in TMA thesaurus records

### check_tma_table_names()

Check the table names used in TMA thesaurus records

### check_tma_table_names()

Check the table names used in TMA thesaurus records

