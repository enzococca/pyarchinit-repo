# scripts/insert_dtzg_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_dtzg_values(cursor)

Inserisce i valori dtzg dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_dtzg_values(cursor)

Inserisce i valori dtzg dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_dtzg_values(cursor)

Inserisce i valori dtzg dal file Excel.

**Parameters:**
- `cursor`

### main()

