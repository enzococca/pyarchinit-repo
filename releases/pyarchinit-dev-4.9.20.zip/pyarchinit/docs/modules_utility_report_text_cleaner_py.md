# modules/utility/report_text_cleaner.py

## Overview

This file contains 20 documented elements.

## Classes

### ReportTextCleaner

Pulisce e riformatta il testo generato dall'AI per una migliore formattazione Word

#### Methods

##### clean_report_text(text)

Pulisce il testo del report rimuovendo formattazioni problematiche

Args:
    text: Testo del report generato dall'AI

Returns:
    Testo pulito e riformattato

##### clean_section_content(section_name, content)

Pulisce il contenuto di una sezione specifica

Args:
    section_name: Nome della sezione
    content: Contenuto della sezione

Returns:
    Contenuto pulito

##### prepare_for_docx(text)

Prepara il testo per l'inserimento in un documento Word

Args:
    text: Testo da preparare

Returns:
    Dictionary con il testo suddiviso in paragrafi e metadata

### ReportTextCleaner

Pulisce e riformatta il testo generato dall'AI per una migliore formattazione Word

#### Methods

##### clean_report_text(text)

Pulisce il testo del report rimuovendo formattazioni problematiche

Args:
    text: Testo del report generato dall'AI

Returns:
    Testo pulito e riformattato

##### clean_section_content(section_name, content)

Pulisce il contenuto di una sezione specifica

Args:
    section_name: Nome della sezione
    content: Contenuto della sezione

Returns:
    Contenuto pulito

##### prepare_for_docx(text)

Prepara il testo per l'inserimento in un documento Word

Args:
    text: Testo da preparare

Returns:
    Dictionary con il testo suddiviso in paragrafi e metadata

### ReportTextCleaner

Pulisce e riformatta il testo generato dall'AI per una migliore formattazione Word

#### Methods

##### clean_report_text(text)

Pulisce il testo del report rimuovendo formattazioni problematiche

Args:
    text: Testo del report generato dall'AI

Returns:
    Testo pulito e riformattato

##### clean_section_content(section_name, content)

Pulisce il contenuto di una sezione specifica

Args:
    section_name: Nome della sezione
    content: Contenuto della sezione

Returns:
    Contenuto pulito

##### prepare_for_docx(text)

Prepara il testo per l'inserimento in un documento Word

Args:
    text: Testo da preparare

Returns:
    Dictionary con il testo suddiviso in paragrafi e metadata

### ReportTextCleaner

Pulisce e riformatta il testo generato dall'AI per una migliore formattazione Word

#### Methods

##### clean_report_text(text)

Pulisce il testo del report rimuovendo formattazioni problematiche

Args:
    text: Testo del report generato dall'AI

Returns:
    Testo pulito e riformattato

##### clean_section_content(section_name, content)

Pulisce il contenuto di una sezione specifica

Args:
    section_name: Nome della sezione
    content: Contenuto della sezione

Returns:
    Contenuto pulito

##### prepare_for_docx(text)

Prepara il testo per l'inserimento in un documento Word

Args:
    text: Testo da preparare

Returns:
    Dictionary con il testo suddiviso in paragrafi e metadata

