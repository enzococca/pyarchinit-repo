# scripts/insert_macl_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_macl_values(cursor)

Inserisce i valori macl dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_macl_values(cursor)

Inserisce i valori macl dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_macl_values(cursor)

Inserisce i valori macl dal file Excel.

**Parameters:**
- `cursor`

### main()

