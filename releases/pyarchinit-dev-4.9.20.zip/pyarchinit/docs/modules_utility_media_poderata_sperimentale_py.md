# modules/utility/media_poderata_sperimentale.py

## Overview

This file contains 36 documented elements.

## Classes

### Cronology_convertion

#### Methods

##### sum_list_of_tuples_for_value(self, l)

##### convert_data(self, datazione_reperto)

##### found_intervallo_per_forma(self, data)

##### calc_percent(self, val_parz, val_totale)

##### media_ponderata_perc_intervallo(self, lista_dati, valore)

##### totale_forme_min(self, data)

##### intervallo_numerico(self, lista_intervalli_cron_i_f)

##### check_value_parz_in_rif_value(self, val_parz, val_rif)

### Cronology_convertion

#### Methods

##### sum_list_of_tuples_for_value(self, l)

##### convert_data(self, datazione_reperto)

##### found_intervallo_per_forma(self, data)

##### calc_percent(self, val_parz, val_totale)

##### media_ponderata_perc_intervallo(self, lista_dati, valore)

##### totale_forme_min(self, data)

##### intervallo_numerico(self, lista_intervalli_cron_i_f)

##### check_value_parz_in_rif_value(self, val_parz, val_rif)

### Cronology_convertion

#### Methods

##### sum_list_of_tuples_for_value(self, l)

##### convert_data(self, datazione_reperto)

##### found_intervallo_per_forma(self, data)

##### calc_percent(self, val_parz, val_totale)

##### media_ponderata_perc_intervallo(self, lista_dati, valore)

##### totale_forme_min(self, data)

##### intervallo_numerico(self, lista_intervalli_cron_i_f)

##### check_value_parz_in_rif_value(self, val_parz, val_rif)

### Cronology_convertion

#### Methods

##### sum_list_of_tuples_for_value(self, l)

##### convert_data(self, datazione_reperto)

##### found_intervallo_per_forma(self, data)

##### calc_percent(self, val_parz, val_totale)

##### media_ponderata_perc_intervallo(self, lista_dati, valore)

##### totale_forme_min(self, data)

##### intervallo_numerico(self, lista_intervalli_cron_i_f)

##### check_value_parz_in_rif_value(self, val_parz, val_rif)

