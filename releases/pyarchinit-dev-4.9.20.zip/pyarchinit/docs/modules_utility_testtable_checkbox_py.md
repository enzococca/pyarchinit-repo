# modules/utility/testtable_checkbox.py

## Overview

This file contains 16 documented elements.

## Classes

### Window

**Inherits from**: QWidget

#### Methods

##### __init__(self, rows, columns)

##### handleItemClicked(self, item)

### Window

**Inherits from**: QWidget

#### Methods

##### __init__(self, rows, columns)

##### handleItemClicked(self, item)

### Window

**Inherits from**: QWidget

#### Methods

##### __init__(self, rows, columns)

##### handleItemClicked(self, item)

### Window

**Inherits from**: QWidget

#### Methods

##### __init__(self, rows, columns)

##### handleItemClicked(self, item)

