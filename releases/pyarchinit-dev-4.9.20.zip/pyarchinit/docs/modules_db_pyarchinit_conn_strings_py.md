# modules/db/pyarchinit_conn_strings.py

## Overview

This file contains 68 documented elements.

## Classes

### PyArchInitConnLogger

Simple file logger for connection operations

#### Methods

##### __init__(self)

##### log(self, message)

Write a log message with timestamp

##### log_exception(self, exc, context)

Log an exception with traceback

### Connection

**Inherits from**: object

#### Methods

##### __init__(self)

##### conn_str(self)

##### databasename(self)

##### datauser(self)

##### datahost(self)

##### dataport(self)

##### datapassword(self)

##### thumb_path(self)

##### thumb_resize(self)

##### sito_set(self)

##### logo_path(self)

### PyArchInitConnLogger

Simple file logger for connection operations

#### Methods

##### __init__(self)

##### log(self, message)

Write a log message with timestamp

##### log_exception(self, exc, context)

Log an exception with traceback

### Connection

**Inherits from**: object

#### Methods

##### __init__(self)

##### conn_str(self)

##### databasename(self)

##### datauser(self)

##### datahost(self)

##### dataport(self)

##### datapassword(self)

##### thumb_path(self)

##### thumb_resize(self)

##### sito_set(self)

##### logo_path(self)

### PyArchInitConnLogger

Simple file logger for connection operations

#### Methods

##### __init__(self)

##### log(self, message)

Write a log message with timestamp

##### log_exception(self, exc, context)

Log an exception with traceback

### Connection

**Inherits from**: object

#### Methods

##### __init__(self)

##### conn_str(self)

##### databasename(self)

##### datauser(self)

##### datahost(self)

##### dataport(self)

##### datapassword(self)

##### thumb_path(self)

##### thumb_resize(self)

##### sito_set(self)

##### logo_path(self)

### PyArchInitConnLogger

Simple file logger for connection operations

#### Methods

##### __init__(self)

##### log(self, message)

Write a log message with timestamp

##### log_exception(self, exc, context)

Log an exception with traceback

### Connection

**Inherits from**: object

#### Methods

##### __init__(self)

##### conn_str(self)

##### databasename(self)

##### datauser(self)

##### datahost(self)

##### dataport(self)

##### datapassword(self)

##### thumb_path(self)

##### thumb_resize(self)

##### sito_set(self)

##### logo_path(self)

