# modules/db/entities/SITE.py

## Overview

This file contains 16 documented elements.

## Classes

### SITE

**Inherits from**: object

#### Methods

##### __init__(self, id_sito, sito, nazione, regione, comune, descrizione, provincia, definizione_sito, sito_path, find_check)

##### __repr__(self)

### SITE

**Inherits from**: object

#### Methods

##### __init__(self, id_sito, sito, nazione, regione, comune, descrizione, provincia, definizione_sito, sito_path, find_check)

##### __repr__(self)

### SITE

**Inherits from**: object

#### Methods

##### __init__(self, id_sito, sito, nazione, regione, comune, descrizione, provincia, definizione_sito, sito_path, find_check)

##### __repr__(self)

### SITE

**Inherits from**: object

#### Methods

##### __init__(self, id_sito, sito, nazione, regione, comune, descrizione, provincia, definizione_sito, sito_path, find_check)

##### __repr__(self)

