# searchLayers.py

## Overview

This file contains 15 documented elements.

## Classes

### SearchLayers

#### Methods

##### __init__(self, iface)

##### initGui(self)

##### showSearchDialog(self)

### SearchLayers

#### Methods

##### __init__(self, iface)

##### initGui(self)

##### showSearchDialog(self)

### SearchLayers

#### Methods

##### __init__(self, iface)

##### initGui(self)

##### showSearchDialog(self)

