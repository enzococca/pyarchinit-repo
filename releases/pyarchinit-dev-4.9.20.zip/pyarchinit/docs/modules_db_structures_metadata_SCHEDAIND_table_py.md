# modules/db/structures_metadata/SCHEDAIND_table.py

## Overview

This file contains 12 documented elements.

## Classes

### SCHEDAIND_table

#### Methods

##### define_table(cls, metadata)

### SCHEDAIND_table

#### Methods

##### define_table(cls, metadata)

### SCHEDAIND_table

#### Methods

##### define_table(cls, metadata)

### SCHEDAIND_table

#### Methods

##### define_table(cls, metadata)

