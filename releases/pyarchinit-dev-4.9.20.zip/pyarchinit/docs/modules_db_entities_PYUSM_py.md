# modules/db/entities/PYUSM.py

## Overview

This file contains 16 documented elements.

## Classes

### PYUSM

**Inherits from**: object

#### Methods

##### __init__(self, gid, area_s, scavo_s, us_s, stratigraph_index_us, tipo_us_s, rilievo_originale, disegnatore, data, tipo_doc, nome_doc, coord, the_geom, unita_tipo_s)

##### __repr__(self)

### PYUSM

**Inherits from**: object

#### Methods

##### __init__(self, gid, area_s, scavo_s, us_s, stratigraph_index_us, tipo_us_s, rilievo_originale, disegnatore, data, tipo_doc, nome_doc, coord, the_geom, unita_tipo_s)

##### __repr__(self)

### PYUSM

**Inherits from**: object

#### Methods

##### __init__(self, gid, area_s, scavo_s, us_s, stratigraph_index_us, tipo_us_s, rilievo_originale, disegnatore, data, tipo_doc, nome_doc, coord, the_geom, unita_tipo_s)

##### __repr__(self)

### PYUSM

**Inherits from**: object

#### Methods

##### __init__(self, gid, area_s, scavo_s, us_s, stratigraph_index_us, tipo_us_s, rilievo_originale, disegnatore, data, tipo_doc, nome_doc, coord, the_geom, unita_tipo_s)

##### __repr__(self)

