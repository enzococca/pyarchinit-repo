# resources/dbfiles/dottoxml_original.py

## Overview

This file contains 28 documented elements.

## Functions

### usage()

### exportDot(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGML(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGraphml(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGDF(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### main()

### usage()

### exportDot(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGML(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGraphml(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGDF(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### main()

### usage()

### exportDot(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGML(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGraphml(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGDF(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### main()

### usage()

### exportDot(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGML(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGraphml(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### exportGDF(o, nodes, edges, options)

**Parameters:**
- `o`
- `nodes`
- `edges`
- `options`

### main()

