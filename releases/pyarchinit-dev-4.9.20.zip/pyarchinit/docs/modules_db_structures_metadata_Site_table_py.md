# modules/db/structures_metadata/Site_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Site_table

#### Methods

##### define_table(cls, metadata)

### Site_table

#### Methods

##### define_table(cls, metadata)

### Site_table

#### Methods

##### define_table(cls, metadata)

### Site_table

#### Methods

##### define_table(cls, metadata)

