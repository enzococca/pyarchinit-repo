# modules/db/structures/Tma_table.py

## Overview

This file contains 8 documented elements.

## Classes

### Tma_table

TMA (Tabella Materiali Archeologici) table structure

### Tma_table

TMA (Tabella Materiali Archeologici) table structure

### Tma_table

TMA (Tabella Materiali Archeologici) table structure

### Tma_table

TMA (Tabella Materiali Archeologici) table structure

