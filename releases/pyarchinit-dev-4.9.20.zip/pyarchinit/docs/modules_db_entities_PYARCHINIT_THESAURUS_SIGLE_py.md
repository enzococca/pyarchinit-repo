# modules/db/entities/PYARCHINIT_THESAURUS_SIGLE.py

## Overview

This file contains 16 documented elements.

## Classes

### PYARCHINIT_THESAURUS_SIGLE

**Inherits from**: object

#### Methods

##### __init__(self, id_thesaurus_sigle, nome_tabella, sigla, sigla_estesa, descrizione, tipologia_sigla, lingua, order_layer, id_parent, parent_sigla, hierarchy_level, n_tipologia, n_sigla)

##### __repr__(self)

### PYARCHINIT_THESAURUS_SIGLE

**Inherits from**: object

#### Methods

##### __init__(self, id_thesaurus_sigle, nome_tabella, sigla, sigla_estesa, descrizione, tipologia_sigla, lingua, order_layer, id_parent, parent_sigla, hierarchy_level, n_tipologia, n_sigla)

##### __repr__(self)

### PYARCHINIT_THESAURUS_SIGLE

**Inherits from**: object

#### Methods

##### __init__(self, id_thesaurus_sigle, nome_tabella, sigla, sigla_estesa, descrizione, tipologia_sigla, lingua, order_layer, id_parent, parent_sigla, hierarchy_level, n_tipologia, n_sigla)

##### __repr__(self)

### PYARCHINIT_THESAURUS_SIGLE

**Inherits from**: object

#### Methods

##### __init__(self, id_thesaurus_sigle, nome_tabella, sigla, sigla_estesa, descrizione, tipologia_sigla, lingua, order_layer, id_parent, parent_sigla, hierarchy_level, n_tipologia, n_sigla)

##### __repr__(self)

