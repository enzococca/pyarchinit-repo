# modules/db/entities/PERIODIZZAZIONE.py

## Overview

This file contains 16 documented elements.

## Classes

### PERIODIZZAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_perfas, sito, periodo, fase, cron_iniziale, cron_finale, descrizione, datazione_estesa, cont_per)

##### __repr__(self)

### PERIODIZZAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_perfas, sito, periodo, fase, cron_iniziale, cron_finale, descrizione, datazione_estesa, cont_per)

##### __repr__(self)

### PERIODIZZAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_perfas, sito, periodo, fase, cron_iniziale, cron_finale, descrizione, datazione_estesa, cont_per)

##### __repr__(self)

### PERIODIZZAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_perfas, sito, periodo, fase, cron_iniziale, cron_finale, descrizione, datazione_estesa, cont_per)

##### __repr__(self)

