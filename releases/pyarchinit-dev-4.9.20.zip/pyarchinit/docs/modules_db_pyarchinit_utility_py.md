# modules/db/pyarchinit_utility.py

## Overview

This file contains 88 documented elements.

## Classes

### Utility

#### Methods

##### pos_none_in_list(self, l)

take a list of values and return the position number of the values
equal to 'None' 

##### tup_2_list(self, t, s, i)

take a tuple of strings, and return a list of lists of the values.
if s is set, add the value to the strings. If i is set return only the
value in the i position

##### tup_2_list_II(self, l)

take a list of tuples ad return a list of lists

##### tup_2_list_III(self, l)

take a list of tuples ad return a list of values

##### list_tup_2_list(self, l)

take a list of tuples ad return a list of lists

##### select_in_list(self, l, p)

take a list of lists or value and return the in a list of lists
the value taken by the value of p. 

##### count_list_eq_v(self, l, v)

take a list and a value. If the number of occurens of a
items inside the list is equal to v value, put the singol value
into list_res as a list. Return a list of lists

##### find_list_in_dict(self, d)

recives a dict and if contains a list of lists and
delete the item from the dict.
Return a tuple containin the new dict and a list of
tuples wich contain the keys and the values

##### add_item_to_dict(self, d, i)

receive a dict and a list containt tuple with key,value
and add them to dict

##### list_col_index_value(self, v1, v2)

return two lists into one tupla,
takin' two list with same lenght and lookin for the occurrences.
for every occurrences between v_1 and v_2 the v_2 value it's charged
into mod_value and its position in list it's put into list_index.

##### deunicode_list(self, l)

##### zip_lists(self, l1, l2)

##### join_list_if(self, l1, l2, v1, v2)

##### extract_from_list(self, l, p)

##### remove_empty_items_fr_dict(self, d)

##### findFieldFrDict(self, d, fn)

##### remove_dup_from_list(self, ls)

##### sum_list_of_tuples_for_value(self, l)

##### conversione_numeri(self, Numero)

##### getQuery(name)

### Utility

#### Methods

##### pos_none_in_list(self, l)

take a list of values and return the position number of the values
equal to 'None' 

##### tup_2_list(self, t, s, i)

take a tuple of strings, and return a list of lists of the values.
if s is set, add the value to the strings. If i is set return only the
value in the i position

##### tup_2_list_II(self, l)

take a list of tuples ad return a list of lists

##### tup_2_list_III(self, l)

take a list of tuples ad return a list of values

##### list_tup_2_list(self, l)

take a list of tuples ad return a list of lists

##### select_in_list(self, l, p)

take a list of lists or value and return the in a list of lists
the value taken by the value of p. 

##### count_list_eq_v(self, l, v)

take a list and a value. If the number of occurens of a
items inside the list is equal to v value, put the singol value
into list_res as a list. Return a list of lists

##### find_list_in_dict(self, d)

recives a dict and if contains a list of lists and
delete the item from the dict.
Return a tuple containin the new dict and a list of
tuples wich contain the keys and the values

##### add_item_to_dict(self, d, i)

receive a dict and a list containt tuple with key,value
and add them to dict

##### list_col_index_value(self, v1, v2)

return two lists into one tupla,
takin' two list with same lenght and lookin for the occurrences.
for every occurrences between v_1 and v_2 the v_2 value it's charged
into mod_value and its position in list it's put into list_index.

##### deunicode_list(self, l)

##### zip_lists(self, l1, l2)

##### join_list_if(self, l1, l2, v1, v2)

##### extract_from_list(self, l, p)

##### remove_empty_items_fr_dict(self, d)

##### findFieldFrDict(self, d, fn)

##### remove_dup_from_list(self, ls)

##### sum_list_of_tuples_for_value(self, l)

##### conversione_numeri(self, Numero)

##### getQuery(name)

### Utility

#### Methods

##### pos_none_in_list(self, l)

take a list of values and return the position number of the values
equal to 'None' 

##### tup_2_list(self, t, s, i)

take a tuple of strings, and return a list of lists of the values.
if s is set, add the value to the strings. If i is set return only the
value in the i position

##### tup_2_list_II(self, l)

take a list of tuples ad return a list of lists

##### tup_2_list_III(self, l)

take a list of tuples ad return a list of values

##### list_tup_2_list(self, l)

take a list of tuples ad return a list of lists

##### select_in_list(self, l, p)

take a list of lists or value and return the in a list of lists
the value taken by the value of p. 

##### count_list_eq_v(self, l, v)

take a list and a value. If the number of occurens of a
items inside the list is equal to v value, put the singol value
into list_res as a list. Return a list of lists

##### find_list_in_dict(self, d)

recives a dict and if contains a list of lists and
delete the item from the dict.
Return a tuple containin the new dict and a list of
tuples wich contain the keys and the values

##### add_item_to_dict(self, d, i)

receive a dict and a list containt tuple with key,value
and add them to dict

##### list_col_index_value(self, v1, v2)

return two lists into one tupla,
takin' two list with same lenght and lookin for the occurrences.
for every occurrences between v_1 and v_2 the v_2 value it's charged
into mod_value and its position in list it's put into list_index.

##### deunicode_list(self, l)

##### zip_lists(self, l1, l2)

##### join_list_if(self, l1, l2, v1, v2)

##### extract_from_list(self, l, p)

##### remove_empty_items_fr_dict(self, d)

##### findFieldFrDict(self, d, fn)

##### remove_dup_from_list(self, ls)

##### sum_list_of_tuples_for_value(self, l)

##### conversione_numeri(self, Numero)

##### getQuery(name)

### Utility

#### Methods

##### pos_none_in_list(self, l)

take a list of values and return the position number of the values
equal to 'None' 

##### tup_2_list(self, t, s, i)

take a tuple of strings, and return a list of lists of the values.
if s is set, add the value to the strings. If i is set return only the
value in the i position

##### tup_2_list_II(self, l)

take a list of tuples ad return a list of lists

##### tup_2_list_III(self, l)

take a list of tuples ad return a list of values

##### list_tup_2_list(self, l)

take a list of tuples ad return a list of lists

##### select_in_list(self, l, p)

take a list of lists or value and return the in a list of lists
the value taken by the value of p. 

##### count_list_eq_v(self, l, v)

take a list and a value. If the number of occurens of a
items inside the list is equal to v value, put the singol value
into list_res as a list. Return a list of lists

##### find_list_in_dict(self, d)

recives a dict and if contains a list of lists and
delete the item from the dict.
Return a tuple containin the new dict and a list of
tuples wich contain the keys and the values

##### add_item_to_dict(self, d, i)

receive a dict and a list containt tuple with key,value
and add them to dict

##### list_col_index_value(self, v1, v2)

return two lists into one tupla,
takin' two list with same lenght and lookin for the occurrences.
for every occurrences between v_1 and v_2 the v_2 value it's charged
into mod_value and its position in list it's put into list_index.

##### deunicode_list(self, l)

##### zip_lists(self, l1, l2)

##### join_list_if(self, l1, l2, v1, v2)

##### extract_from_list(self, l, p)

##### remove_empty_items_fr_dict(self, d)

##### findFieldFrDict(self, d, fn)

##### remove_dup_from_list(self, ls)

##### sum_list_of_tuples_for_value(self, l)

##### conversione_numeri(self, Numero)

##### getQuery(name)

