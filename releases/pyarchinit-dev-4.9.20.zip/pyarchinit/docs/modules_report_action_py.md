# modules/report/action.py

## Overview

This file contains 20 documented elements.

## Classes

### ArchaeologicalActions

#### Methods

##### SintesiIntroduttiva(context)

Gestisce l'analisi introduttiva del sito

##### AnalisiAreaScavo(context)

Gestisce l'analisi dell'area di scavo

##### AnalisiStratigrafica(context)

Gestisce l'analisi stratigrafica completa dei dati US.
Organizza e analizza:
- Elenco delle US
- Rapporti stratigrafici
- Interpretazione delle fasi

##### AnalisiMaterialiComplessiva(context)

Gestisce l'analisi completa dei materiali archeologici.
Analizza sia i materiali generici che la ceramica.

### ArchaeologicalActions

#### Methods

##### SintesiIntroduttiva(context)

Gestisce l'analisi introduttiva del sito

##### AnalisiAreaScavo(context)

Gestisce l'analisi dell'area di scavo

##### AnalisiStratigrafica(context)

Gestisce l'analisi stratigrafica completa dei dati US.
Organizza e analizza:
- Elenco delle US
- Rapporti stratigrafici
- Interpretazione delle fasi

##### AnalisiMaterialiComplessiva(context)

Gestisce l'analisi completa dei materiali archeologici.
Analizza sia i materiali generici che la ceramica.

### ArchaeologicalActions

#### Methods

##### SintesiIntroduttiva(context)

Gestisce l'analisi introduttiva del sito

##### AnalisiAreaScavo(context)

Gestisce l'analisi dell'area di scavo

##### AnalisiStratigrafica(context)

Gestisce l'analisi stratigrafica completa dei dati US.
Organizza e analizza:
- Elenco delle US
- Rapporti stratigrafici
- Interpretazione delle fasi

##### AnalisiMaterialiComplessiva(context)

Gestisce l'analisi completa dei materiali archeologici.
Analizza sia i materiali generici che la ceramica.

### ArchaeologicalActions

#### Methods

##### SintesiIntroduttiva(context)

Gestisce l'analisi introduttiva del sito

##### AnalisiAreaScavo(context)

Gestisce l'analisi dell'area di scavo

##### AnalisiStratigrafica(context)

Gestisce l'analisi stratigrafica completa dei dati US.
Organizza e analizza:
- Elenco delle US
- Rapporti stratigrafici
- Interpretazione delle fasi

##### AnalisiMaterialiComplessiva(context)

Gestisce l'analisi completa dei materiali archeologici.
Analizza sia i materiali generici che la ceramica.

