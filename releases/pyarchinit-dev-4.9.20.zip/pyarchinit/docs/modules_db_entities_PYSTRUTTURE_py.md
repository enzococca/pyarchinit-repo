# modules/db/entities/PYSTRUTTURE.py

## Overview

This file contains 16 documented elements.

## Classes

### PYSTRUTTURE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, id_strutt, per_iniz, per_fin, dataz_ext, fase_iniz, fase_fin, descrizione, the_geom, sigla_strut, nr_strut)

##### __repr__(self)

### PYSTRUTTURE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, id_strutt, per_iniz, per_fin, dataz_ext, fase_iniz, fase_fin, descrizione, the_geom, sigla_strut, nr_strut)

##### __repr__(self)

### PYSTRUTTURE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, id_strutt, per_iniz, per_fin, dataz_ext, fase_iniz, fase_fin, descrizione, the_geom, sigla_strut, nr_strut)

##### __repr__(self)

### PYSTRUTTURE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, id_strutt, per_iniz, per_fin, dataz_ext, fase_iniz, fase_fin, descrizione, the_geom, sigla_strut, nr_strut)

##### __repr__(self)

