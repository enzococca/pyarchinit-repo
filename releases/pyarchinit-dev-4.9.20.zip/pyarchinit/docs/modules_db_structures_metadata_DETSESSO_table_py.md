# modules/db/structures_metadata/DETSESSO_table.py

## Overview

This file contains 12 documented elements.

## Classes

### DETSESSO_table

#### Methods

##### define_table(cls, metadata)

### DETSESSO_table

#### Methods

##### define_table(cls, metadata)

### DETSESSO_table

#### Methods

##### define_table(cls, metadata)

### DETSESSO_table

#### Methods

##### define_table(cls, metadata)

