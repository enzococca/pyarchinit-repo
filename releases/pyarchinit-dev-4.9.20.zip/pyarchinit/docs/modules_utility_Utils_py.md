# modules/utility/Utils.py

## Overview

This file contains 24 documented elements.

## Classes

### ClickTool

**Inherits from**: QgsMapTool

#### Methods

##### __init__(self, iface, callback)

##### canvasReleaseEvent(self, e)

### ClickTool

**Inherits from**: QgsMapTool

#### Methods

##### __init__(self, iface, callback)

##### canvasReleaseEvent(self, e)

### ClickTool

**Inherits from**: QgsMapTool

#### Methods

##### __init__(self, iface, callback)

##### canvasReleaseEvent(self, e)

### ClickTool

**Inherits from**: QgsMapTool

#### Methods

##### __init__(self, iface, callback)

##### canvasReleaseEvent(self, e)

## Functions

### pointToWGS84(point, crs)

crs is the renderer crs

**Parameters:**
- `point`
- `crs`

### pointFromWGS84(point, crs)

**Parameters:**
- `point`
- `crs`

### pointToWGS84(point, crs)

crs is the renderer crs

**Parameters:**
- `point`
- `crs`

### pointFromWGS84(point, crs)

**Parameters:**
- `point`
- `crs`

### pointToWGS84(point, crs)

crs is the renderer crs

**Parameters:**
- `point`
- `crs`

### pointFromWGS84(point, crs)

**Parameters:**
- `point`
- `crs`

### pointToWGS84(point, crs)

crs is the renderer crs

**Parameters:**
- `point`
- `crs`

### pointFromWGS84(point, crs)

**Parameters:**
- `point`
- `crs`

