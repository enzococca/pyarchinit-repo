# modules/db/entities/PYUS_NEGATIVE.py

## Overview

This file contains 16 documented elements.

## Classes

### PYUS_NEGATIVE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_n, area_n, us_n, tipo_doc_n, nome_doc_n, the_geom)

##### __repr__(self)

### PYUS_NEGATIVE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_n, area_n, us_n, tipo_doc_n, nome_doc_n, the_geom)

##### __repr__(self)

### PYUS_NEGATIVE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_n, area_n, us_n, tipo_doc_n, nome_doc_n, the_geom)

##### __repr__(self)

### PYUS_NEGATIVE

**Inherits from**: object

#### Methods

##### __init__(self, pkuid, sito_n, area_n, us_n, tipo_doc_n, nome_doc_n, the_geom)

##### __repr__(self)

