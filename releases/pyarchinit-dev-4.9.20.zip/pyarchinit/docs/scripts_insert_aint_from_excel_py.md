# scripts/insert_aint_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_aint_values(cursor)

Inserisce i valori aint dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_aint_values(cursor)

Inserisce i valori aint dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_aint_values(cursor)

Inserisce i valori aint dal file Excel.

**Parameters:**
- `cursor`

### main()

