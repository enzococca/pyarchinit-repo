# modules/db/structures_metadata/pylineeriferimento.py

## Overview

This file contains 12 documented elements.

## Classes

### pylineeriferimento

#### Methods

##### define_table(cls, metadata)

### pylineeriferimento

#### Methods

##### define_table(cls, metadata)

### pylineeriferimento

#### Methods

##### define_table(cls, metadata)

### pylineeriferimento

#### Methods

##### define_table(cls, metadata)

