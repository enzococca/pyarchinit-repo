# modules/db/entities/INVENTARIO_MATERIALI_TOIMP.py

## Overview

This file contains 16 documented elements.

## Classes

### INVENTARIO_MATERIALI_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_invmat, sito, numero_inventario, tipo_reperto, criterio_schedatura, definizione, descrizione, area, us, lavato, nr_cassa, luogo_conservazione, stato_conservazione, datazione_reperto, elementi_reperto, misurazioni, rif_biblio, tecnologie, forme_minime, forme_massime, totale_frammenti, corpo_ceramico, rivestimento)

##### __repr__(self)

### INVENTARIO_MATERIALI_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_invmat, sito, numero_inventario, tipo_reperto, criterio_schedatura, definizione, descrizione, area, us, lavato, nr_cassa, luogo_conservazione, stato_conservazione, datazione_reperto, elementi_reperto, misurazioni, rif_biblio, tecnologie, forme_minime, forme_massime, totale_frammenti, corpo_ceramico, rivestimento)

##### __repr__(self)

### INVENTARIO_MATERIALI_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_invmat, sito, numero_inventario, tipo_reperto, criterio_schedatura, definizione, descrizione, area, us, lavato, nr_cassa, luogo_conservazione, stato_conservazione, datazione_reperto, elementi_reperto, misurazioni, rif_biblio, tecnologie, forme_minime, forme_massime, totale_frammenti, corpo_ceramico, rivestimento)

##### __repr__(self)

### INVENTARIO_MATERIALI_TOIMP

**Inherits from**: object

#### Methods

##### __init__(self, id_invmat, sito, numero_inventario, tipo_reperto, criterio_schedatura, definizione, descrizione, area, us, lavato, nr_cassa, luogo_conservazione, stato_conservazione, datazione_reperto, elementi_reperto, misurazioni, rif_biblio, tecnologie, forme_minime, forme_massime, totale_frammenti, corpo_ceramico, rivestimento)

##### __repr__(self)

