# modules/db/entities/DOCUMENTAZIONE.py

## Overview

This file contains 16 documented elements.

## Classes

### DOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_documentazione, sito, nome_doc, data, tipo_documentazione, sorgente, scala, disegnatore, note)

##### __repr__(self)

### DOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_documentazione, sito, nome_doc, data, tipo_documentazione, sorgente, scala, disegnatore, note)

##### __repr__(self)

### DOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_documentazione, sito, nome_doc, data, tipo_documentazione, sorgente, scala, disegnatore, note)

##### __repr__(self)

### DOCUMENTAZIONE

**Inherits from**: object

#### Methods

##### __init__(self, id_documentazione, sito, nome_doc, data, tipo_documentazione, sorgente, scala, disegnatore, note)

##### __repr__(self)

