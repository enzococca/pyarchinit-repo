# scripts/map_thesaurus_types.py

## Overview

This file contains 9 documented elements.

## Functions

### map_thesaurus_types(db_path)

Mappa i tipi del thesaurus secondo la logica corretta.

**Parameters:**
- `db_path`

### main()

### map_thesaurus_types(db_path)

Mappa i tipi del thesaurus secondo la logica corretta.

**Parameters:**
- `db_path`

### main()

### map_thesaurus_types(db_path)

Mappa i tipi del thesaurus secondo la logica corretta.

**Parameters:**
- `db_path`

### main()

