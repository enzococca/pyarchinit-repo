# modules/utility/csv_writer.py

## Overview

This file contains 48 documented elements.

## Classes

### UTF8Recoder

Iterator that reads an encoded stream and reencodes the input to UTF-8

#### Methods

##### __init__(self, f, encoding)

##### __iter__(self)

##### __next__(self)

### UnicodeReader

A CSV reader which will iterate over lines in the CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### __next__(self)

##### __iter__(self)

### UnicodeWriter

A CSV writer which will write rows to CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### writerow(self, row)

##### writerows(self, rows)

### UTF8Recoder

Iterator that reads an encoded stream and reencodes the input to UTF-8

#### Methods

##### __init__(self, f, encoding)

##### __iter__(self)

##### __next__(self)

### UnicodeReader

A CSV reader which will iterate over lines in the CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### __next__(self)

##### __iter__(self)

### UnicodeWriter

A CSV writer which will write rows to CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### writerow(self, row)

##### writerows(self, rows)

### UTF8Recoder

Iterator that reads an encoded stream and reencodes the input to UTF-8

#### Methods

##### __init__(self, f, encoding)

##### __iter__(self)

##### __next__(self)

### UnicodeReader

A CSV reader which will iterate over lines in the CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### __next__(self)

##### __iter__(self)

### UnicodeWriter

A CSV writer which will write rows to CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### writerow(self, row)

##### writerows(self, rows)

### UTF8Recoder

Iterator that reads an encoded stream and reencodes the input to UTF-8

#### Methods

##### __init__(self, f, encoding)

##### __iter__(self)

##### __next__(self)

### UnicodeReader

A CSV reader which will iterate over lines in the CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### __next__(self)

##### __iter__(self)

### UnicodeWriter

A CSV writer which will write rows to CSV file "f",
which is encoded in the given encoding.

#### Methods

##### __init__(self, f, dialect, encoding)

##### writerow(self, row)

##### writerows(self, rows)

