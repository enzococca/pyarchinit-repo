# modules/db/entities/PYQUOTE.py

## Overview

This file contains 16 documented elements.

## Classes

### PYQUOTE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

### PYQUOTE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

### PYQUOTE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

### PYQUOTE

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

