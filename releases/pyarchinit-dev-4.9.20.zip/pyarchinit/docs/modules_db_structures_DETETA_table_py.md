# modules/db/structures/DETETA_table.py

## Overview

This file contains 8 documented elements.

## Classes

### DETETA_table

### DETETA_table

### DETETA_table

### DETETA_table

