# modules/db/structures_metadata/Pyarchinit_thesaurus_sigle.py

## Overview

This file contains 12 documented elements.

## Classes

### Pyarchinit_thesaurus_sigle

#### Methods

##### define_table(cls, metadata)

### Pyarchinit_thesaurus_sigle

#### Methods

##### define_table(cls, metadata)

### Pyarchinit_thesaurus_sigle

#### Methods

##### define_table(cls, metadata)

### Pyarchinit_thesaurus_sigle

#### Methods

##### define_table(cls, metadata)

