# modules/db/structures_metadata/Inventario_materiali_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Inventario_materiali_table

#### Methods

##### define_table(cls, metadata)

### Inventario_materiali_table

#### Methods

##### define_table(cls, metadata)

### Inventario_materiali_table

#### Methods

##### define_table(cls, metadata)

### Inventario_materiali_table

#### Methods

##### define_table(cls, metadata)

