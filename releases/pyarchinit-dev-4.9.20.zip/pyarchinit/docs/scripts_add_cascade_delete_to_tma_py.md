# scripts/add_cascade_delete_to_tma.py

## Overview

This file contains 6 documented elements.

## Functions

### add_cascade_delete(db_path)

Add CASCADE DELETE to TMA foreign key constraint

**Parameters:**
- `db_path`

### add_cascade_delete(db_path)

Add CASCADE DELETE to TMA foreign key constraint

**Parameters:**
- `db_path`

### add_cascade_delete(db_path)

Add CASCADE DELETE to TMA foreign key constraint

**Parameters:**
- `db_path`

