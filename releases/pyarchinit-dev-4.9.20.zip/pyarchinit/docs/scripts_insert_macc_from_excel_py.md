# scripts/insert_macc_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_macc_values(cursor)

Inserisce i valori macc dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_macc_values(cursor)

Inserisce i valori macc dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_macc_values(cursor)

Inserisce i valori macc dal file Excel.

**Parameters:**
- `cursor`

### main()

