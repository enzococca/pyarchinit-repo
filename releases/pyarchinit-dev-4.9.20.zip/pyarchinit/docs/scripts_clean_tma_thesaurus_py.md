# scripts/clean_tma_thesaurus.py

## Overview

This file contains 9 documented elements.

## Functions

### clean_tma_thesaurus(db_path)

Pulisce e corregge il thesaurus TMA.

**Parameters:**
- `db_path`

### main()

### clean_tma_thesaurus(db_path)

Pulisce e corregge il thesaurus TMA.

**Parameters:**
- `db_path`

### main()

### clean_tma_thesaurus(db_path)

Pulisce e corregge il thesaurus TMA.

**Parameters:**
- `db_path`

### main()

