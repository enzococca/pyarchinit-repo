# modules/db/structures_metadata/pystrutture.py

## Overview

This file contains 12 documented elements.

## Classes

### pystrutture

#### Methods

##### define_table(cls, metadata)

### pystrutture

#### Methods

##### define_table(cls, metadata)

### pystrutture

#### Methods

##### define_table(cls, metadata)

### pystrutture

#### Methods

##### define_table(cls, metadata)

