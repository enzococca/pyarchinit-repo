# modules/db/entities/SCHEDAIND.py

## Overview

This file contains 16 documented elements.

## Classes

### SCHEDAIND

**Inherits from**: object

#### Methods

##### __init__(self, id_scheda_ind, sito, area, us, nr_individuo, data_schedatura, schedatore, sesso, eta_min, eta_max, classi_eta, osservazioni, sigla_struttura, nr_struttura, completo_si_no, disturbato_si_no, in_connessione_si_no, lunghezza_scheletro, posizione_scheletro, posizione_cranio, posizione_arti_superiori, posizione_arti_inferiori, orientamento_asse, orientamento_azimut)

##### __repr__(self)

### SCHEDAIND

**Inherits from**: object

#### Methods

##### __init__(self, id_scheda_ind, sito, area, us, nr_individuo, data_schedatura, schedatore, sesso, eta_min, eta_max, classi_eta, osservazioni, sigla_struttura, nr_struttura, completo_si_no, disturbato_si_no, in_connessione_si_no, lunghezza_scheletro, posizione_scheletro, posizione_cranio, posizione_arti_superiori, posizione_arti_inferiori, orientamento_asse, orientamento_azimut)

##### __repr__(self)

### SCHEDAIND

**Inherits from**: object

#### Methods

##### __init__(self, id_scheda_ind, sito, area, us, nr_individuo, data_schedatura, schedatore, sesso, eta_min, eta_max, classi_eta, osservazioni, sigla_struttura, nr_struttura, completo_si_no, disturbato_si_no, in_connessione_si_no, lunghezza_scheletro, posizione_scheletro, posizione_cranio, posizione_arti_superiori, posizione_arti_inferiori, orientamento_asse, orientamento_azimut)

##### __repr__(self)

### SCHEDAIND

**Inherits from**: object

#### Methods

##### __init__(self, id_scheda_ind, sito, area, us, nr_individuo, data_schedatura, schedatore, sesso, eta_min, eta_max, classi_eta, osservazioni, sigla_struttura, nr_struttura, completo_si_no, disturbato_si_no, in_connessione_si_no, lunghezza_scheletro, posizione_scheletro, posizione_cranio, posizione_arti_superiori, posizione_arti_inferiori, orientamento_asse, orientamento_azimut)

##### __repr__(self)

