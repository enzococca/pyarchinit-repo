# fix_thesaurus_hierarchy_complete.py

## Overview

This file contains 44 documented elements.

## Functions

### setupUi_additions(self)

Aggiunte all'interfaccia dopo setupUi - da chiamare in __init__

**Parameters:**
- `self`

### create_hierarchy_widgets(self)

Create hierarchy selection widgets and add them to the UI.

**Parameters:**
- `self`

### on_nome_tabella_changed(self)

Handle table name change.

**Parameters:**
- `self`

### setup_tma_hierarchy_widgets(self)

Setup hierarchy management widgets for TMA materials.

**Parameters:**
- `self`

### on_tma_tipologia_changed(self)

Handle TMA tipologia change to show hierarchy options.

**Parameters:**
- `self`

### hide_hierarchy_widgets(self)

Hide all hierarchy selection widgets.

**Parameters:**
- `self`

### show_area_parent_widgets(self)

Show widgets for selecting località parent for area.

**Parameters:**
- `self`

### show_settore_parent_widgets(self)

Show widgets for selecting località and area parents for settore.

**Parameters:**
- `self`

### load_parent_localita(self)

Load available località from thesaurus.

**Parameters:**
- `self`

### on_parent_localita_changed(self)

When località selection changes, update available areas.

**Parameters:**
- `self`

### setupUi_additions(self)

Aggiunte all'interfaccia dopo setupUi - da chiamare in __init__

**Parameters:**
- `self`

### create_hierarchy_widgets(self)

Create hierarchy selection widgets and add them to the UI.

**Parameters:**
- `self`

### on_nome_tabella_changed(self)

Handle table name change.

**Parameters:**
- `self`

### setup_tma_hierarchy_widgets(self)

Setup hierarchy management widgets for TMA materials.

**Parameters:**
- `self`

### on_tma_tipologia_changed(self)

Handle TMA tipologia change to show hierarchy options.

**Parameters:**
- `self`

### hide_hierarchy_widgets(self)

Hide all hierarchy selection widgets.

**Parameters:**
- `self`

### show_area_parent_widgets(self)

Show widgets for selecting località parent for area.

**Parameters:**
- `self`

### show_settore_parent_widgets(self)

Show widgets for selecting località and area parents for settore.

**Parameters:**
- `self`

### load_parent_localita(self)

Load available località from thesaurus.

**Parameters:**
- `self`

### on_parent_localita_changed(self)

When località selection changes, update available areas.

**Parameters:**
- `self`

### setupUi_additions(self)

Aggiunte all'interfaccia dopo setupUi - da chiamare in __init__

**Parameters:**
- `self`

### create_hierarchy_widgets(self)

Create hierarchy selection widgets and add them to the UI.

**Parameters:**
- `self`

### on_nome_tabella_changed(self)

Handle table name change.

**Parameters:**
- `self`

### setup_tma_hierarchy_widgets(self)

Setup hierarchy management widgets for TMA materials.

**Parameters:**
- `self`

### on_tma_tipologia_changed(self)

Handle TMA tipologia change to show hierarchy options.

**Parameters:**
- `self`

### hide_hierarchy_widgets(self)

Hide all hierarchy selection widgets.

**Parameters:**
- `self`

### show_area_parent_widgets(self)

Show widgets for selecting località parent for area.

**Parameters:**
- `self`

### show_settore_parent_widgets(self)

Show widgets for selecting località and area parents for settore.

**Parameters:**
- `self`

### load_parent_localita(self)

Load available località from thesaurus.

**Parameters:**
- `self`

### on_parent_localita_changed(self)

When località selection changes, update available areas.

**Parameters:**
- `self`

### setupUi_additions(self)

Aggiunte all'interfaccia dopo setupUi - da chiamare in __init__

**Parameters:**
- `self`

### create_hierarchy_widgets(self)

Create hierarchy selection widgets and add them to the UI.

**Parameters:**
- `self`

### on_nome_tabella_changed(self)

Handle table name change.

**Parameters:**
- `self`

### setup_tma_hierarchy_widgets(self)

Setup hierarchy management widgets for TMA materials.

**Parameters:**
- `self`

### on_tma_tipologia_changed(self)

Handle TMA tipologia change to show hierarchy options.

**Parameters:**
- `self`

### hide_hierarchy_widgets(self)

Hide all hierarchy selection widgets.

**Parameters:**
- `self`

### show_area_parent_widgets(self)

Show widgets for selecting località parent for area.

**Parameters:**
- `self`

### show_settore_parent_widgets(self)

Show widgets for selecting località and area parents for settore.

**Parameters:**
- `self`

### load_parent_localita(self)

Load available località from thesaurus.

**Parameters:**
- `self`

### on_parent_localita_changed(self)

When località selection changes, update available areas.

**Parameters:**
- `self`

