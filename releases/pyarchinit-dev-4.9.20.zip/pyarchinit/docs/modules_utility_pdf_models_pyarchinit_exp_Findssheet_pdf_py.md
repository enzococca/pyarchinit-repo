# modules/utility/pdf_models/pyarchinit_exp_Findssheet_pdf.py

## Overview

This file contains 84 documented elements.

## Classes

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Finds_sheets(self, records)

##### build_index_US(self, records, sito)

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Finds_sheets(self, records)

##### build_index_US(self, records, sito)

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Finds_sheets(self, records)

##### build_index_US(self, records, sito)

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_USindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

### generate_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_Finds_sheets(self, records)

##### build_index_US(self, records, sito)

