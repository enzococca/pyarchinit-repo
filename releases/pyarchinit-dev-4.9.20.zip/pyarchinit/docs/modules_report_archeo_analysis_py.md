# modules/report/archeo_analysis.py

## Overview

This file contains 40 documented elements.

## Classes

### ArchaeologicalAnalysis

#### Methods

##### __init__(self)

##### get_max_tokens_for_section(self, section)

##### get_next_analysis_step(self)

##### get_introduction_step(self)

##### get_methodology_step(self)

##### get_stratigraphy_step(self)

##### get_materials_step(self)

##### get_tma_cassette_step(self)

##### get_conclusions_step(self)

### ArchaeologicalAnalysis

#### Methods

##### __init__(self)

##### get_max_tokens_for_section(self, section)

##### get_next_analysis_step(self)

##### get_introduction_step(self)

##### get_methodology_step(self)

##### get_stratigraphy_step(self)

##### get_materials_step(self)

##### get_tma_cassette_step(self)

##### get_conclusions_step(self)

### ArchaeologicalAnalysis

#### Methods

##### __init__(self)

##### get_max_tokens_for_section(self, section)

##### get_next_analysis_step(self)

##### get_introduction_step(self)

##### get_methodology_step(self)

##### get_stratigraphy_step(self)

##### get_materials_step(self)

##### get_tma_cassette_step(self)

##### get_conclusions_step(self)

### ArchaeologicalAnalysis

#### Methods

##### __init__(self)

##### get_max_tokens_for_section(self, section)

##### get_next_analysis_step(self)

##### get_introduction_step(self)

##### get_methodology_step(self)

##### get_stratigraphy_step(self)

##### get_materials_step(self)

##### get_tma_cassette_step(self)

##### get_conclusions_step(self)

