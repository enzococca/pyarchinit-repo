# modules/utility/askgpt.py

## Overview

This file contains 16 documented elements.

## Classes

### MyApp

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

##### ask_gpt(self, prompt, apikey, model)

##### is_connected(self)

### MyApp

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

##### ask_gpt(self, prompt, apikey, model)

##### is_connected(self)

### MyApp

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

##### ask_gpt(self, prompt, apikey, model)

##### is_connected(self)

### MyApp

**Inherits from**: QWidget

#### Methods

##### __init__(self, parent)

##### ask_gpt(self, prompt, apikey, model)

##### is_connected(self)

