# pyarchinitPlugin.py

## Overview

This file contains 144 documented elements.

## Classes

### PyArchInitPlugin

**Inherits from**: object

#### Methods

##### __init__(self, iface)

##### check_and_fix_sqlite_databases(self)

Check and fix macc field in all SQLite databases in the pyarchinit folder

##### fix_single_sqlite_database(self, db_path)

Fix macc field in a single SQLite database

##### initGui(self)

##### runSite(self)

##### runPer(self)

##### runStruttura(self)

##### runUS(self)

##### runInr(self)

##### runTma(self)

##### runCampioni(self)

##### runPottery(self)

##### runPotteryTools(self)

##### runGisTimeController(self)

##### runTops(self)

##### runPrint(self)

##### runGpkg(self)

##### runConf(self)

##### runInfo(self)

##### runImageViewer(self)

##### runTomba(self)

##### runSchedaind(self)

##### runDetsesso(self)

##### runDeteta(self)

##### runUT(self)

##### runImages_directory_export(self)

##### runComparision(self)

##### runDbmanagment(self)

##### runPdfexp(self)

##### runThesaurus(self)

##### runDocumentazione(self)

##### runExcel(self)

##### unload(self)

##### showHideDockWidget(self)

### PyArchInitPlugin

**Inherits from**: object

#### Methods

##### __init__(self, iface)

##### check_and_fix_sqlite_databases(self)

Check and fix macc field in all SQLite databases in the pyarchinit folder

##### fix_single_sqlite_database(self, db_path)

Fix macc field in a single SQLite database

##### initGui(self)

##### runSite(self)

##### runPer(self)

##### runStruttura(self)

##### runUS(self)

##### runInr(self)

##### runTma(self)

##### runCampioni(self)

##### runPottery(self)

##### runPotteryTools(self)

##### runGisTimeController(self)

##### runTops(self)

##### runPrint(self)

##### runGpkg(self)

##### runConf(self)

##### runInfo(self)

##### runImageViewer(self)

##### runTomba(self)

##### runSchedaind(self)

##### runDetsesso(self)

##### runDeteta(self)

##### runUT(self)

##### runImages_directory_export(self)

##### runComparision(self)

##### runDbmanagment(self)

##### runPdfexp(self)

##### runThesaurus(self)

##### runDocumentazione(self)

##### runExcel(self)

##### unload(self)

##### showHideDockWidget(self)

### PyArchInitPlugin

**Inherits from**: object

#### Methods

##### __init__(self, iface)

##### check_and_fix_sqlite_databases(self)

Check and fix macc field in all SQLite databases in the pyarchinit folder

##### fix_single_sqlite_database(self, db_path)

Fix macc field in a single SQLite database

##### initGui(self)

##### runSite(self)

##### runPer(self)

##### runStruttura(self)

##### runUS(self)

##### runInr(self)

##### runTma(self)

##### runCampioni(self)

##### runPottery(self)

##### runPotteryTools(self)

##### runGisTimeController(self)

##### runTops(self)

##### runPrint(self)

##### runGpkg(self)

##### runConf(self)

##### runInfo(self)

##### runImageViewer(self)

##### runTomba(self)

##### runSchedaind(self)

##### runDetsesso(self)

##### runDeteta(self)

##### runUT(self)

##### runImages_directory_export(self)

##### runComparision(self)

##### runDbmanagment(self)

##### runPdfexp(self)

##### runThesaurus(self)

##### runDocumentazione(self)

##### runExcel(self)

##### unload(self)

##### showHideDockWidget(self)

### PyArchInitPlugin

**Inherits from**: object

#### Methods

##### __init__(self, iface)

##### check_and_fix_sqlite_databases(self)

Check and fix macc field in all SQLite databases in the pyarchinit folder

##### fix_single_sqlite_database(self, db_path)

Fix macc field in a single SQLite database

##### initGui(self)

##### runSite(self)

##### runPer(self)

##### runStruttura(self)

##### runUS(self)

##### runInr(self)

##### runTma(self)

##### runCampioni(self)

##### runPottery(self)

##### runPotteryTools(self)

##### runGisTimeController(self)

##### runTops(self)

##### runPrint(self)

##### runGpkg(self)

##### runConf(self)

##### runInfo(self)

##### runImageViewer(self)

##### runTomba(self)

##### runSchedaind(self)

##### runDetsesso(self)

##### runDeteta(self)

##### runUT(self)

##### runImages_directory_export(self)

##### runComparision(self)

##### runDbmanagment(self)

##### runPdfexp(self)

##### runThesaurus(self)

##### runDocumentazione(self)

##### runExcel(self)

##### unload(self)

##### showHideDockWidget(self)

