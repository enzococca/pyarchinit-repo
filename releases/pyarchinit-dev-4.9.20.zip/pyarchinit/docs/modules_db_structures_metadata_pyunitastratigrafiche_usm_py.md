# modules/db/structures_metadata/pyunitastratigrafiche_usm.py

## Overview

This file contains 12 documented elements.

## Classes

### pyunitastratigrafiche_usm

#### Methods

##### define_table(cls, metadata)

### pyunitastratigrafiche_usm

#### Methods

##### define_table(cls, metadata)

### pyunitastratigrafiche_usm

#### Methods

##### define_table(cls, metadata)

### pyunitastratigrafiche_usm

#### Methods

##### define_table(cls, metadata)

