# modules/utility/pyarchinit_exp_Tmasheet_pdf.py

## Overview

This file contains 44 documented elements.

## Classes

### NumberedCanvas_TMAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### generate_tma_pdf

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

Convert date for display

##### create_sheet(self)

Main method to create the PDF

### NumberedCanvas_TMAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### generate_tma_pdf

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

Convert date for display

##### create_sheet(self)

Main method to create the PDF

### NumberedCanvas_TMAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### generate_tma_pdf

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

Convert date for display

##### create_sheet(self)

Main method to create the PDF

### NumberedCanvas_TMAsheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### generate_tma_pdf

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

Convert date for display

##### create_sheet(self)

Main method to create the PDF

## Functions

### single_TMA_pdf(data)

Function to generate a single TMA PDF

**Parameters:**
- `data`

### single_TMA_pdf(data)

Function to generate a single TMA PDF

**Parameters:**
- `data`

### single_TMA_pdf(data)

Function to generate a single TMA PDF

**Parameters:**
- `data`

### single_TMA_pdf(data)

Function to generate a single TMA PDF

**Parameters:**
- `data`

