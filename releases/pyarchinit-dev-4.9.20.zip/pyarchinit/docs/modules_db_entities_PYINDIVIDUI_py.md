# modules/db/entities/PYINDIVIDUI.py

## Overview

This file contains 16 documented elements.

## Classes

### PYINDIVIDUI

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, sigla_struttura, note, id_individuo, the_geom)

##### __repr__(self)

### PYINDIVIDUI

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, sigla_struttura, note, id_individuo, the_geom)

##### __repr__(self)

### PYINDIVIDUI

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, sigla_struttura, note, id_individuo, the_geom)

##### __repr__(self)

### PYINDIVIDUI

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, sigla_struttura, note, id_individuo, the_geom)

##### __repr__(self)

