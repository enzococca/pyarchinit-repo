# scripts/insert_ldcn_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_ldcn_values(cursor)

Inserisce i valori ldcn dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_ldcn_values(cursor)

Inserisce i valori ldcn dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_ldcn_values(cursor)

Inserisce i valori ldcn dal file Excel.

**Parameters:**
- `cursor`

### main()

