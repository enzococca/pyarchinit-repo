# modules/db/entities/MEDIA.py

## Overview

This file contains 16 documented elements.

## Classes

### MEDIA

**Inherits from**: object

#### Methods

##### __init__(self, id_media, mediatype, filename, filetype, filepath, descrizione, tags)

##### __repr__(self)

### MEDIA

**Inherits from**: object

#### Methods

##### __init__(self, id_media, mediatype, filename, filetype, filepath, descrizione, tags)

##### __repr__(self)

### MEDIA

**Inherits from**: object

#### Methods

##### __init__(self, id_media, mediatype, filename, filetype, filepath, descrizione, tags)

##### __repr__(self)

### MEDIA

**Inherits from**: object

#### Methods

##### __init__(self, id_media, mediatype, filename, filetype, filepath, descrizione, tags)

##### __repr__(self)

