# scripts/fix_thesaurus_field_shift.py

## Overview

This file contains 9 documented elements.

## Functions

### fix_field_shift(db_path)

Corregge lo spostamento dei campi nel thesaurus.

**Parameters:**
- `db_path`

### main()

### fix_field_shift(db_path)

Corregge lo spostamento dei campi nel thesaurus.

**Parameters:**
- `db_path`

### main()

### fix_field_shift(db_path)

Corregge lo spostamento dei campi nel thesaurus.

**Parameters:**
- `db_path`

### main()

