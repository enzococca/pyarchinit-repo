# scripts/insert_ogtm_from_excel.py

## Overview

This file contains 9 documented elements.

## Functions

### insert_ogtm_values(cursor)

Inserisce i valori ogtm dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_ogtm_values(cursor)

Inserisce i valori ogtm dal file Excel.

**Parameters:**
- `cursor`

### main()

### insert_ogtm_values(cursor)

Inserisce i valori ogtm dal file Excel.

**Parameters:**
- `cursor`

### main()

