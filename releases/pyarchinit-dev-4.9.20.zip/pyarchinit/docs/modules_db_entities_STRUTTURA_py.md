# modules/db/entities/STRUTTURA.py

## Overview

This file contains 16 documented elements.

## Classes

### STRUTTURA

**Inherits from**: object

#### Methods

##### __init__(self, id_struttura, sito, sigla_struttura, numero_struttura, categoria_struttura, tipologia_struttura, definizione_struttura, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa, materiali_impiegati, elementi_strutturali, rapporti_struttura, misure_struttura)

##### __repr__(self)

### STRUTTURA

**Inherits from**: object

#### Methods

##### __init__(self, id_struttura, sito, sigla_struttura, numero_struttura, categoria_struttura, tipologia_struttura, definizione_struttura, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa, materiali_impiegati, elementi_strutturali, rapporti_struttura, misure_struttura)

##### __repr__(self)

### STRUTTURA

**Inherits from**: object

#### Methods

##### __init__(self, id_struttura, sito, sigla_struttura, numero_struttura, categoria_struttura, tipologia_struttura, definizione_struttura, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa, materiali_impiegati, elementi_strutturali, rapporti_struttura, misure_struttura)

##### __repr__(self)

### STRUTTURA

**Inherits from**: object

#### Methods

##### __init__(self, id_struttura, sito, sigla_struttura, numero_struttura, categoria_struttura, tipologia_struttura, definizione_struttura, descrizione, interpretazione, periodo_iniziale, fase_iniziale, periodo_finale, fase_finale, datazione_estesa, materiali_impiegati, elementi_strutturali, rapporti_struttura, misure_struttura)

##### __repr__(self)

