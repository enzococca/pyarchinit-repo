# scripts/fix_sqlite_geometry_spatialite.py

## Overview

This file contains 12 documented elements.

## Functions

### get_table_name_and_geom_type(content)

Extract table name and geometry type from the file content

**Parameters:**
- `content`

### fix_geometry_in_file(file_path)

Fix geometry handling for SQLite in a structure file

**Parameters:**
- `file_path`

### main()

### get_table_name_and_geom_type(content)

Extract table name and geometry type from the file content

**Parameters:**
- `content`

### fix_geometry_in_file(file_path)

Fix geometry handling for SQLite in a structure file

**Parameters:**
- `file_path`

### main()

### get_table_name_and_geom_type(content)

Extract table name and geometry type from the file content

**Parameters:**
- `content`

### fix_geometry_in_file(file_path)

Fix geometry handling for SQLite in a structure file

**Parameters:**
- `file_path`

### main()

