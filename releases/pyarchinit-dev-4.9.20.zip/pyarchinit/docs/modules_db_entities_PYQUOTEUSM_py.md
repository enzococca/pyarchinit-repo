# modules/db/entities/PYQUOTEUSM.py

## Overview

This file contains 16 documented elements.

## Classes

### PYQUOTEUSM

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

### PYQUOTEUSM

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

### PYQUOTEUSM

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

### PYQUOTEUSM

**Inherits from**: object

#### Methods

##### __init__(self, id, sito_q, area_q, us_q, unita_misu_q, quota_q, data, disegnatore, rilievo_originale, the_geom, unita_tipo_q)

##### __repr__(self)

