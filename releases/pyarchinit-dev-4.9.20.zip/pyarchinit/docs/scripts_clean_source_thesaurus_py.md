# scripts/clean_source_thesaurus.py

## Overview

This file contains 9 documented elements.

## Functions

### clean_source_database(db_type, conn_params)

Pulisce i duplicati nel database sorgente.

**Parameters:**
- `db_type`
- `conn_params`

### main()

### clean_source_database(db_type, conn_params)

Pulisce i duplicati nel database sorgente.

**Parameters:**
- `db_type`
- `conn_params`

### main()

### clean_source_database(db_type, conn_params)

Pulisce i duplicati nel database sorgente.

**Parameters:**
- `db_type`
- `conn_params`

### main()

