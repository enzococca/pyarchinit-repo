# resources/dbfiles/X11Colors.py

## Overview

This file contains 4 documented elements.

