# modules/db/entities/DETETA.py

## Overview

This file contains 16 documented elements.

## Classes

### DETETA

**Inherits from**: object

#### Methods

##### __init__(self, id_det_eta, sito, nr_individuo, sinf_min, sinf_max, sinf_min_2, sinf_max_2, SSPIA, SSPIB, SSPIC, SSPID, sup_aur_min, sup_aur_max, sup_aur_min_2, sup_aur_max_2, ms_sup_min, ms_sup_max, ms_inf_min, ms_inf_max, usura_min, usura_max, Id_endo, Is_endo, IId_endo, IIs_endo, IIId_endo, IIIs_endo, IV_endo, V_endo, VI_endo, VII_endo, VIIId_endo, VIIIs_endo, IXd_endo, IXs_endo, Xd_endo, Xs_endo, endo_min, endo_max, volta_1, volta_2, volta_3, volta_4, volta_5, volta_6, volta_7, lat_6, lat_7, lat_8, lat_9, lat_10, volta_min, volta_max, ant_lat_min, ant_lat_max, ecto_min, ecto_max)

##### __repr__(self)

### DETETA

**Inherits from**: object

#### Methods

##### __init__(self, id_det_eta, sito, nr_individuo, sinf_min, sinf_max, sinf_min_2, sinf_max_2, SSPIA, SSPIB, SSPIC, SSPID, sup_aur_min, sup_aur_max, sup_aur_min_2, sup_aur_max_2, ms_sup_min, ms_sup_max, ms_inf_min, ms_inf_max, usura_min, usura_max, Id_endo, Is_endo, IId_endo, IIs_endo, IIId_endo, IIIs_endo, IV_endo, V_endo, VI_endo, VII_endo, VIIId_endo, VIIIs_endo, IXd_endo, IXs_endo, Xd_endo, Xs_endo, endo_min, endo_max, volta_1, volta_2, volta_3, volta_4, volta_5, volta_6, volta_7, lat_6, lat_7, lat_8, lat_9, lat_10, volta_min, volta_max, ant_lat_min, ant_lat_max, ecto_min, ecto_max)

##### __repr__(self)

### DETETA

**Inherits from**: object

#### Methods

##### __init__(self, id_det_eta, sito, nr_individuo, sinf_min, sinf_max, sinf_min_2, sinf_max_2, SSPIA, SSPIB, SSPIC, SSPID, sup_aur_min, sup_aur_max, sup_aur_min_2, sup_aur_max_2, ms_sup_min, ms_sup_max, ms_inf_min, ms_inf_max, usura_min, usura_max, Id_endo, Is_endo, IId_endo, IIs_endo, IIId_endo, IIIs_endo, IV_endo, V_endo, VI_endo, VII_endo, VIIId_endo, VIIIs_endo, IXd_endo, IXs_endo, Xd_endo, Xs_endo, endo_min, endo_max, volta_1, volta_2, volta_3, volta_4, volta_5, volta_6, volta_7, lat_6, lat_7, lat_8, lat_9, lat_10, volta_min, volta_max, ant_lat_min, ant_lat_max, ecto_min, ecto_max)

##### __repr__(self)

### DETETA

**Inherits from**: object

#### Methods

##### __init__(self, id_det_eta, sito, nr_individuo, sinf_min, sinf_max, sinf_min_2, sinf_max_2, SSPIA, SSPIB, SSPIC, SSPID, sup_aur_min, sup_aur_max, sup_aur_min_2, sup_aur_max_2, ms_sup_min, ms_sup_max, ms_inf_min, ms_inf_max, usura_min, usura_max, Id_endo, Is_endo, IId_endo, IIs_endo, IIId_endo, IIIs_endo, IV_endo, V_endo, VI_endo, VII_endo, VIIId_endo, VIIIs_endo, IXd_endo, IXs_endo, Xd_endo, Xs_endo, endo_min, endo_max, volta_1, volta_2, volta_3, volta_4, volta_5, volta_6, volta_7, lat_6, lat_7, lat_8, lat_9, lat_10, volta_min, volta_max, ant_lat_min, ant_lat_max, ecto_min, ecto_max)

##### __repr__(self)

