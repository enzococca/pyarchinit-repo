# scripts/fix_tma_deletion_issue.py

## Overview

This file contains 9 documented elements.

## Functions

### check_foreign_keys(db_path)

Verifica lo stato delle foreign keys.

**Parameters:**
- `db_path`

### main()

### check_foreign_keys(db_path)

Verifica lo stato delle foreign keys.

**Parameters:**
- `db_path`

### main()

### check_foreign_keys(db_path)

Verifica lo stato delle foreign keys.

**Parameters:**
- `db_path`

### main()

