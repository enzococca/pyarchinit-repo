# modules/db/add_versioning_support.py

## Overview

This file contains 28 documented elements.

## Classes

### VersioningSupport

Add versioning support to database tables

#### Methods

##### __init__(self)

##### get_all_tables(self)

Get all tables that need versioning support

##### add_versioning_columns(self, table_name)

Add versioning columns to a table

##### update_all_tables(self)

Update all tables with versioning support

### VersioningSupport

Add versioning support to database tables

#### Methods

##### __init__(self)

##### get_all_tables(self)

Get all tables that need versioning support

##### add_versioning_columns(self, table_name)

Add versioning columns to a table

##### update_all_tables(self)

Update all tables with versioning support

### VersioningSupport

Add versioning support to database tables

#### Methods

##### __init__(self)

##### get_all_tables(self)

Get all tables that need versioning support

##### add_versioning_columns(self, table_name)

Add versioning columns to a table

##### update_all_tables(self)

Update all tables with versioning support

### VersioningSupport

Add versioning support to database tables

#### Methods

##### __init__(self)

##### get_all_tables(self)

Get all tables that need versioning support

##### add_versioning_columns(self, table_name)

Add versioning columns to a table

##### update_all_tables(self)

Update all tables with versioning support

## Functions

### main()

Main function to add versioning support

### main()

Main function to add versioning support

### main()

Main function to add versioning support

### main()

Main function to add versioning support

