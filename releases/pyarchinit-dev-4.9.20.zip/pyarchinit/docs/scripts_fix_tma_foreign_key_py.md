# scripts/fix_tma_foreign_key.py

## Overview

This file contains 12 documented elements.

## Functions

### fix_foreign_key(file_path)

Corregge la foreign key per puntare alla tabella corretta.

**Parameters:**
- `file_path`

### check_tma_table_name()

Verifica il nome della tabella TMA principale.

### main()

### fix_foreign_key(file_path)

Corregge la foreign key per puntare alla tabella corretta.

**Parameters:**
- `file_path`

### check_tma_table_name()

Verifica il nome della tabella TMA principale.

### main()

### fix_foreign_key(file_path)

Corregge la foreign key per puntare alla tabella corretta.

**Parameters:**
- `file_path`

### check_tma_table_name()

Verifica il nome della tabella TMA principale.

### main()

