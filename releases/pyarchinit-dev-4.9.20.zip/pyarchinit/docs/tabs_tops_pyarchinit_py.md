# tabs/tops_pyarchinit.py

## Overview

This file contains 33 documented elements.

## Classes

### pyarchinit_TOPS

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

Constructor.

##### setPathinput(self)

##### setPathoutput(self)

##### loadCsv(self, fileName)

##### delete(self)

##### listtostr(self)

##### convert_csv(self)

##### on_pushButton_export_pressed(self)

##### rmvLyr(lyrname)

### pyarchinit_TOPS

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

Constructor.

##### setPathinput(self)

##### setPathoutput(self)

##### loadCsv(self, fileName)

##### delete(self)

##### listtostr(self)

##### convert_csv(self)

##### on_pushButton_export_pressed(self)

##### rmvLyr(lyrname)

### pyarchinit_TOPS

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, iface)

Constructor.

##### setPathinput(self)

##### setPathoutput(self)

##### loadCsv(self, fileName)

##### delete(self)

##### listtostr(self)

##### convert_csv(self)

##### on_pushButton_export_pressed(self)

##### rmvLyr(lyrname)

