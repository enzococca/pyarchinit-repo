# modules/utility/settings.py

## Overview

This file contains 16 documented elements.

## Classes

### Settings

**Inherits from**: object

#### Methods

##### __init__(self, s)

##### set_configuration(self)

### Settings

**Inherits from**: object

#### Methods

##### __init__(self, s)

##### set_configuration(self)

### Settings

**Inherits from**: object

#### Methods

##### __init__(self, s)

##### set_configuration(self)

### Settings

**Inherits from**: object

#### Methods

##### __init__(self, s)

##### set_configuration(self)

