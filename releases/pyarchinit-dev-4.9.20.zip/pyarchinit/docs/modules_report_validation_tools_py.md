# modules/report/validation_tools.py

## Overview

This file contains 32 documented elements.

## Classes

### ArchaeologicalValidators

#### Methods

##### validate_site_info(context)

Valida le informazioni del sito

##### validate_us(context)

Validate US descriptions and provide detailed feedback

##### validate_materials(context)

Validate materials descriptions with enhanced feedback

##### validate_pottery(context)

Validate pottery descriptions with enhanced feedback

##### validate_tomba(context)

Validate tomb descriptions with enhanced feedback

##### validate_periodizzazione(context)

Validate periodization data with enhanced feedback

##### validate_struttura(context)

Validate structure data with enhanced feedback

### ArchaeologicalValidators

#### Methods

##### validate_site_info(context)

Valida le informazioni del sito

##### validate_us(context)

Validate US descriptions and provide detailed feedback

##### validate_materials(context)

Validate materials descriptions with enhanced feedback

##### validate_pottery(context)

Validate pottery descriptions with enhanced feedback

##### validate_tomba(context)

Validate tomb descriptions with enhanced feedback

##### validate_periodizzazione(context)

Validate periodization data with enhanced feedback

##### validate_struttura(context)

Validate structure data with enhanced feedback

### ArchaeologicalValidators

#### Methods

##### validate_site_info(context)

Valida le informazioni del sito

##### validate_us(context)

Validate US descriptions and provide detailed feedback

##### validate_materials(context)

Validate materials descriptions with enhanced feedback

##### validate_pottery(context)

Validate pottery descriptions with enhanced feedback

##### validate_tomba(context)

Validate tomb descriptions with enhanced feedback

##### validate_periodizzazione(context)

Validate periodization data with enhanced feedback

##### validate_struttura(context)

Validate structure data with enhanced feedback

### ArchaeologicalValidators

#### Methods

##### validate_site_info(context)

Valida le informazioni del sito

##### validate_us(context)

Validate US descriptions and provide detailed feedback

##### validate_materials(context)

Validate materials descriptions with enhanced feedback

##### validate_pottery(context)

Validate pottery descriptions with enhanced feedback

##### validate_tomba(context)

Validate tomb descriptions with enhanced feedback

##### validate_periodizzazione(context)

Validate periodization data with enhanced feedback

##### validate_struttura(context)

Validate structure data with enhanced feedback

