# scripts/update_schema.py

## Overview

This file contains 18 documented elements.

## Functions

### update_us_fields(content)

Update US fields from BIGINT to TEXT

**Parameters:**
- `content`

### add_tma_table(content)

Add TMA table definition

**Parameters:**
- `content`

### verify_inventario_materiali(content)

Verify and update inventario_materiali table structure

**Parameters:**
- `content`

### add_constraints_and_indexes(content)

Add constraints and indexes for updated schema

**Parameters:**
- `content`

### main()

### update_us_fields(content)

Update US fields from BIGINT to TEXT

**Parameters:**
- `content`

### add_tma_table(content)

Add TMA table definition

**Parameters:**
- `content`

### verify_inventario_materiali(content)

Verify and update inventario_materiali table structure

**Parameters:**
- `content`

### add_constraints_and_indexes(content)

Add constraints and indexes for updated schema

**Parameters:**
- `content`

### main()

### update_us_fields(content)

Update US fields from BIGINT to TEXT

**Parameters:**
- `content`

### add_tma_table(content)

Add TMA table definition

**Parameters:**
- `content`

### verify_inventario_materiali(content)

Verify and update inventario_materiali table structure

**Parameters:**
- `content`

### add_constraints_and_indexes(content)

Add constraints and indexes for updated schema

**Parameters:**
- `content`

### main()

