# modules/db/structures_metadata/Archeozoology_table.py

## Overview

This file contains 4 documented elements.

