# modules/db/structures_metadata/Media_to_Entity_table_view.py

## Overview

This file contains 12 documented elements.

## Classes

### Media_to_Entity_table_view

#### Methods

##### define_table(self, metadata)

### Media_to_Entity_table_view

#### Methods

##### define_table(self, metadata)

### Media_to_Entity_table_view

#### Methods

##### define_table(self, metadata)

### Media_to_Entity_table_view

#### Methods

##### define_table(self, metadata)

