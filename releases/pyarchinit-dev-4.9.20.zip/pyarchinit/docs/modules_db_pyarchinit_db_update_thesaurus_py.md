# modules/db/pyarchinit_db_update_thesaurus.py

## Overview

This file contains 12 documented elements.

## Functions

### update_thesaurus_table(engine, metadata)

Update thesaurus table with new columns if they don't exist

**Parameters:**
- `engine`
- `metadata`

### update_thesaurus_aliases(engine, is_sqlite)

Update table name aliases in thesaurus

**Parameters:**
- `engine`
- `is_sqlite`

### update_thesaurus_table(engine, metadata)

Update thesaurus table with new columns if they don't exist

**Parameters:**
- `engine`
- `metadata`

### update_thesaurus_aliases(engine, is_sqlite)

Update table name aliases in thesaurus

**Parameters:**
- `engine`
- `is_sqlite`

### update_thesaurus_table(engine, metadata)

Update thesaurus table with new columns if they don't exist

**Parameters:**
- `engine`
- `metadata`

### update_thesaurus_aliases(engine, is_sqlite)

Update table name aliases in thesaurus

**Parameters:**
- `engine`
- `is_sqlite`

### update_thesaurus_table(engine, metadata)

Update thesaurus table with new columns if they don't exist

**Parameters:**
- `engine`
- `metadata`

### update_thesaurus_aliases(engine, is_sqlite)

Update table name aliases in thesaurus

**Parameters:**
- `engine`
- `is_sqlite`

