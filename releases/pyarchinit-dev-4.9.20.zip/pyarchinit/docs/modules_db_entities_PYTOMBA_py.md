# modules/db/entities/PYTOMBA.py

## Overview

This file contains 16 documented elements.

## Classes

### PYTOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, nr_scheda, the_geom)

##### __repr__(self)

### PYTOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, nr_scheda, the_geom)

##### __repr__(self)

### PYTOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, nr_scheda, the_geom)

##### __repr__(self)

### PYTOMBA

**Inherits from**: object

#### Methods

##### __init__(self, id, sito, nr_scheda, the_geom)

##### __repr__(self)

