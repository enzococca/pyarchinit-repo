# modules/utility/report_generator.py

## Overview

This file contains 32 documented elements.

## Classes

### ReportGenerator

**Inherits from**: QWidget

#### Methods

##### __init__(self)

##### read_data_from_db(db_url, table_name)

##### chunk_data(data, chunk_size)

##### generate_report_with_openai(self, prompt_completo, modello_selezionato, apikey)

Usa l'API di OpenAI per generare un report basato sul prompt combinato e le descrizioni.

##### is_connected()

##### save_report_to_file_old(report, file_path)

##### save_report_to_file(report, file_path)

Save report with proper formatting and cleaning

### ReportGenerator

**Inherits from**: QWidget

#### Methods

##### __init__(self)

##### read_data_from_db(db_url, table_name)

##### chunk_data(data, chunk_size)

##### generate_report_with_openai(self, prompt_completo, modello_selezionato, apikey)

Usa l'API di OpenAI per generare un report basato sul prompt combinato e le descrizioni.

##### is_connected()

##### save_report_to_file_old(report, file_path)

##### save_report_to_file(report, file_path)

Save report with proper formatting and cleaning

### ReportGenerator

**Inherits from**: QWidget

#### Methods

##### __init__(self)

##### read_data_from_db(db_url, table_name)

##### chunk_data(data, chunk_size)

##### generate_report_with_openai(self, prompt_completo, modello_selezionato, apikey)

Usa l'API di OpenAI per generare un report basato sul prompt combinato e le descrizioni.

##### is_connected()

##### save_report_to_file_old(report, file_path)

##### save_report_to_file(report, file_path)

Save report with proper formatting and cleaning

### ReportGenerator

**Inherits from**: QWidget

#### Methods

##### __init__(self)

##### read_data_from_db(db_url, table_name)

##### chunk_data(data, chunk_size)

##### generate_report_with_openai(self, prompt_completo, modello_selezionato, apikey)

Usa l'API di OpenAI per generare un report basato sul prompt combinato e le descrizioni.

##### is_connected()

##### save_report_to_file_old(report, file_path)

##### save_report_to_file(report, file_path)

Save report with proper formatting and cleaning

