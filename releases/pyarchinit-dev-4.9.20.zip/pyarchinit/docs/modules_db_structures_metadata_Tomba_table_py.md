# modules/db/structures_metadata/Tomba_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Tomba_table

#### Methods

##### define_table(cls, metadata)

### Tomba_table

#### Methods

##### define_table(cls, metadata)

### Tomba_table

#### Methods

##### define_table(cls, metadata)

### Tomba_table

#### Methods

##### define_table(cls, metadata)

