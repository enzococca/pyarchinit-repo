# modules/db/entities/PYREPERTI.py

## Overview

This file contains 16 documented elements.

## Classes

### PYREPERTI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rep, siti, link, the_geom)

##### __repr__(self)

### PYREPERTI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rep, siti, link, the_geom)

##### __repr__(self)

### PYREPERTI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rep, siti, link, the_geom)

##### __repr__(self)

### PYREPERTI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_rep, siti, link, the_geom)

##### __repr__(self)

