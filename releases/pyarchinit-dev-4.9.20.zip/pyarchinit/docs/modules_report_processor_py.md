# modules/report/processor.py

## Overview

This file contains 12 documented elements.

## Classes

### ArchaeologicalStepProcessor

#### Methods

##### __init__(self)

##### process_step(self, step, context)

Processa uno step dell'analisi

### ArchaeologicalStepProcessor

#### Methods

##### __init__(self)

##### process_step(self, step, context)

Processa uno step dell'analisi

### ArchaeologicalStepProcessor

#### Methods

##### __init__(self)

##### process_step(self, step, context)

Processa uno step dell'analisi

### ArchaeologicalStepProcessor

#### Methods

##### __init__(self)

##### process_step(self, step, context)

Processa uno step dell'analisi

