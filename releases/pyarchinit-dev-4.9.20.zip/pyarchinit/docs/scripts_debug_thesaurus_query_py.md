# scripts/debug_thesaurus_query.py

## Overview

This file contains 9 documented elements.

## Functions

### debug_thesaurus(db_path)

Debug delle query thesaurus.

**Parameters:**
- `db_path`

### main()

### debug_thesaurus(db_path)

Debug delle query thesaurus.

**Parameters:**
- `db_path`

### main()

### debug_thesaurus(db_path)

Debug delle query thesaurus.

**Parameters:**
- `db_path`

### main()

