# gui/quantpanelmain.py

## Overview

This file contains 28 documented elements.

## Classes

### QuantPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### on_pushButtonQuant_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

### QuantPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### on_pushButtonQuant_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

### QuantPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### on_pushButtonQuant_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

### QuantPanelMain

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### on_pushButtonQuant_pressed(self)

##### on_pushButtonRight_pressed(self)

##### on_pushButtonLeft_pressed(self)

##### insertItems(self, lv)

