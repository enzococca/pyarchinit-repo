# modules/db/entities/CAMPIONI.py

## Overview

This file contains 16 documented elements.

## Classes

### CAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id_campione, sito, nr_campione, tipo_campione, descrizione, area, us, numero_inventario_materiale, nr_cassa, luogo_conservazione)

##### __repr__(self)

### CAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id_campione, sito, nr_campione, tipo_campione, descrizione, area, us, numero_inventario_materiale, nr_cassa, luogo_conservazione)

##### __repr__(self)

### CAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id_campione, sito, nr_campione, tipo_campione, descrizione, area, us, numero_inventario_materiale, nr_cassa, luogo_conservazione)

##### __repr__(self)

### CAMPIONI

**Inherits from**: object

#### Methods

##### __init__(self, id_campione, sito, nr_campione, tipo_campione, descrizione, area, us, numero_inventario_materiale, nr_cassa, luogo_conservazione)

##### __repr__(self)

