# tabs/Pdf_administrator.py

## Overview

This file contains 144 documented elements.

## Classes

### pyarchinit_PDFAdministrator

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### enable_button(self, n)

##### enable_button_search(self, n)

##### connect(self)

##### cellchanged(self)

##### on_pushButton_inserisci_nome_campo_pressed(self)

##### cell_click_ed(self)

##### set_table_name(self, tname)

##### charge_list(self)

##### add_id_list(self, id_list)

##### on_pushButton_charge_default_schema_pressed(self)

##### on_pushButton_sort_pressed(self)

##### on_pushButton_new_rec_pressed(self)

##### on_pushButton_save_pressed(self)

##### data_error_check(self)

##### insert_new_rec(self)

##### on_pushButton_view_all_pressed(self)

##### on_pushButton_first_rec_pressed(self)

##### on_pushButton_last_rec_pressed(self)

##### on_pushButton_prev_rec_pressed(self)

##### on_pushButton_next_rec_pressed(self)

##### on_pushButton_delete_pressed(self)

##### on_pushButton_new_search_pressed(self)

##### on_pushButton_search_go_pressed(self)

##### update_if(self, msg)

##### charge_records(self)

##### datestrfdate(self)

##### empty_fields(self)

##### fill_fields(self, n)

##### set_rec_counter(self, t, c)

##### set_LIST_REC_TEMP(self)

##### set_LIST_REC_CORR(self)

##### setComboBoxEnable(self, f, v)

##### setComboBoxEditable(self, f, n)

##### rec_toupdate(self)

##### records_equal_check(self)

##### update_record(self)

##### testing(self, name_file, message)

##### table2dict(self, n)

##### tableInsertData(self, t, d)

Set the value into alls Grid

##### on_pushButton_add_row_griglia_pressed(self)

##### on_pushButton_remove_row_griglia_pressed(self)

##### on_pushButton_add_row_cell_pressed(self)

##### on_pushButton_remove_row_cell_pressed(self)

##### insert_new_row(self, table_name)

insert new row into a table based on table_name

##### remove_row(self, table_name)

insert new row into a table based on table_name

### pyarchinit_PDFAdministrator

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### enable_button(self, n)

##### enable_button_search(self, n)

##### connect(self)

##### cellchanged(self)

##### on_pushButton_inserisci_nome_campo_pressed(self)

##### cell_click_ed(self)

##### set_table_name(self, tname)

##### charge_list(self)

##### add_id_list(self, id_list)

##### on_pushButton_charge_default_schema_pressed(self)

##### on_pushButton_sort_pressed(self)

##### on_pushButton_new_rec_pressed(self)

##### on_pushButton_save_pressed(self)

##### data_error_check(self)

##### insert_new_rec(self)

##### on_pushButton_view_all_pressed(self)

##### on_pushButton_first_rec_pressed(self)

##### on_pushButton_last_rec_pressed(self)

##### on_pushButton_prev_rec_pressed(self)

##### on_pushButton_next_rec_pressed(self)

##### on_pushButton_delete_pressed(self)

##### on_pushButton_new_search_pressed(self)

##### on_pushButton_search_go_pressed(self)

##### update_if(self, msg)

##### charge_records(self)

##### datestrfdate(self)

##### empty_fields(self)

##### fill_fields(self, n)

##### set_rec_counter(self, t, c)

##### set_LIST_REC_TEMP(self)

##### set_LIST_REC_CORR(self)

##### setComboBoxEnable(self, f, v)

##### setComboBoxEditable(self, f, n)

##### rec_toupdate(self)

##### records_equal_check(self)

##### update_record(self)

##### testing(self, name_file, message)

##### table2dict(self, n)

##### tableInsertData(self, t, d)

Set the value into alls Grid

##### on_pushButton_add_row_griglia_pressed(self)

##### on_pushButton_remove_row_griglia_pressed(self)

##### on_pushButton_add_row_cell_pressed(self)

##### on_pushButton_remove_row_cell_pressed(self)

##### insert_new_row(self, table_name)

insert new row into a table based on table_name

##### remove_row(self, table_name)

insert new row into a table based on table_name

### pyarchinit_PDFAdministrator

**Inherits from**: QDialog, MAIN_DIALOG_CLASS

#### Methods

##### __init__(self, parent, db)

##### enable_button(self, n)

##### enable_button_search(self, n)

##### connect(self)

##### cellchanged(self)

##### on_pushButton_inserisci_nome_campo_pressed(self)

##### cell_click_ed(self)

##### set_table_name(self, tname)

##### charge_list(self)

##### add_id_list(self, id_list)

##### on_pushButton_charge_default_schema_pressed(self)

##### on_pushButton_sort_pressed(self)

##### on_pushButton_new_rec_pressed(self)

##### on_pushButton_save_pressed(self)

##### data_error_check(self)

##### insert_new_rec(self)

##### on_pushButton_view_all_pressed(self)

##### on_pushButton_first_rec_pressed(self)

##### on_pushButton_last_rec_pressed(self)

##### on_pushButton_prev_rec_pressed(self)

##### on_pushButton_next_rec_pressed(self)

##### on_pushButton_delete_pressed(self)

##### on_pushButton_new_search_pressed(self)

##### on_pushButton_search_go_pressed(self)

##### update_if(self, msg)

##### charge_records(self)

##### datestrfdate(self)

##### empty_fields(self)

##### fill_fields(self, n)

##### set_rec_counter(self, t, c)

##### set_LIST_REC_TEMP(self)

##### set_LIST_REC_CORR(self)

##### setComboBoxEnable(self, f, v)

##### setComboBoxEditable(self, f, n)

##### rec_toupdate(self)

##### records_equal_check(self)

##### update_record(self)

##### testing(self, name_file, message)

##### table2dict(self, n)

##### tableInsertData(self, t, d)

Set the value into alls Grid

##### on_pushButton_add_row_griglia_pressed(self)

##### on_pushButton_remove_row_griglia_pressed(self)

##### on_pushButton_add_row_cell_pressed(self)

##### on_pushButton_remove_row_cell_pressed(self)

##### insert_new_row(self, table_name)

insert new row into a table based on table_name

##### remove_row(self, table_name)

insert new row into a table based on table_name

