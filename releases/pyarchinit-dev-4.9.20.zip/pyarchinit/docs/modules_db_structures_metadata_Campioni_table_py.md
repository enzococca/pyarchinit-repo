# modules/db/structures_metadata/Campioni_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Campioni_table

#### Methods

##### define_table(cls, metadata)

### Campioni_table

#### Methods

##### define_table(cls, metadata)

### Campioni_table

#### Methods

##### define_table(cls, metadata)

### Campioni_table

#### Methods

##### define_table(cls, metadata)

