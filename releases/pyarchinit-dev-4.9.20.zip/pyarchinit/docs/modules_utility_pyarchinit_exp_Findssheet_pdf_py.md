# modules/utility/pyarchinit_exp_Findssheet_pdf.py

## Overview

This file contains 300 documented elements.

## Classes

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_FINDSindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FINDS_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet_2

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### generate_reperti_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_index_Foto(self, records, sito)

##### build_index_Foto_en(self, records, sito)

##### build_index_Foto_de(self, records, sito)

##### build_index_Foto_2(self, records, sito)

##### build_index_Foto_2_en(self, records, sito)

##### build_index_Foto_2_de(self, records, sito)

##### build_Finds_sheets(self, records)

##### build_Finds_sheets_de(self, records)

##### build_Finds_sheets_en(self, records)

##### build_index_Finds(self, records, sito)

##### build_index_Finds_de(self, records, sito)

##### build_index_Finds_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Finds(self, records, sito)

##### build_box_labels_Finds_de(self, records, sito)

##### build_box_labels_Finds_en(self, records, sito)

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_FINDSindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FINDS_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet_2

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### generate_reperti_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_index_Foto(self, records, sito)

##### build_index_Foto_en(self, records, sito)

##### build_index_Foto_de(self, records, sito)

##### build_index_Foto_2(self, records, sito)

##### build_index_Foto_2_en(self, records, sito)

##### build_index_Foto_2_de(self, records, sito)

##### build_Finds_sheets(self, records)

##### build_Finds_sheets_de(self, records)

##### build_Finds_sheets_en(self, records)

##### build_index_Finds(self, records, sito)

##### build_index_Finds_de(self, records, sito)

##### build_index_Finds_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Finds(self, records, sito)

##### build_box_labels_Finds_de(self, records, sito)

##### build_box_labels_Finds_en(self, records, sito)

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_FINDSindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FINDS_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet_2

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### generate_reperti_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_index_Foto(self, records, sito)

##### build_index_Foto_en(self, records, sito)

##### build_index_Foto_de(self, records, sito)

##### build_index_Foto_2(self, records, sito)

##### build_index_Foto_2_en(self, records, sito)

##### build_index_Foto_2_de(self, records, sito)

##### build_Finds_sheets(self, records)

##### build_Finds_sheets_de(self, records)

##### build_Finds_sheets_en(self, records)

##### build_index_Finds(self, records, sito)

##### build_index_Finds_de(self, records, sito)

##### build_index_Finds_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Finds(self, records, sito)

##### build_box_labels_Finds_de(self, records, sito)

##### build_box_labels_Finds_en(self, records, sito)

### NumberedCanvas_Findssheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_FINDSindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_CASSEindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Box_labels_Finds_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data, sito)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### CASSE_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FINDS_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### FOTO_index_pdf_sheet_2

**Inherits from**: object

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_en(self)

##### getTable_de(self)

##### makeStyles(self)

### generate_reperti_pdf

**Inherits from**: object

#### Methods

##### datestrfdate(self)

##### build_index_Foto(self, records, sito)

##### build_index_Foto_en(self, records, sito)

##### build_index_Foto_de(self, records, sito)

##### build_index_Foto_2(self, records, sito)

##### build_index_Foto_2_en(self, records, sito)

##### build_index_Foto_2_de(self, records, sito)

##### build_Finds_sheets(self, records)

##### build_Finds_sheets_de(self, records)

##### build_Finds_sheets_en(self, records)

##### build_index_Finds(self, records, sito)

##### build_index_Finds_de(self, records, sito)

##### build_index_Finds_en(self, records, sito)

##### build_index_Casse(self, records, sito)

##### build_index_Casse_de(self, records, sito)

##### build_index_Casse_en(self, records, sito)

##### build_box_labels_Finds(self, records, sito)

##### build_box_labels_Finds_de(self, records, sito)

##### build_box_labels_Finds_en(self, records, sito)

