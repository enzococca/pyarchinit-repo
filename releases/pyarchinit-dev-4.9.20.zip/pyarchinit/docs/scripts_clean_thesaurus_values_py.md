# scripts/clean_thesaurus_values.py

## Overview

This file contains 9 documented elements.

## Functions

### clean_thesaurus_values(db_path)

Pulisce i valori None e sistema le tipologie.

**Parameters:**
- `db_path`

### main()

### clean_thesaurus_values(db_path)

Pulisce i valori None e sistema le tipologie.

**Parameters:**
- `db_path`

### main()

### clean_thesaurus_values(db_path)

Pulisce i valori None e sistema le tipologie.

**Parameters:**
- `db_path`

### main()

