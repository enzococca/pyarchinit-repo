# modules/db/structures_metadata/pytomba.py

## Overview

This file contains 12 documented elements.

## Classes

### pytomba

#### Methods

##### define_table(cls, metadata)

### pytomba

#### Methods

##### define_table(cls, metadata)

### pytomba

#### Methods

##### define_table(cls, metadata)

### pytomba

#### Methods

##### define_table(cls, metadata)

