# modules/db/entities/PYSEZIONI.py

## Overview

This file contains 16 documented elements.

## Classes

### PYSEZIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_sezione, sito, area, descr, the_geom, tipo_doc, nome_doc)

##### __repr__(self)

### PYSEZIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_sezione, sito, area, descr, the_geom, tipo_doc, nome_doc)

##### __repr__(self)

### PYSEZIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_sezione, sito, area, descr, the_geom, tipo_doc, nome_doc)

##### __repr__(self)

### PYSEZIONI

**Inherits from**: object

#### Methods

##### __init__(self, id, id_sezione, sito, area, descr, the_geom, tipo_doc, nome_doc)

##### __repr__(self)

