# modules/utility/pyarchinit_exp_Documentazionesheet_pdf.py

## Overview

This file contains 132 documented elements.

## Classes

### NumberedCanvas_Documentazionesheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Documentazioneindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Documentazione_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Documentazione_index_pdf_sheet

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_documentazione_pdf

#### Methods

##### datestrfdate(self)

##### build_Documentazione_sheets(self, records)

##### build_Documentazione_sheets_de(self, records)

##### build_Documentazione_sheets_en(self, records)

##### build_index_Documentazione(self, records, sito)

##### build_index_Documentazione_de(self, records, sito)

##### build_index_Documentazione_en(self, records, sito)

### NumberedCanvas_Documentazionesheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Documentazioneindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Documentazione_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Documentazione_index_pdf_sheet

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_documentazione_pdf

#### Methods

##### datestrfdate(self)

##### build_Documentazione_sheets(self, records)

##### build_Documentazione_sheets_de(self, records)

##### build_Documentazione_sheets_en(self, records)

##### build_index_Documentazione(self, records, sito)

##### build_index_Documentazione_de(self, records, sito)

##### build_index_Documentazione_en(self, records, sito)

### NumberedCanvas_Documentazionesheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Documentazioneindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Documentazione_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Documentazione_index_pdf_sheet

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_documentazione_pdf

#### Methods

##### datestrfdate(self)

##### build_Documentazione_sheets(self, records)

##### build_Documentazione_sheets_de(self, records)

##### build_Documentazione_sheets_en(self, records)

##### build_index_Documentazione(self, records, sito)

##### build_index_Documentazione_de(self, records, sito)

##### build_index_Documentazione_en(self, records, sito)

### NumberedCanvas_Documentazionesheet

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### NumberedCanvas_Documentazioneindex

**Inherits from**: canvas.Canvas

#### Methods

##### __init__(self)

##### define_position(self, pos)

##### showPage(self)

##### save(self)

add page info to each page (page x of y)

##### draw_page_number(self, page_count)

### single_Documentazione_pdf_sheet

#### Methods

##### __init__(self, data)

##### datestrfdate(self)

##### create_sheet(self)

##### create_sheet_de(self)

##### create_sheet_en(self)

### Documentazione_index_pdf_sheet

#### Methods

##### __init__(self, data)

##### getTable(self)

##### getTable_de(self)

##### getTable_en(self)

##### makeStyles(self)

### generate_documentazione_pdf

#### Methods

##### datestrfdate(self)

##### build_Documentazione_sheets(self, records)

##### build_Documentazione_sheets_de(self, records)

##### build_Documentazione_sheets_en(self, records)

##### build_index_Documentazione(self, records, sito)

##### build_index_Documentazione_de(self, records, sito)

##### build_index_Documentazione_en(self, records, sito)

