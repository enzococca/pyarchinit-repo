# modules/gis/pyarchinit_pyqgis_archeozoo.py

## Overview

This file contains 88 documented elements.

## Classes

### Pyarchinit_pyqgis

**Inherits from**: QDialog

#### Methods

##### __init__(self, iface)

##### remove_USlayer_from_registry(self)

##### charge_individui_us(self, data)

##### charge_vector_layers(self, data)

##### charge_vector_layers_periodo(self, cont_per)

##### loadMapPreview(self, gidstr)

if has geometry column load to map canvas 

##### dataProviderFields(self)

##### selectedFeatures(self)

##### findFieldFrDict(self, fn)

##### findItemInAttributeMap(self, fp, fl)

### Order_layers

**Inherits from**: object

#### Methods

##### __init__(self, lr)

##### main(self)

##### add_values_to_lista_us(self)

##### loop_on_lista_us(self)

##### check_position(self, n)

##### add_key_value_to_diz(self, n)

### MyError

**Inherits from**: Exception

#### Methods

##### __init__(self, value)

##### __str__(self)

### Pyarchinit_pyqgis

**Inherits from**: QDialog

#### Methods

##### __init__(self, iface)

##### remove_USlayer_from_registry(self)

##### charge_individui_us(self, data)

##### charge_vector_layers(self, data)

##### charge_vector_layers_periodo(self, cont_per)

##### loadMapPreview(self, gidstr)

if has geometry column load to map canvas 

##### dataProviderFields(self)

##### selectedFeatures(self)

##### findFieldFrDict(self, fn)

##### findItemInAttributeMap(self, fp, fl)

### Order_layers

**Inherits from**: object

#### Methods

##### __init__(self, lr)

##### main(self)

##### add_values_to_lista_us(self)

##### loop_on_lista_us(self)

##### check_position(self, n)

##### add_key_value_to_diz(self, n)

### MyError

**Inherits from**: Exception

#### Methods

##### __init__(self, value)

##### __str__(self)

### Pyarchinit_pyqgis

**Inherits from**: QDialog

#### Methods

##### __init__(self, iface)

##### remove_USlayer_from_registry(self)

##### charge_individui_us(self, data)

##### charge_vector_layers(self, data)

##### charge_vector_layers_periodo(self, cont_per)

##### loadMapPreview(self, gidstr)

if has geometry column load to map canvas 

##### dataProviderFields(self)

##### selectedFeatures(self)

##### findFieldFrDict(self, fn)

##### findItemInAttributeMap(self, fp, fl)

### Order_layers

**Inherits from**: object

#### Methods

##### __init__(self, lr)

##### main(self)

##### add_values_to_lista_us(self)

##### loop_on_lista_us(self)

##### check_position(self, n)

##### add_key_value_to_diz(self, n)

### MyError

**Inherits from**: Exception

#### Methods

##### __init__(self, value)

##### __str__(self)

### Pyarchinit_pyqgis

**Inherits from**: QDialog

#### Methods

##### __init__(self, iface)

##### remove_USlayer_from_registry(self)

##### charge_individui_us(self, data)

##### charge_vector_layers(self, data)

##### charge_vector_layers_periodo(self, cont_per)

##### loadMapPreview(self, gidstr)

if has geometry column load to map canvas 

##### dataProviderFields(self)

##### selectedFeatures(self)

##### findFieldFrDict(self, fn)

##### findItemInAttributeMap(self, fp, fl)

### Order_layers

**Inherits from**: object

#### Methods

##### __init__(self, lr)

##### main(self)

##### add_values_to_lista_us(self)

##### loop_on_lista_us(self)

##### check_position(self, n)

##### add_key_value_to_diz(self, n)

### MyError

**Inherits from**: Exception

#### Methods

##### __init__(self, value)

##### __str__(self)

