# scripts/add_tma_columns.py

## Overview

This file contains 9 documented elements.

## Functions

### add_columns(db_path)

Aggiunge le colonne created_by e updated_by.

**Parameters:**
- `db_path`

### main()

### add_columns(db_path)

Aggiunge le colonne created_by e updated_by.

**Parameters:**
- `db_path`

### main()

### add_columns(db_path)

Aggiunge le colonne created_by e updated_by.

**Parameters:**
- `db_path`

### main()

