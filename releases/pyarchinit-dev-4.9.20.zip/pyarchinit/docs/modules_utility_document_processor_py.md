# modules/utility/document_processor.py

## Overview

This file contains 24 documented elements.

## Classes

### DocumentProcessor

Processa documenti Word applicando cleaning e correzione stili

#### Methods

##### __init__(self)

##### process_document(self, doc_path, output_path)

Processa un documento Word correggendo stili e formattazione

Args:
    doc_path: Path al documento da processare
    output_path: Path di output (opzionale, sovrascrive l'originale se None)

Returns:
    Dizionario con statistiche del processing

##### process_content_to_paragraphs(self, content, doc)

Processa contenuto testuale e lo aggiunge al documento con stili corretti

Args:
    content: Testo da processare
    doc: Documento Word a cui aggiungere il contenuto

##### quick_fix_document(doc_path)

Metodo statico per correzione rapida di un documento

Args:
    doc_path: Path al documento da correggere

Returns:
    Statistiche della correzione

### DocumentProcessor

Processa documenti Word applicando cleaning e correzione stili

#### Methods

##### __init__(self)

##### process_document(self, doc_path, output_path)

Processa un documento Word correggendo stili e formattazione

Args:
    doc_path: Path al documento da processare
    output_path: Path di output (opzionale, sovrascrive l'originale se None)

Returns:
    Dizionario con statistiche del processing

##### process_content_to_paragraphs(self, content, doc)

Processa contenuto testuale e lo aggiunge al documento con stili corretti

Args:
    content: Testo da processare
    doc: Documento Word a cui aggiungere il contenuto

##### quick_fix_document(doc_path)

Metodo statico per correzione rapida di un documento

Args:
    doc_path: Path al documento da correggere

Returns:
    Statistiche della correzione

### DocumentProcessor

Processa documenti Word applicando cleaning e correzione stili

#### Methods

##### __init__(self)

##### process_document(self, doc_path, output_path)

Processa un documento Word correggendo stili e formattazione

Args:
    doc_path: Path al documento da processare
    output_path: Path di output (opzionale, sovrascrive l'originale se None)

Returns:
    Dizionario con statistiche del processing

##### process_content_to_paragraphs(self, content, doc)

Processa contenuto testuale e lo aggiunge al documento con stili corretti

Args:
    content: Testo da processare
    doc: Documento Word a cui aggiungere il contenuto

##### quick_fix_document(doc_path)

Metodo statico per correzione rapida di un documento

Args:
    doc_path: Path al documento da correggere

Returns:
    Statistiche della correzione

### DocumentProcessor

Processa documenti Word applicando cleaning e correzione stili

#### Methods

##### __init__(self)

##### process_document(self, doc_path, output_path)

Processa un documento Word correggendo stili e formattazione

Args:
    doc_path: Path al documento da processare
    output_path: Path di output (opzionale, sovrascrive l'originale se None)

Returns:
    Dizionario con statistiche del processing

##### process_content_to_paragraphs(self, content, doc)

Processa contenuto testuale e lo aggiunge al documento con stili corretti

Args:
    content: Testo da processare
    doc: Documento Word a cui aggiungere il contenuto

##### quick_fix_document(doc_path)

Metodo statico per correzione rapida di un documento

Args:
    doc_path: Path al documento da correggere

Returns:
    Statistiche della correzione

