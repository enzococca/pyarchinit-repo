# scripts/insert_tma_vocabularies.py

## Overview

This file contains 6 documented elements.

## Functions

### insert_tma_vocabularies()

Insert TMA vocabularies into thesaurus table.

### insert_tma_vocabularies()

Insert TMA vocabularies into thesaurus table.

### insert_tma_vocabularies()

Insert TMA vocabularies into thesaurus table.

