# modules/db/structures_metadata/Inventario_Lapidei_table.py

## Overview

This file contains 12 documented elements.

## Classes

### Inventario_Lapidei_table

#### Methods

##### define_table(cls, metadata)

### Inventario_Lapidei_table

#### Methods

##### define_table(cls, metadata)

### Inventario_Lapidei_table

#### Methods

##### define_table(cls, metadata)

### Inventario_Lapidei_table

#### Methods

##### define_table(cls, metadata)

