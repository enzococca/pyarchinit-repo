
CREATE TABLE IF NOT EXISTS"pyarchinit_us_negative_doc" (
"pkuid" integer PRIMARY KEY AUTOINCREMENT,
"sito_n" text,
"area_n" text,
"us_n" integer,
"tipo_doc_n" text,
"nome_doc_n" text, "the_geom" LINESTRING)